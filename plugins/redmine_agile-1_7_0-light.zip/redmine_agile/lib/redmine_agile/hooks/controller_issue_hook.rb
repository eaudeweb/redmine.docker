# This file is a part of Redmin Agile (redmine_agile) plugin,
# Agile board plugin for redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_agile is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_agile is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_agile.  If not, see <http://www.gnu.org/licenses/>.

module RedmineAgile
  module Hooks
    class ControllerIssueHook < Redmine::Hook::ViewListener

      def controller_issues_edit_before_save(context={})
        add_agile_journal_details(context) unless context[:controller].api_request?
      end

      def controller_issues_bulk_edit_before_save(context={})
        add_agile_journal_details(context) unless context[:controller].api_request?
      end

      def controller_issues_new_after_save(context={})
        notify_web_socket_services(context) unless context[:controller].api_request?
      end

      private

      def add_agile_journal_details(context)
        return false unless context[:issue].project.module_enabled?(:agile)
        # return false unless context[:issue].color
        old_value = Issue.where(id: context[:issue].id).first || context[:issue]
        # save changes for story points to journal
        old_sp = old_value.story_points
        new_sp = context[:issue].story_points
        if !((new_sp == old_sp) || context[:issue].current_journal.blank?)
          context[:issue].current_journal.details << JournalDetail.new(:property => 'attr',
          :prop_key => 'story_points',
          :old_value => old_sp,
          :value => new_sp)
        end

      end

      def notify_web_socket_services(context)
        context[:controller].retrieve_agile_query_from_session
        context[:controller].web_socket_service_create(context[:params], context[:issue], { project: context[:issue].project })
      end
    end
  end
end
