module RedmineXAssets
  module Helpers
    # Module which enables to collect translations and send them to the js gantt app
    module TranslationsHelper

      # Loads translations from locale files, filters only the necessary keys and converts them to json
      # @param locale_paths [Array] of strings containing paths to directories with locale files
      # @param translation_keys [Array] of symbols - name of keys which should be exported
      # @return [Hash] (json) = translations in appropriate language in json
      def export_translations(locale_paths, translation_keys)
        translator = I18n.backend
        translator.load_translations(locale_files(locale_paths))
        translations = translator.send(:translations)
        result = {}

        # If translation of current language exists, use it, otherwise use english
        translation_keys.each do |key|
          if translations[I18n.locale].key?(key)
            result.merge!(translations[I18n.locale][key])
          else
            result.merge!(translations[:en][key])
          end
        end

        result.merge!(translations_from_redmine(translations, I18n.locale))
        result.to_json.html_safe
      end

      # Returns jquery datepickers locale according to the availability on the server
      def datepicker_locale
        return 'en' if I18n.locale == :en

        locales_dir = "#{Redmine::Plugin.find(:redmine_x_assets).assets_directory}/javascripts/jquery_datepicker_locale"
        if File.exist?("#{locales_dir}/datepicker-#{I18n.locale.to_s}.js")
          return I18n.locale.to_s
        else
          return 'en'
        end
      end

      private

      # Collects paths to plugin locales files
      # @param dir_paths [Array] of strings containing paths to directories with locale files
      # @return [Array] of strings = paths of locales files
      def locale_files(dir_paths)
        paths = []
        dir_paths.each { |path| paths += Dir.glob(path).map(&File.method(:realpath)) }
        paths
      end

      # Collects translation of keys, which are in redmine (global) locale files
      # @param translations [Hash] of all translations including the ones from redmine
      # @param locale [Symbol] symbol of locale we want to translate, e.g. :en
      # @return [Hash] hash of keys with translations from redmine
      def translations_from_redmine(translations, locale)
        result = {}
        values_to_translate.each do |value|
          translated_value = translations[locale].dig(*Array(value)) || translations[:en].dig(*Array(value))
          result[Array(value).last] = translated_value
        end
        result
      end

      # Defines which keys should be translated from the redmine's locale files
      # @return [Array] of symbols = keys which should be translated from redmine and not from plugin
      def values_to_translate
        [
          :date,
          :button_apply,
          :button_close,

          :error_no_tracker_in_project,

          :label_copy_source,
          :label_copy_target,
          :label_day_plural,
          :label_filter_plural,
          :label_group,
          :label_issue,
          :label_me,
          :label_new,
          :label_project,
          :label_project_plural,
          :label_spent_time,
          :label_total_time,
          :label_user,
          :label_user_plural,
          :label_version,

          :field_assigned_to,
          :field_author,
          :field_delay,
          :field_description,
          :field_due_date,
          :field_estimated_hours,
          :field_issue_to,
          :field_name,
          :field_parent_issue,
          :field_priority,
          :field_start_date,
          :field_subject,

          :general_text_Yes,
          :general_text_No,

          [:activerecord, :errors, :messages, :blank],
          [:activerecord, :errors, :messages, :cant_link_an_issue_with_a_descendant],
          [:activerecord, :errors, :messages, :not_same_project],
        ]
      end
    end
  end
end
