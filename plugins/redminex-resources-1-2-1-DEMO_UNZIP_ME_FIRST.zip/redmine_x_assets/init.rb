Redmine::Plugin.register :redmine_x_assets do
  name 'RedmineX Assets'
  author 'Ondřej Svejkovský'
  description 'Plugin with common backend and frontend assets for RedmineX Gantt and Resources'
  version '1.0.1'
  url 'https://www.redmine-x.com'
end
