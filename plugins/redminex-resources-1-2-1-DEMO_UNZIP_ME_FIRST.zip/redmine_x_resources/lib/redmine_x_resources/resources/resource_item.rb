module RedmineXResources
  module Resources
    class ResourceItem
      TYPE_ENTRY = 'TYPE_ENTRY'
      TYPE_FIXED = 'TYPE_FIXED'
      TYPE_DISTRIBUTION = 'TYPE_DISTRIBUTION'
      TYPE_DAYOFF = 'TYPE_DAYOFF'

      attr_reader :data, :external, :id
      attr_accessor :parent_project, :parent_user

      def initialize(options)
        @data = {}
        @parent_project = nil
        @parent_user = nil
        @external = options[:external]
        if options[:type]
          @id = options[:id]
          @type = options[:type]
        else
          initialize_type_and_id(options[:item])
        end
        initialize_all_values
      end

      def initialize_type_and_id(item)
        if item.class == Issue
          @type = 'issue'
        elsif item.class == Project
          @type = 'project'
        elsif item.class == User
          @type = 'user'
        else
          @type = 'group'
        end
      end

      def initialize_all_values
        @data[:values] = {}
        @data[:estimated] = 0
        @data[:fixedTotal] = 0
        @data[:hoursDistribution] = 0
        @data[:hoursDistributionTotal] = 0
        @data[:spentTotal] = 0
        @data[:highEstimation] = 0
        @data[:lowEstimation] = 0
        if (@type != 'issue' && @type != 'project')
          @data[:valuesExternal] = {}
          @data[:estimatedExternal] = 0
          @data[:fixedTotalExternal] = 0
          @data[:hoursDistributionTotalExternal] = 0
          @data[:spentTotalExternal] = 0
        end
      end

      def set_value(date, value, external=false)
        # p "SET VALUE #{@id}, #{date}, #{value}, #{external}"
        # puts "=============================================================="
        # set_min_end_and_start_date(date, value) if @type == 'issue' && !@external

        data_type_key = external ? :valuesExternal : :values

        if @data[data_type_key][date]
          @data[data_type_key][date][:hours] += value[:hours]
          @data[data_type_key][date][:type] = value[:type]
        else
          @data[data_type_key][date] = value.dup
        end

        total_value = case value[:type]
                      when TYPE_ENTRY
                        'spentTotal'
                      when TYPE_FIXED
                        'fixedTotal'
                      when TYPE_DISTRIBUTION
                        'hoursDistributionTotal'
                      when TYPE_DAYOFF
                        nil
                      end
        total_value = total_value && external ? "#{total_value}External" : total_value
        #p "total_value", total_value
        @data[total_value.to_sym] += value[:hours] if total_value

        @parent_project.set_value(date, value) if @parent_project && !@external
        @parent_user.set_value(date, value, @external) if @parent_user
        #p "@parent_project", @parent_project.data if @parent_project
        #p "@parent_user", @parent_user.data if @parent_user
      end

      # def set(key, value)
      #   if @data[key].class == Integer || @data[key].class == Float
      #     @data[key] += value
      #   else
      #     @data[key] ||= value
      #   end

      #   return if key == :hoursDistribution

      #   if @external &&  (@data[key].class == Integer || @data[key].class == Float)
      #     if key.to_s.include?('External')
      #       @parent_user.set(key, value) if @parent_user
      #     else
      #       @parent_user.set("#{key.to_s}External".to_sym, value) if @parent_user
      #     end
      #   else
      #     @parent_project.set(key, value) if @parent_project
      #     @parent_user.set(key, value) if @parent_user
      #   end
      # end

      def set_number(key, value)
        @data[key] += value
        return if key == :hoursDistribution

        if @external
          if key.to_s.include?('External')
            @parent_user.set_number(key, value) if @parent_user
          else
            @parent_user.set_number("#{key.to_s}External".to_sym, value) if @parent_user
          end
        else
          @parent_project.set_number(key, value) if @parent_project
          @parent_user.set_number(key, value) if @parent_user
        end
      end

      def set_boolean(key, value)
        @data[key] ||= value

        @parent_project.set_boolean(key, value) if @parent_project
        @parent_user.set_boolean(key, value) if @parent_user
      end

      def set_time_entry(assigned_to_id, value)
        if @type == 'issue' ||
           @type == 'group' ||
           (@type == 'user' && @id == assigned_to_id)

           @data[:spentTotal] += value
        end

        @parent_project.set_time_entry(assigned_to_id, value) if @parent_project
        @parent_user.set_time_entry(assigned_to_id, value) if @parent_user

        # if @external
        #   if key.to_s.include?('External')
        #     @parent_user.set(key, value) if @parent_user
        #   else
        #     @parent_user.set("#{key.to_s}External".to_sym, value) if @parent_user
        #   end
        # elsif @parent_user.id == id
        #   @parent_project.set(key, value) if @parent_project
        #   @parent_user.set(key, value) if @parent_user
        # else
        #   @parent_project.set(key, value) if @parent_project
        # end
      end

      def set_min_end_and_start_date(date_str, value)
        date = Date.parse(date_str)
        if value[:type] == TYPE_ENTRY && value[:hours] > 0
          if @data[:min_end_date]
            @data[:min_end_date] = date.to_time if @data[:min_end_date] < date
          else
            @data[:min_end_date] = date.to_time
          end

          if @data[:min_start_date]
            @data[:min_start_date] = date.to_time if @data[:min_start_date] > date
          else
            @data[:min_start_date] = date.to_time
          end
        end
      end

    end

  end

end
