module RedmineXResources
  module Resources
    class ResourceStore
      attr_reader :store, :data

      ID = 0
      PROJECT = 1
      USER = 2
      OTHER_USERS_GROUP_ID = 1000000
      UNASSIGNED_USER = -1
      ASSIGNED_TO_ID = 2

      def initialize
        @store = {}
        @data = {}
      end

      def add_value(issue_arr, external, date, value)
        id = issue_arr[ID].class == Integer ? "i#{issue_arr[ID]}" : issue_arr[ID]
        create_new_item(issue_arr, external) unless @store[id]
        @store[id].set_value(date, value)
      end

      def add(issue_arr, external, key, value)
        id = issue_arr[ID].class == Integer ? "i#{issue_arr[ID]}" : issue_arr[ID]
        create_new_item(issue_arr, external) unless @store[id]

        if key == :spentTotal
          @store[id].set_time_entry(issue_arr[ASSIGNED_TO_ID], value)
        elsif key == :highEstimation || key == :lowEstimation
          @store[id].set_boolean(key, value)
        else
          @store[id].set_number(key, value)
        end
      end

      def get_all
        @data
      end

      def create_new_item(issue_arr, external, type='issue')
        if type == 'issue'
          id = issue_arr[ID].class == Integer ? "i#{issue_arr[ID]}" : issue_arr[ID]
        elsif type == 'user' || type == 'group'
          id = "u#{issue_arr[ID]}"
        else
          id = issue_arr[ID]
        end

        project_id = issue_arr[PROJECT]
        user_id = issue_arr[USER].class == Integer ? "u#{issue_arr[USER]}" : issue_arr[USER]

        @store[id] = ResourceItem.new({ type: type, external: external, id: id })
        @data[id] = @store[id].data

        @store[id].parent_project = @store[project_id] ? @store[project_id] : create_parent_project(project_id)

        if type == 'issue' && user_id.nil?
          @store[id].parent_user = @store["u#{UNASSIGNED_USER}"] ? @store["u#{UNASSIGNED_USER}"] : create_parent_user(UNASSIGNED_USER)
        elsif type == 'user' && id == "u#{UNASSIGNED_USER}"
          @store[id].parent_user = nil
        elsif type == 'user' && user_id.nil?
          @store[id].parent_user = @store["u#{OTHER_USERS_GROUP_ID}"] ? @store["u#{OTHER_USERS_GROUP_ID}"] : create_parent_user(OTHER_USERS_GROUP_ID)
        else
          @store[id].parent_user = @store[user_id] ? @store[user_id] : create_parent_user(issue_arr[USER])
        end
        @store[id]
      end

      def create_parent_project(id)
        return nil unless id
        project = Project.where(id: id).pluck(:id, :parent_id)[0]
        create_new_item(project, false, 'project')
      end

      def create_parent_user(id)
        return nil unless id

        if id == OTHER_USERS_GROUP_ID
          return create_new_item([OTHER_USERS_GROUP_ID, nil, nil], false, 'group')
        elsif id == UNASSIGNED_USER
          return create_new_item([UNASSIGNED_USER, nil, nil], false, 'user')
        end

        user = Principal.find(id)
        return nil unless user

        parent_items = user.try(:groups).try(:pluck, :id)
        parent = user.type == 'Group' ? nil : OTHER_USERS_GROUP_ID
        if parent_items && parent_items.length > 0
            parent = parent_items.min
        end
        create_new_item([user.id, nil, parent], false, user.class.to_s.downcase)
      end
    end

  end
end