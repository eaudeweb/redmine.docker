# Collects info about project, issues, links (relations) and versions from DB
module RedmineXResources
  module Helpers
    module DataHelper
      AREL = RedmineXAssets::Helpers::ArelFunctionsHelper
      # Collects info about all projects given, including subproject, issues, subissues, links and versions
      # @param projects [Array] of Project ActiveRecord objects
      # @param options [Hash] - now only for "global" options which states if global or project gantt is rendered
      # @return [Array] of Hashes of all items in format readable for dhtmlx Gantt component
      def projects_items(projects, options, user_list)
        projects_items = []
        link_items = []
        version_items = []
        versions = Version.arel_table

        projects.each do |project|
          if project.parent
            hasParent = check_parent(projects, project)
          end
          projects_items << project_item_values(project, hasParent)

          issues = issues_query(project, options[:show_closed_issues], user_list)
          projects_items += issue_item_values(issues, project_issues_readonly?(project))

          link_items += issue_relations(project, options[:show_closed_issues]).map { |relation| link_item_values(relation) }

          # Get project's versions
          version_items += project.versions.map { |version| version_item_values(version, project) }

          # Get other versions, which are shared with this project
          version_items +=
            project
            .shared_versions
            .where(versions[:id].not_in(project.versions.pluck(:id)))
            .map { |version| version_item_values(version, project, shared: true) }
        end

        min_date = projects_min_date(projects, options[:show_closed_issues])
        issues_external = issues_query_external(options[:show_closed_issues], user_list, projects, min_date)
        external_issues_items = external_issue_item_values(issues_external, min_date)

        {
          data: projects_items + version_items,
          links: link_items,
        }
      end

      def self.project_items_select(projects)
        projects_items = []
        Project.project_tree(projects) do |project, level|
          projects_items << {
            id: project.id,
            key: project.id,
            label: project.name,
            add_issues: User.current.allowed_to?(:add_issues, project),
            level: level,
            parent: project.parent_id
          }
        end
        projects_items
      end

      def projects_min_date(projects, show_closed_issues)
        issues = Issue.arel_table
        issue_statuses = IssueStatus.arel_table

        issue_statuses_join = issues.join(issue_statuses).on(issue_statuses[:id].eq(issues[:status_id])).join_sources

        if show_closed_issues
          Issue.visible
               .where(issues[:project_id].in(projects.pluck(:id)))
               .minimum(:start_date)
        else
          Issue.visible
               .joins(issue_statuses_join)
               .where(issue_statuses[:is_closed].eq(false))
               .where(issues[:project_id].in(projects.pluck(:id)))
               .minimum(:start_date)
        end
      end

      def issues_query(project, show_closed_issues, user_list)
        issues = Issue.arel_table
        issues_children = Issue.arel_table.alias('issues_children')
        time_entries = TimeEntry.arel_table
        assignees = User.arel_table.alias('assignees')
        authors = User.arel_table.alias('authors')
        issue_statuses = IssueStatus.arel_table
        enumerations = Enumeration.arel_table

        visible_issues = nil
        if show_closed_issues
          visible_issues = project.issues.visible
        else
          visible_issues = project.issues.visible.where(issue_statuses[:is_closed].eq(false))
        end

        issues_children_join = issues.join(issues_children, Arel::Nodes::OuterJoin).on(issues_children[:parent_id].eq(issues[:id])).join_sources
        time_entries_join = issues.join(time_entries, Arel::Nodes::OuterJoin).on(time_entries[:issue_id].eq(issues[:id])).join_sources
        assignees_join = issues.join(assignees, Arel::Nodes::OuterJoin).on(assignees[:id].eq(issues[:assigned_to_id])).join_sources
        authors_join = issues.join(authors, Arel::Nodes::OuterJoin).on(authors[:id].eq(issues[:author_id])).join_sources
        issue_statuses_join = issues.join(issue_statuses).on(issue_statuses[:id].eq(issues[:status_id])).join_sources
        enumerations_join = issues.join(enumerations).on(enumerations[:id].eq(issues[:priority_id])).join_sources

        issue_in_user_list = AREL.arel_db_in(issues[:assigned_to_id], user_list).or(issues[:assigned_to_id].eq(nil))

        issue_id = AREL.arel_db_concatenation('i', issues[:id])
        start_date_condition_today = AREL.arel_db_if(issues[:start_date].eq(nil), Date.today, issues[:start_date])
        closed_on_condition = AREL.arel_db_if(issues[:closed_on].eq(nil), start_date_condition_today, issues[:closed_on])
        due_date_condition = AREL.arel_db_if(issues[:due_date].eq(nil), closed_on_condition, issues[:due_date])
        start_date_condition = AREL.arel_db_if(issues[:start_date].eq(nil), due_date_condition, issues[:start_date])

        fixed_version_id_condition = AREL.arel_db_if(
          issues[:fixed_version_id].eq(nil),
          AREL.arel_db_cast(issues[:project_id], 'CHAR(20)'),
          AREL.arel_db_concatenation('m', issues[:fixed_version_id], '-', issues[:project_id])
        )
        parent_id_condition = AREL.arel_db_if(
          issues[:parent_id].eq(nil),
          fixed_version_id_condition,
          AREL.arel_db_concatenation('i', issues[:parent_id])
        )

        done_ratio = AREL.arel_db_division(issues[:done_ratio], Arel::Nodes::SqlLiteral.new('100.0'))
        due_date_text = AREL.arel_db_if(
          issues[:due_date].eq(nil),
          Arel::Nodes::SqlLiteral.new('\'N/A\''),
          AREL.arel_db_cast(issues[:due_date], 'CHAR(30)')
        )

        estimated_hours = AREL.arel_db_if(
          issues[:estimated_hours].eq(nil),
          Arel::Nodes::SqlLiteral.new('0'),
          issues[:estimated_hours]
        )

        time_entries_condition = time_entries.where(time_entries[:issue_id].eq(issues[:id])).project(time_entries[:hours].sum)
        time_entries_hours = AREL.arel_db_if(
          Arel::Nodes::Equality.new(time_entries_condition, nil),
          Arel::Nodes::SqlLiteral.new('0'),
          time_entries_condition
        )

        # time_entries_hours = AREL.arel_db_if(
        #   time_entries[:hours].sum.eq(nil),
        #   Arel::Nodes::SqlLiteral.new('0'),
        #   time_entries[:hours].sum
        # )

        assignees_id = AREL.arel_db_if(
          assignees[:id].eq(nil),
          Arel::Nodes::SqlLiteral.new('-1'),
          assignees[:id]
        )
        assignees_name = AREL.arel_db_if(
          assignees[:firstname].eq(nil).and(assignees[:lastname].eq(nil)),
          Arel::Nodes::SqlLiteral.new('\'N/A\''),
          AREL.arel_db_concatenation(assignees[:firstname], ' ', assignees[:lastname])
        )

        authors_id = AREL.arel_db_if(
          authors[:id].eq(nil),
          Arel::Nodes::SqlLiteral.new('-2'),
          authors[:id]
        )
        authors_name = AREL.arel_db_if(
          authors[:firstname].eq(nil).and(authors[:lastname].eq(nil)),
          Arel::Nodes::SqlLiteral.new('\'N/A\''),
          AREL.arel_db_concatenation(authors[:firstname], ' ', authors[:lastname])
        )

        issue_has_children = issues_children[:parent_id].count

        visible_issues
        .where(issue_in_user_list)
        .joins(assignees_join, authors_join, issue_statuses_join, enumerations_join, issues_children_join)
        .group(:id, assignees[:id], assignees[:firstname], assignees[:lastname], authors[:id], authors[:firstname], authors[:lastname], issue_statuses[:name], enumerations[:id], enumerations[:position_name], enumerations[:position])
        .pluck(
          issue_id,
          issues[:project_id],
          issues[:subject],
          start_date_condition,
          due_date_condition,
          done_ratio,
          parent_id_condition,
          issues[:closed_on],
          due_date_text,
          estimated_hours,
          time_entries_hours,
          assignees_id,
          assignees_name,
          authors_name,
          authors_id,
          issue_statuses[:name],
          enumerations[:position_name],
          enumerations[:id],
          enumerations[:position],
          issue_has_children
        )
      end

      def issues_query_external(show_closed_issues, user_list, projects, min_date)
        issues = Issue.arel_table
        issue_statuses = IssueStatus.arel_table
        time_entries = TimeEntry.arel_table
        assignees = User.arel_table.alias('assignees')

        projects_list = projects.map { |project| project.id }

        visible_issues = nil
        if show_closed_issues
          visible_issues = Issue.visible
        else
          visible_issues = Issue.visible.where(issue_statuses[:is_closed].eq(false))
        end

        issue_statuses_join = issues.join(issue_statuses).on(issue_statuses[:id].eq(issues[:status_id])).join_sources
        time_entries_join = issues.join(time_entries, Arel::Nodes::OuterJoin).on(time_entries[:issue_id].eq(issues[:id])).join_sources
        assignees_join = issues.join(assignees, Arel::Nodes::OuterJoin).on(assignees[:id].eq(issues[:assigned_to_id])).join_sources

        start_date_condition_today = AREL.arel_db_if(issues[:start_date].eq(nil), Date.today, issues[:start_date])
        closed_on_condition = AREL.arel_db_if(issues[:closed_on].eq(nil), start_date_condition_today, issues[:closed_on])
        due_date_condition = AREL.arel_db_if(issues[:due_date].eq(nil), closed_on_condition, issues[:due_date])
        start_date_condition = AREL.arel_db_if(issues[:start_date].eq(nil), due_date_condition, issues[:start_date])

        issues_condition = issues[:assigned_to_id].in(user_list).and(issues[:project_id].not_in(projects_list)).and(due_date_condition.gteq(min_date))

        issue_id = AREL.arel_db_concatenation('i', issues[:id])

        fixed_version_id_condition = AREL.arel_db_if(
          issues[:fixed_version_id].eq(nil),
          AREL.arel_db_cast(issues[:project_id], 'CHAR(20)'),
          AREL.arel_db_concatenation('m', issues[:fixed_version_id], '-', issues[:project_id])
        )

        parent_id_condition = AREL.arel_db_if(
          issues[:parent_id].eq(nil),
          fixed_version_id_condition,
          AREL.arel_db_concatenation('i', issues[:parent_id])
        )

        estimated_hours = AREL.arel_db_if(
          issues[:estimated_hours].eq(nil),
          Arel::Nodes::SqlLiteral.new('0'),
          issues[:estimated_hours]
        )

          time_entries_hours = AREL.arel_db_if(
            time_entries[:hours].sum.eq(nil),
            Arel::Nodes::SqlLiteral.new('0'),
            time_entries[:hours].sum
          )

        assignees_id = AREL.arel_db_if(
          assignees[:id].eq(nil),
          Arel::Nodes::SqlLiteral.new('-1'),
          assignees[:id]
        )

        visible_issues
        .where(issues_condition)
        .joins(issue_statuses_join, time_entries_join, assignees_join)
        .group(issues[:id], assignees[:id])
        .pluck(
          issue_id,
          start_date_condition,
          due_date_condition,
          parent_id_condition,
          issues[:closed_on],
          estimated_hours,
          time_entries_hours,
          assignees_id
        )
      end

      # Issues info in hash suitable for Gantt component
      # @param issues [Array] array of arrays of issue values loaded from db
      # @param project_issues_readonly [Hash] of issues name_of_issue: readonly_boolean
      # @return [Hash] all info needed for the gantt chart
      def issue_item_values(issues, project_issues_readonly)
        issues.map do |issue|
          {
            id: issue[0],
            readonly: project_issues_readonly,
            type: "task",
            project_id: issue[1],
            text: issue[2],
            start_date: issue[3],
            end_date: issue[4].class == Date ? issue[4] + 1 : Date.parse(issue[4]) + 1,
            progress: issue[5].to_f,
            parent: issue[6],
            open: !to_boolean(issue[7]),
            due_date_text: issue[8],
            estimated_hours: issue[9],
            total_hours: issue[10],
            owner_id: issue[11],
            assigned_to: issue[12],
            author: issue[13],
            author_id: issue[14],
            status: issue[15],
            priority: issue[16],
            priority_id: issue[17],
            priority_position: issue[18],
            uid: issue[0],
            utype: 'task',
            uparent: "u#{issue[11]}",
            external: false,
            has_children: issue[19] > 0 ? true : false
          }
        end
      end

      # Converts value to boolean - rails has error -
      # pluck sometimes returns incorrect data type (e.g. 0 instead of false etc.)
      # @param value [Integer or Boolean] value to be converted
      # @return [Boolean] true, false or nil (if conversion is not possible)
      def to_boolean(value)
        case value
        when true, 1 then true
        when false, 0 then false
        else
          nil
        end
      end

      def external_issue_item_values(issues, min_date)
        issues.map do |issue|
          {
            id: issue[0],
            readonly: true,
            type: "task",
            start_date: min_date,
            end_date: min_date + 1,
            parent: issue[3],
            open: issue[4].nil?,
            estimated_hours: issue[5],
            total_hours: issue[6],
            owner_id: issue[7],
            uid: issue[0],
            utype: 'task',
            ustart_date: issue[1],
            uend_date: issue[2].class == Date ? issue[2] + 1 : Date.parse(issue[2]) + 1,
            uparent: "u#{issue[7]}",
            external: true
          }
        end
      end

      def project_issues_readonly?(project)
        user = User.current

        if user.admin
          false
        elsif user.allowed_to?(:edit_issues, project)
          false
        elsif user.allowed_to?(:edit_own_issues, project)
          issue.assigned_to == user.id ? false : true
        else
          true
        end
      end

      # Info about single version (milestone)
      # @param version [Object] ActiveRecord Version object
      # @param project [Object] ActiveRecord Project object, where this version will be
      #                         rendered - used with shared versions only
      # @param options [Hash] options hash, shared: true will create shared version data
      # @return [Hash] all info needed for the gantt chart
      def version_item_values(version, project, options = {})
        {
          id: "m#{version.id}-#{project.id}",
          project_id: options[:shared] ? project.id : version.project_id,
          owner_project_id: version.project_id,
          readonly: version_item_readonly(version),
          type: 'milestone',
          text: version.name,
          description: version.description,
          start_date: version_item_effective_date(version),
          parent: options[:shared] ? project.id : version.project_id,
          open: version.status == 'open' || version.status == 'locked' ? true : false,
          shared: version.sharing == 'none' ? false : true,
          uid: "m#{version.id}",
          utype: 'milestone'
        }
      end

      # Date of version
      # @param version [Object] ActiveRecord Version object
      # @return [Date] of version (effective date of created on)
      def version_item_effective_date(version)
        if version.effective_date
          version.effective_date
        else
          version.created_on
        end
      end

      # Should be version read only?
      # @param version [Object] ActiveRecord Version object
      # @return [Boolean]
      def version_item_readonly(version)
        user = User.current
        project = Project.find(version.project_id)
        !user.allowed_to?(:manage_versions, project)
      end

      # Should be issue read only?
      # @param version [Object] ActiveRecord Issue object
      # @return [Boolean]
      def issue_item_readonly(issue)
        user = User.current
        project = Project.find(issue.project_id)

        if user.admin
          false
        elsif user.allowed_to?(:edit_issues, project)
          false
        elsif user.allowed_to?(:edit_own_issues, project)
          issue.assigned_to == user.id ? false : true
        else
          true
        end
      end

      # Returns Due Date of issue - in case due date is not filled in, we use other dates to set issue due date
      # Dates are increased by one day beacuse Gantt does not include due date to the duration of the task
      # @param issue [Object] ActiveRecord Issue object
      # @return [Date] due date of issue
      def issue_item_due_date(issue)
        if issue.due_date
          issue.due_date + 1.day
        elsif issue.closed_on
          issue.closed_on + 1.day
        else
          issue.start_date ? issue.start_date + 1.day : Date.today + 1.day
        end
      end

      # Returns parent of the issue - in case the issue is part of version, the parent should be this version
      # Id of parent has prefix 'm' or 'i' because Gantt doesn't distinguish between issues, projects or versions
      # and requires unique id
      # @param issue [Object] ActiveRecord Issue object
      # @return [String] id of the parent
      def issue_item_parent(issue)
        if issue.parent_id
          "i#{issue.parent_id}"
        elsif issue.fixed_version_id
          "m#{issue.fixed_version_id}"
        else
          issue.project_id
        end
      end

      # Calculates duration of the issue in days based on due date or other date used as a due date
      # @param issue [Object] ActiveRecord Issue object
      # @return [Integer] duration in days
      def issue_item_duration(issue)
        return 1 unless issue.start_date
        if issue.closed_on
          (issue.closed_on.to_date - issue.start_date).to_i + 1
        elsif issue.due_date
          (issue.due_date - issue.start_date).to_i + 1
        elsif (Date.today - issue.start_date) >= 1
          (Date.today - issue.start_date).to_i + 1
        else
          1
        end
      end

      # Finds user related to issue (assigned to, created by)
      # @param id [Integer] id of the user in DB
      # @return [String] name of user or N/A message
      def issue_item_related_user(id)
        user = User.find(id)
        "#{user.firstname} #{user.lastname}"
      rescue
        l(:not_available, scope: :redmine_x_gantt)
      end

      # Info about single project
      # @param project [Object] ActiveRecord Project object
      # @return [Hash] all info needed for the gantt chart
      def project_item_values(project, hasParent)
        {
          id: project.id,
          readonly: true,
          type: "project",
          text: "#{l(:label_project)} ##{project.id}: #{project.name}",
          name: project.name,
          start_date: project.start_date || project.created_on.to_date,
          progress: project.completed_percent(include_subprojects: true) / 100.0,
          parent: hasParent ? project.parent_id : nil,
          open: project.active?,
          '$open': false,
          #start_date_text: format_date(project.start_date),
          #due_date_text: format_date(project_item_due_date(project)),
          estimated_hours: project_item_estimated_hours(project),
          total_hours: project_item_total_hours(project),
          uid: project.id,
          utype: 'project'
        }
      end

      # Total hours spent on a project
      # @param project [Object] ActiveRecord Project object
      # @return [Float] hours spent on the project
      def project_item_total_hours(project)
        condition = project.project_condition(true)
        TimeEntry.visible.where(condition).sum(:hours).to_f
      end

      # Total hours estimated to be spent on a project
      # @param project [Object] ActiveRecord Project object
      # @return [Float] hours estimated to be spent on the project
      def project_item_estimated_hours(project)
        condition = project.project_condition(true)
        Issue.visible.where(condition).sum(:estimated_hours).to_f
      end

      # Returns project due date based on the due date of the last issue
      # @param project [Object] ActiveRecord Project object
      # @return [Date] due date of the project
      def project_item_due_date(project)
        condition = project.project_condition(true)
        due_date = Date.new
        Issue.visible.where(condition).each do |issue|
          issue_due_date = issue.start_date + issue_item_duration(issue) - 1
          due_date = issue_due_date > due_date ? issue_due_date : due_date
        end

        due_date
      end

      # Returns all links in a project (relations between all issues)
      # @param project_condition [String] SQL condition defining which projects we should load links for
      # @param global [show_closed_issues] - states if closed issues will be rendered or not
      #   (=> load or not relations of these issues)
      # @return [Array] of relations (links)
      def issue_relations(project, show_closed_issues)
        issues = Issue.arel_table
        issue_statuses = IssueStatus.arel_table
        issue_relations = IssueRelation.arel_table

        visible_issues = nil
        if show_closed_issues
          visible_issues = project.issues.visible
        else
          visible_issues = project.issues.visible.where(issue_statuses[:is_closed].eq(false))
        end

        issue_statuses_join = issues.join(issue_statuses).on(issue_statuses[:id].eq(issues[:status_id])).join_sources
        all_issues = visible_issues.joins(issue_statuses_join).select(:id).arel
        link_id_in_all_issues = AREL.arel_db_in(issue_relations[:issue_from_id], all_issues).and(AREL.arel_db_in(issue_relations[:issue_to_id], all_issues))

        IssueRelation.where(
          link_id_in_all_issues
        ).where.not(relation_type: ['duplicates', 'copied_to'])
      end

      # Info about single relation (link)
      # @param issue_relation [Object] ActiveRecord IssueRelation object
      # @return [Hash] all info needed for the gantt chart
      def link_item_values(issue_relation)
        relation_type = translate_relation(issue_relation.relation_type)
        {
          id: issue_relation.id,
          source: "i#{issue_relation.issue_from_id}",
          target: "i#{issue_relation.issue_to_id}",
          type: relation_type[:gantt_type],
          relation_name: relation_type[:name],
          lag: issue_relation.delay || nil,
          created: true
        }
      end

      # Translates redmine relation type to dhtmlx Gantt relation type
      # @param relation_type [String] name of relation valid for redmine
      # @return [String] number (type) of relation valid for Gantt
      def translate_relation(relation_type)
        result = { name: relation_type }
        case relation_type
        when 'precedes'
          result[:gantt_type] = '0'
        when 'finish_to_start'
          result[:gantt_type] = '0'
        when 'blocks'
          result[:gantt_type] = '1'
        when 'start_to_start'
          result[:gantt_type] = '1'
        when 'finish_to_finish'
          result[:gantt_type] = '2'
        when 'start_to_finish'
          result[:gantt_type] = '3'
        end
        result
      end

      def check_parent(projects, project)
        projects.include?(project.parent)
      end
    end
  end
end

#.where(issues_condition).joins(issue_statuses_join, time_entries_join, assignees_join).group(issues[:id], assignees[:id], time_entries[:hours]).pluck(