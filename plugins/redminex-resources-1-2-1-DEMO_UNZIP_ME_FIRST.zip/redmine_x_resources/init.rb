unless Redmine::Plugin.installed?(:redmine_x_assets)
  raise "\n\033[31mRedmineX Resources plugin requires RedmineX Assets plugin, which is part of the RedmineX Resources package.\n" +
        "Please install RedmineX Assets plugin v1.0.1 first.\033[0m"
end

unless Redmine::Plugin.find(:redmine_x_assets).version == '1.0.1'
  raise "\n\033[31mRedmineX Resources plugin requires RedmineX Assets plugin v1.0.1.\n" +
  "Please install the correct version of the RedmineX Assets plugin first.\033[0m"
end

Redmine::Plugin.register :redmine_x_resources do
  name 'RedmineX Resources DEMO'
  author 'Ondřej Svejkovský'
  description 'Resources plugin for Redmine'
  version '1.2.1_DEMO' # Requires RedmineX Assets plugin v1.0.1
  url 'https://www.redmine-x.com'

  settings(partial: 'settings/redmine_x_resources_settings',
           default: {
             hours_per_resource_per_day: 8,
             closed_tasks_on_local_resources: false,
             closed_tasks_on_global_resources: false,
             projects_unselected_on_global_resources: [],
             users_unselected_on_global_resources: []
           })

  project_module :redmine_x_resources do
    permission(:view_redmine_x_resources,
               { redmine_x_resources: [:show] },
               read: true)

    permission(:view_global_redmine_x_resources,
               { redmine_x_resources: [:index] },
               global: true, read: true)
  end

  menu(:top_menu, :redmine_x_resources, { controller: 'redmine_x_resources', action: 'index' },
    caption: :project_menu_item_redmine_x_resources,
    if: proc { |p| User.current.allowed_to_globally?(:view_global_redmine_x_resources) })

  menu(:project_menu, :redmine_x_resources, { controller: 'redmine_x_resources', action: 'show' },
    caption: :project_menu_item_redmine_x_resources, projectino_extension: true, after: :issues,
    if: proc { |p| User.current.allowed_to?(:view_redmine_x_resources, p) })
end


