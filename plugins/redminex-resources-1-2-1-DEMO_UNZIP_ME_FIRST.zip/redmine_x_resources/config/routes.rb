# frozen_string_literal: true

# Plugin's routes
get 'redmine_x_resources', to: 'redmine_x_resources#index'
get 'projects/:id/redmine_x_resources', to: 'redmine_x_resources#show'
get 'redmine_x_resources/help', to: 'redmine_x_resources#help'

namespace :redmine_x_resources_api, defaults: { format: :json }, path: 'redmine_x_resources/api' do
  namespace :v1 do
    resources :data, only: [:index, :show]
    resources :fixed, only: [:index, :create]
    resources :resources, only: [:show]
    post 'resources/issues', to: 'resources#issues'
    post 'resources/issues_and_users', to: 'resources#issues_and_users'
    post 'resources/user_spent_time', to: 'resources#user_spent_time'
  end
end

#get 'polls/:project_id/', to: 'issues#bulk_update_api', defaults: { format: :json }


