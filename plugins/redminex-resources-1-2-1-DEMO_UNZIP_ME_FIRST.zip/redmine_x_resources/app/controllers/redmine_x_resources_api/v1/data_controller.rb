class RedmineXResourcesApi::V1::DataController < ApplicationController
  accept_api_auth :index, :show

  include RedmineXResources::Helpers::DataHelper
  include RedmineXAssets::Helpers::PrioritiesHelper

  # Gantt data global - for all projects
  def index
    unselected_projects = Setting.plugin_redmine_x_resources[:projects_unselected_on_global_resources]
    unselected_projects = [-100] if unselected_projects.nil? || unselected_projects.empty?
    projects = Project.active.visible.where('id NOT IN (?)', unselected_projects)

    unselected_users = Setting.plugin_redmine_x_resources[:users_unselected_on_global_resources]
    unselected_users = [-100] if unselected_users.nil? || unselected_users.empty?

    users = RedmineXResources::Helpers::UsersHelper.user_items(nil, unselected_users)
    user_list = users.map { |v| v[:id] }

    items = projects_items(projects,
                           { show_closed_issues: show_closed_issues?(true) },
                           user_list)
    items[:collections] = {
      users: users,
      priorities: priority_items,
      projects: RedmineXResources::Helpers::DataHelper.project_items_select(projects),
      projects_and_users: [{ projects: projects.pluck(:id) }, { users: user_list }]
    }
    render json: items
  end

  # Gantt data for one project only
  def show
    project = Project.find(params[:id])
    condition = project.project_condition(true)
    projects = Project.where(condition).active.visible
    users = RedmineXResources::Helpers::UsersHelper.user_items(projects.pluck(:id), [])
    user_list = users.map { |v| v[:id] }
    items = projects_items(projects, { show_closed_issues: show_closed_issues?(false) }, user_list)
    items[:collections] = {
      users: users,
      priorities: priority_items,
      projects: RedmineXResources::Helpers::DataHelper.project_items_select(projects),
      projects_and_users: [{ projects: projects.pluck(:id) }, { users: user_list }]
    }
    render json: items
  end

  private

  def show_closed_issues?(global)
    if global
      return true if Setting.plugin_redmine_x_resources[:closed_tasks_on_global_resources]
    else
      return true if Setting.plugin_redmine_x_resources[:closed_tasks_on_local_resources]
    end
    false
  end

  def add_parent_projects(project_list)
    parent_projects = []
    project_list.each do |id|
      current_project = Project.find(id)
      while current_project.parent
        parent_projects << current_project.parent_id
        current_project = current_project.parent
      end
    end
    project_list + parent_projects
  end
end
