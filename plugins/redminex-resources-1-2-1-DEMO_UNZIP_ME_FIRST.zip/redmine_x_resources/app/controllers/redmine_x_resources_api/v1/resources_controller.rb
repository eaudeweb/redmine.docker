class RedmineXResourcesApi::V1::ResourcesController < ApplicationController
    accept_api_auth :show, :issues, :issues_and_users, :user_spent_time

    include RedmineXResources::Helpers::IssueResourcesHelper

    def show
      issue = Issue.find(params[:id])
      render json: single_issue_resources(issue)
    end

    def issues
      ids = issues_params[:issues].map { |id| id.to_s.start_with?('i') ? id[1..-1] : id }
      issues = Issue.where('id IN (?)', ids)
      render json: issue_resources(issues)
    end

    def issues_and_users
        resources = projects_and_users_resources(
          issues_and_users_params,
          show_closed_issues?(issues_and_users_params[:global])
        )
        render json: resources
    end

    def user_spent_time
      hours = spent_time(
        user_spent_time_params[:user_id],
        user_spent_time_params[:issues]
      )

      render json: {
        user_id: user_spent_time_params[:user_id],
        issues: user_spent_time_params[:issues],
        hours: hours
      }
    end

    private

    def issues_params
      params.permit(:key, issues: [])
    end

    def issues_and_users_params
      params.require(:projects_and_users).permit(:global, projects: [], users: [])
    end

    def user_spent_time_params
      params.require(:user_spent_time).permit(:user_id, issues: [])
    end

    def show_closed_issues?(global)
        if global
          return true if Setting.plugin_redmine_x_resources[:closed_tasks_on_global_resources]
        else
          return true if Setting.plugin_redmine_x_resources[:closed_tasks_on_local_resources]
        end
        false
      end
end