class CreateResourcesFixedValues < ActiveRecord::Migration[5.2]
  def change
    create_table :resources_fixed_values do |t|
      t.float :hours, null: false
      t.date :date, null: false
      t.integer :author_id, null: false
      t.references :issue

      t.timestamps null: false
    end
    add_index :resources_fixed_values, :date
  end
end
