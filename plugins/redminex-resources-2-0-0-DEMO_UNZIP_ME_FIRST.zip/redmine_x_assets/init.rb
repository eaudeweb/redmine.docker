require_dependency 'redmine_x_assets/patches/issue_patch'
require_dependency 'redmine_x_assets/patches/issue_relation_patch'
require_dependency 'redmine_x_assets/patches/issues_controller_patch'

Redmine::Plugin.register :redmine_x_assets do
  name 'RedmineX Assets'
  author 'Ondřej Svejkovský'
  description 'Plugin with common backend and frontend assets for RedmineX Gantt and Resources'
  version '2.0.0'
  url 'https://www.redmine-x.com'

  settings(
    default: { 'default_holidays_inherit_days': 1 },
    partial: 'settings/redmine_x_assets_settings'
  )
end
