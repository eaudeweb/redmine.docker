# Model which stores preloaded country (and state) holidays
class RxCountryHoliday < ActiveRecord::Base
  # Cached values are stored in @@states, @@holidays, @@years variables
  # which are populated when 1st query to db is sent
  @@states = {}
  @@holidays = {}
  @@years = nil

  # Loads (and caches) all countries from db (for which we have holiday info)
  # @return [Array] of arrays - for each country name of the country and iso code is returned
  def self.countries
    @@countries ||=
      RxCountryHoliday
      .group(:country_iso, :country)
      .pluck(:country, :country_iso)
  end

  # Loads (and caches) all states for particular country from db
  # @param country_iso [String] iso code of country for which we want to load states for
  # @return [Array] of arrays - for each state name of the state and iso code is returned
  def self.states(country_iso)
    @@states[country_iso] ||=
      RxCountryHoliday
      .where(country_iso: country_iso)
      .where('state IS NOT NULL')
      .group(:state_iso, :state)
      .pluck(:state, :state_iso)
  end

  # Loads (and caches) years from db for which we have holiday info
  # @return [Array] of integers - years in yyyy format (e.g. 2021)
  def self.holiday_years
    @@years ||=
      RxCountryHoliday
      .pluck(:year)
      .uniq
  end

  # Returns (and caches) holiday info for one particular country (and state)
  # @param country_iso [String] iso code of country for which we want to load holidays for
  # @param year [Integer] year in yyyy format for which we want to load holidays for
  # @param state_iso [String] iso code of state for which we want to load holidays for
  # @return [Array] of arrays - for each holiday name (with date and name) and
  #                             date of the holiday is returned
  def self.holidays(country_iso, year, state_iso=nil)
    if state_iso
      @@holidays["#{country_iso}_#{year}_#{state_iso}"] ||=
        self.holidays_with_state(country_iso, state_iso, year)
    else
      @@holidays["#{country_iso}_#{year}"] ||=
        self.holidays_without_state(country_iso, year)
    end
  end

  # Loads holiday info from db for one particular country which has states
  # @param country_iso [String] iso code of country for which we want to return holidays for
  # @param state_iso [String] iso code of state for which we want to return holidays for
  # @param year [Integer] year in yyyy format for which we want to return holidays for
  # @return [Array] of arrays - for each holiday name (with date and name) and
  #                             date of the holiday is returned
  def self.holidays_with_state(country_iso, state_iso, year)
    RxCountryHoliday
    .where(country_iso: country_iso)
    .where(year: year)
    .where("holiday_type = 'national' OR state_iso = ?", state_iso)
    .pluck(:name, :date)
  end

  #RxCountryHoliday.where(country_iso: 'CZ').where(year: 2022).where('holiday_type = "national" OR state_iso = ?', 'AA').group(:date).pluck("GROUP_CONCAT(DISTINCT name SEPARATOR ', ')", :date)

  # Loads holiday info from db for one particular country which has no states
  # @param country_iso [String] iso code of country for which we want to load holidays for
  # @param year [Integer] year in yyyy format for which we want to load holidays for
  # @return [Array] of arrays - for each holiday name (with date and name) and
  #                             date of the holiday is returned
  def self.holidays_without_state(country_iso, year)
    RxCountryHoliday
    .where(country_iso: country_iso, holiday_type: 'national')
    .where(year: year)
    .pluck(:name, :date)
  end
end