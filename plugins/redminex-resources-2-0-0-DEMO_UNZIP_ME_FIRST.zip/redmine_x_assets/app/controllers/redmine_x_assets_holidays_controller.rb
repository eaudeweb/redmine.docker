class RedmineXAssetsHolidaysController < ApplicationController
  def get
    @h_helper = @h_helper || RedmineXAssets::Helpers::HolidayHelper
    if params[:state_iso]
      render json: {
        country_iso: params[:country_iso],
        holidays: @h_helper.holiday_options(params[:country_iso], params[:state_iso])
      }
    else
      states = ActionController::Base.helpers.options_for_select(
        RxCountryHoliday.states(params[:country_iso])
      )
      if states.empty?
        holidays = @h_helper.holiday_options(params[:country_iso])
      else
        holidays = @h_helper.holiday_options(
          params[:country_iso],
          RxCountryHoliday.states(params[:country_iso]).first[0]
        )
      end
      render json: {
        country_iso: params[:country_iso],
        states: states,
        holidays: holidays
      }
    end
  end

  def create
    @user = Principal.find(params[:user_id])
    Setting.plugin_redmine_x_assets["#{@user.id}_holidays_country".to_sym] = ''
    Setting.plugin_redmine_x_assets["#{@user.id}_holidays_inherit_days".to_sym] = 1

    @user_options =
      RedmineXAssets::Helpers::HolidayHelper.groups_and_users

    respond_to do |format|
      format.js { render layout: false }
    end
  end

  def destroy
    @user = Principal.find(params[:user_id])
    settings = Setting.plugin_redmine_x_assets
    settings.each { |k, v| settings.delete(k) if k.to_s.start_with?("#{@user.id}_holidays")}
    Setting.plugin_redmine_x_assets = settings

    @user_options =
      RedmineXAssets::Helpers::HolidayHelper.groups_and_users

    respond_to do |format|
      format.js { render layout: false }
    end
  end
end