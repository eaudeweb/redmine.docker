module RedmineXAssets
  module Helpers
    # Module which prepares calendar data for gantt/resources frontend and backend
    module CalendarsHelper
      include Redmine::I18n

      # Returns calendars (i.e. list of holidays + working days) for the given users
      # @param users [Array] - array of User ActiveRecord objects for which we want the calendars for
      # @return [Array] - array of hashes with requested calendars
      def calendars(users)
        @settings = Setting.plugin_redmine_x_assets
        calendars = [calendar('default')]
        users.each do |user|
          calendars << calendar(user[:id]) if gantt_user_holiday_settings?(user[:id])
        end
        calendars
      end

      # Returns true if there are valid holiday settings for user or his/her group
      # @param key [Integer] - id of user or group for which we want to find out if settings exist
      # @return [Boolean] - true if settings exist for the given user id
      def gantt_user_holiday_settings?(key)
        return true if @settings["#{key}_holidays_country"]
        return true if personal_holiday_issues_query(key).count > 0

        begin
          principal = Principal.find(key)
        rescue ActiveRecord::RecordNotFound
          return false
        end

        unless principal.type.start_with?('Group')
          principal.groups.each do |group|
            return true if @settings["#{group.id}_holidays_country"]
            return true if personal_holiday_issues_query(group.id).count > 0
          end
        end

        return false
      end

      # Prepare calendar for one given user or group
      # @param key [Integer] - id of user or group for which we want the calendar for
      # @return [Hash] - hash with calendar data (list of holidays + working days) for the given user
      def calendar(key)
        precalculate_holiday_data(key)
        @calendars ||= {}

        @calendars[key] ||= {
          key: key,
          holidays: @personal_holidays +
            @holiday_settings.map { |h| { from: h[1], name: "public###{h[0]}"} },
          workdays: @work_days
        }
      end

      # Returns valid personal holiday settings for the given user or group
      # (including inheritance mechanism - user inherits settings from group)
      # @param key [Integer] - id of user or group for which we want the holiday settings for
      # @return [Array] - array with holiday dates for the given user or superior group
      def personal_holiday_settings(key)
        holidays = personal_holidays(key)
        # return holidays if holidays.any?

        begin
          principal = Principal.find(key)
        rescue ActiveRecord::RecordNotFound
          return holidays
        end

        unless principal.type.start_with?('Group')
          principal.groups.each do |group|
            holidays += personal_holidays(group.id)
            return holidays if holidays.any?
          end
        end

        holidays
      end

      # Returns list of personal holidays for the given user
      # @param key [Integer] - id of user or group for which we want the personal holidays for
      # @return [Array] - array with personal holidays, every item contains one holiday
      #                   time span (from, to, name)
      def personal_holidays(key)
        holiday_issues = personal_holiday_issues_query(key)

        user_name = "N/A"
        begin
          principal = Principal.find(key)
          if principal.name.strip.length > 0
            user_name = principal.name
          end
        rescue ActiveRecord::RecordNotFound
        end

        holidays = []
        holiday_issues.each do |issue|
          next unless issue.start_date
          due_date = issue.due_date || issue.start_date
          result = { from: issue.start_date, name: "private###{user_name}" }
          result[:to] = due_date + 1 if issue.start_date < due_date
          holidays << result
        end

        holidays
      end

      # Returns array of issues which define personal holidays for the given user
      # @param key [Integer] - id of user or group for which we want the personal holidays for
      # @return [ActiveRecord Object or Array] - array with issues, which define personal holidays
      def personal_holiday_issues_query(key)
        unless @settings['holiday_tracker'] && @settings['holiday_tracker'].length > 0
          return []
        end

        Issue
        .open
        .where(tracker_id: @settings['holiday_tracker'])
        .where(assigned_to_id: key)
      end

      def work_days(key)
        work_days = work_days_data("#{key}_holidays")
        return work_days if work_days.any?

        begin
          principal = Principal.find(key)
        rescue ActiveRecord::RecordNotFound
          return work_days_data('default_holidays')
        end

        unless principal.type.start_with?('Group')
          principal.groups.each do |group|
            work_days = work_days_data("#{group.id}_holidays")
            return work_days if work_days.any?
          end
        end

        return work_days_data('default_holidays')
      end

      # Returns valid work day settings in Redmine format for the given user or group
      # @param key [Integer] - id of user or group for which we want the work day settings for
      # @return [Array] - array with work day settings for the given user or superior group or default
      # def work_day_settings(key)
      #   return user_work_days(key) if user_work_days(key)

      #   begin
      #     principal = Principal.find(key)
      #   rescue ActiveRecord::RecordNotFound
      #     return (default_work_days ? default_work_days : Setting.non_working_week_days)
      #   end

      #   unless principal.type.start_with?('Group')
      #     principal.groups.each do |group|
      #       return user_work_days(group.id) if user_work_days(group.id)
      #     end
      #   end

      #   return (default_work_days ? default_work_days : Setting.non_working_week_days)
      # end

      # Returns default work days settings if available
      # @return [Array or nil] - array with the work day settings or nil if settings is N/A
      # def default_work_days
      #   if @settings["default_holidays_non_working_week_days"]
      #     return @settings["default_holidays_non_working_week_days"]
      #   end
      #   if @settings["default_holidays_inherit_days"]
      #     return Setting.non_working_week_days
      #   end

      #   nil
      # end

      def work_days_data(key)
        work_days = if Redmine::Plugin.installed?(:redmine_x_resources)
                      RedmineXAssets::Helpers::HolidayHelper.work_days_resources(key)
                    else
                      RedmineXAssets::Helpers::HolidayHelper.work_days_gantt(key)
                    end

        return work_days.unshift(work_days.pop) if work_days.any?

        if @settings["#{key}_inherit_days"] || @settings["#{key}_inherit_days".to_sym]
          work_days = RedmineXAssets::Helpers::HolidayHelper.work_days_inherit(key)
          return work_days.unshift(work_days.pop)
        end

        work_days
      end

      # Returns work days settings for the given key if available
      # @param key [Integer] - id of user or group for which we want the calendar for
      # @return [Array or nil] - array with the work day settings or nil if settings is N/A
      # def user_work_days(key)
      #   if @settings["#{key}_holidays_non_working_week_days"]
      #     return @settings["#{key}_holidays_non_working_week_days"]
      #   end
      #   if @settings["#{key}_holidays_inherit_days"]
      #     return Setting.non_working_week_days
      #   end

      #   nil
      # end

      # Returns valid public holiday settings for the given user or group
      # (including inheritance mechanism - user inherits settings from group or uses default settings)
      # @param key [Integer] - id of user or group for which we want the holiday settings for
      # @return [Array] - array with holiday dates for the given user or superior group or default
      def public_holiday_settings(key)
        return selected_public_holidays(key) if @settings["#{key}_holidays_country"]

        begin
          principal = Principal.find(key)
        rescue ActiveRecord::RecordNotFound
          return selected_public_holidays('default')
        end

        unless principal.type.start_with?('Group')
          principal.groups.each do |group|
            return selected_public_holidays(group.id) if @settings["#{group.id}_holidays_country"]
          end
        end

        return selected_public_holidays('default')
      end

      # Prepares array of dates representing public holidays for the given user or group (or default)
      # minus unselected holidays
      # @param key [Integer] - id of user or group for which we want the holiday dates for
      # @return [Array] - array of holiday dates
      def selected_public_holidays(key)
        holiday_settings = @settings["#{key}_holidays_country"]
        return [] if @settings["#{key}_holidays_country"].nil? || @settings["#{key}_holidays_country"].empty?

        holidays = public_holiday_dates(@settings["#{key}_holidays_country"], @settings["#{key}_holidays_state"])
        holidays =
          holidays - @settings["#{key}_holidays_unselected"] if @settings["#{key}_holidays_unselected"]
        holidays
      end

      # Retrieves public holiday dates for the specific country and state
      # @param country_iso [String] - iso code of the country for which we want to obtain the holiday
      #                               dates for
      # @param state_iso [String] - iso code of the state for which we want to obtain the holiday
      #                             dates for (if there are state holidays in the given country)
      # @return [Array] - array of holiday dates
      def public_holiday_dates(country_iso, state_iso)
        holidays = []
        RxCountryHoliday.holiday_years.each do |year|
          holidays += RxCountryHoliday.holidays(country_iso, year, state_iso)
        end
        holidays
      end

      # Calculates and caches holiday data for successor_soonest_start and reschedule_on methods in
      # issue_relation.rb and issue.rb
      # @param key [Integer] - id of user or group for which we want the holiday dates for
      # @return [nil] - nothing is returned
      def precalculate_holiday_data(key)
        @settings = Setting.plugin_redmine_x_assets
        @work_days = work_days(key)
        @holiday_settings = public_holiday_settings(key)
        @personal_holidays = personal_holiday_settings(key)
        @holiday_union = holiday_union
      end

      # Returns number of working days and hours between two dates (from included, to excluded)
      # @param from [Date] - start date of the interval - this date is included in the interval
      # @param to [Date] - end date of the interval - this date is not included in the interval
      # @return {Hash} - with two keys: days = number of working days between the given dates
      #                                 hours = number of working hours between the given dates (only for resources)
      def working_days_with_calendars(from, to)
        days = (to - from).to_i
        work_days_sum = @work_days.map { |n| n > 0 ? 1 : 0 }.sum
        if days > 0
          weeks = days / 7
          result_days = weeks * work_days_sum
          result_hours = weeks * @work_days.sum

          days_left = days - weeks * 7
          wday = from.wday
          days_left.times do |i|
            if @work_days[(wday + i) % 7] > 0
              result_days += 1
              result_hours += @work_days[(wday + i) % 7]
            end
          end
          holidays = check_holidays(from - 1, to)
          result_days -= holidays[:days]
          result_hours -= holidays[:hours]
          { days: result_days, hours: result_hours }
        else
          { days: 0, hours: 0 }
        end
      end

      # Returns date which is x (given) working days after the given date
      # @param date {Date} - start date from which we want to start the computation (excluded)
      # @param working_days {Integer} - number of working days from the start date
      # @return {Date} - end date (excluded) of the period defined by the given date and the given
      #                  number of the working days
      def add_working_days_with_calendars(date, working_days)
        work_days_sum = @work_days.map { |n| n > 0 ? 1 : 0 }.sum
        if working_days > 0
          weeks = working_days / work_days_sum
          result = weeks * 7
          days_left = working_days - weeks * work_days_sum
          wday = date.wday
          while days_left > 0
            wday += 1
            if @work_days[wday % 7] > 0
              days_left -= 1
            end
            result += 1
          end
          result_date = next_working_date_with_calendars(date + result)
          holidays = check_holidays(date, date + result + 1)[:days]
          holidays.times do
            result_date = next_working_date_with_calendars(result_date + 1, true)
          end
          result_date
        else
          date
        end
      end

      # Counts number of holidays between two dates (both excluded)
      # @param start_date {Date} - start date of the period for which we want to get number of holidays
      # @param end_date {Date} - end date of the period for which we want to get number of holidays
      # @return {Hash} - with two keys: days = number of holidays between the given dates on work days
      #                                 hours = number of work hours lost by those holidays (only for resources)
      def check_holidays(start_date, end_date)
        return 0 if start_date >= end_date - 1

        days = 0
        hours = 0
        @holiday_union.each do |holidays|
          current_date = holidays[:from]
          holiday_end = holidays[:to] ? holidays[:to] - 1 : holidays[:from]

          while current_date <= holiday_end
            if start_date < current_date && current_date < end_date && @work_days[current_date.wday] > 0
              days += 1
              hours += @work_days[current_date.wday]
            end
            current_date += 1
          end
        end

        { days: days, hours: hours }
      end

      # Decides if the given date is a working day or not
      # @param date {Date} - date for which we want to find out if it is a working day
      # @param include_holidays {Boolean} - true if we want to take into account public
      #                                     and personal holidays
      # @return {Boolean} - true if the given date is a working day
      def working_day?(date, include_holidays)
        result = true
        #return false if include_holidays && @holiday_settings.detect { |h| h[1] == date.to_s }

        if include_holidays
          @holiday_union.each do |holidays|
            holidays_end = holidays[:to] ? holidays[:to] - 1 : holidays[:from]
            return false if holidays[:from] <= date && date <= holidays_end
          end
        end

        return false if @work_days[date.wday].zero?

        return true
      end

      # Prepares union of personal and public holidays for computation of the earliest start date
      # @return {Array} - array of hashes, each with :from and :to keys denoting start and end of 
      #                   holidays period
      def holiday_union
        holidays_union = []
        holidays_flat = []

        @personal_holidays.each do |holiday|
          holidays_flat << { date: holiday[:from], type: :begin }
          holidays_flat << { date: (holiday[:to] ? holiday[:to] : holiday[:from] + 1), type: :end }
        end

        @holiday_settings.each do |holiday|
          holidays_flat << { date: holiday[1], type: :begin }
          holidays_flat << { date: holiday[1] + 1, type: :end }
        end

        holidays_flat.sort! do |a,b|
          (a[:date] == b[:date]) ? a[:type].to_s <=> b[:type].to_s : a[:date] <=> b[:date]
        end

        counter = 0
        holiday_obj = {}
        holidays_flat.each do |date|
          holiday_obj[:from] = date[:date] if date[:type] == :begin && counter.zero?
          counter += 1 if date[:type] == :begin

          counter -= 1 if date[:type] == :end
          if date[:type] == :end && counter.zero?
            holiday_obj[:to] = date[:date] unless date[:date] + 1 == holiday_obj[:from]
            holidays_union << holiday_obj.dup
            holiday_obj = {}
          end
        end

        holidays_union
      end

      # Returns the date of the first day on or after the given date that is a working day
      # @param date [Date] - date for which we want to find the nearest working day
      # @param include_holidays [Boolean] - should we include or leave out holidays?
      # @return [Date] - date of 1st working day on or after the given date
      def next_working_date_with_calendars(date, include_holidays=false)
        date += 1 while working_day?(date, include_holidays) == false
        date
      end

    # Returns the date of the first day on or before the given date that is a working day
    # @param date [Date] - date for which we want to find the nearest working day
    # @param include_holidays [Boolean] - should we include or leave out holidays?
    # @return [Date] - date of 1st working day on or before the given date
    def previous_working_date_with_calendars(date, include_holidays=false)
      date -= 1 while working_day?(date, include_holidays) == false
      date
    end
    end
  end
end

# def add_working_days_with_calendars(date, working_days)
#   return date if working_days <= 0

#   days = 0
#   current_date = date + 1
#   while days < working_days
#     days += 1 if working_day?(current_date)
#     current_date += 1
#   end

#   current_date += 1 while working_day?(current_date) == false

#   current_date
# end

# def measure(date, working_days)
#   @settings = Setting.plugin_redmine_x_assets
#   @work_days = work_days(12)
#   @holiday_settings = public_holiday_settings(12)
#   @personal_holidays = personal_holidays(12)
#   @holiday_union = holiday_union
#   t = Time.now
#   start_date = add_working_days_with_calendars(date, working_days)
#   time = Time.now - t
#   p "Earliest start date: #{start_date}, time: #{time}"
# end




# def next_working_date(date)
#   date += 1 while working_day?(date) == false
#   date
# end

# # Returns the date of the first day on or after the given date that is a working day
# # @param date [Date] - date for which we want to find the nearest working day
# # @param include_holidays [Boolean] - should we include or leave out holidays?
# # @return [Date] - date of 1st working day on or after the given date
# def next_working_date(date, include_holidays=false)
#   wday = date.wday
#   days = 0
#   days += 1 while @work_days[(wday + days) % 7] == 0 ||
#             (include_holidays && @holiday_settings.include?((date + days).to_s))
#   date + days
# end

# Returns number of holidays, which fall on a work day between two dates
# @param start_date [Date] - start date (excluded) of the interval for which we want to get # of holidays
# @param end_date [Date] - end date (excluded) of the interval for which we want to get # of holidays
# @return [Integer] - number of holidays which fall on a work day

