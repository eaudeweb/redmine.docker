module RedmineXAssets
  module Helpers
    # Module which provides some auxilliary method for displaying
    # and saving holiday settings in Redmine
    module HolidayHelper
      include Redmine::I18n

      # Class variable which temporarily saves assign_to_id of issue, which is being updated
      # When a task is modified, it must be validated before it can be saved to the db. If
      # the assignee of a task changes, the calendar changes, which may mean that the task
      # will need to be moved (if the task is linked to another task using precedes/follows
      # relation). However, the function that validates the task shift has no way of knowing
      # that the owner of the task has been changed, because the change has not yet been written
      # to the database (due to the fact that the task is still being validated). This is what
      # this variable is for.
      @@assigned_to_ids = {}

      # Prepares html string with grouped (by years) options for select element with holidays
      # @param country_iso [String] iso code of country for which we want to prepare holidays for
      # @param state_iso [String] iso code of state for which we want to prepare holidays for
      # @return [String] - html string containing optgroups and options with holidays
      def self.holiday_options(country_iso, state_iso=nil)
        years = RxCountryHoliday.holiday_years
        options = []
        years.each do |year|
          holidays = RxCountryHoliday.holidays(
            country_iso, year,
            state_iso
          ).map { |h| ["#{format_date(h[1])} #{h[0]}", h[1], { class: 'bold-option' }] }
          if block_given?
            holidays_filtered = holidays.filter { |holiday| yield(holiday[1]) }
          else
            holidays_filtered = holidays
          end
          options << [year, holidays_filtered] if holidays_filtered.any?
        end
        ActionController::Base.helpers.grouped_options_for_select(options)
      end

      # Removes holiday settings for one particular user from plugin settings hash from db
      # @param key [String or Integer] - id of the user for whom we want to remove the settings
      # @return [nil] - nothing is returned
      def self.remove_holiday_settings(key)
        settings = Setting.plugin_redmine_x_assets
        settings.each do |key, value| 
          ka = key.split('_')
          next unless ka.length > 2 && ka[0] == key && ka[1] == 'holidays'
          settings.delete(key)
        end
        Setting.plugin_redmine_x_assets = settings
      end

      # Returns work_days settings for settings page
      # @param key [String or Integer] - id of the user for whom we want to remove the settings
      # @param inherit [Boolean] - if true, we prefer Redmine work days setting before assets setting
      # @return [Array] - array of integers of length 7 (1st element is monday, last is sunday), for
      #                   gantt, is is array of 1s and 0s (1 for work day), for resources it is number
      #                   of hours in the specific day (integers 0..24)
      def self.work_days(key, inherit=false)
        settings = Setting.plugin_redmine_x_assets
        work_days = if Redmine::Plugin.installed?(:redmine_x_resources)
                      work_days_resources(key)
                    else
                      work_days_gantt(key)
                    end

        if inherit || work_days.empty?
          work_days = work_days_inherit(key)
        end

        work_days
      end

      # Returns Redmine work days settings
      # @param key [String or Integer] - id of the user for whom we want to remove the settings
      # @return [Array] - array of integers of length 7 (1st element is monday, last is sunday), for
      #                   gantt, is is array of 1s and 0s (1 for work day), for resources it is array
      #                   8s and 0s (as redmine does not have hours setting, we return 8 for work day)
      def self.work_days_inherit(key)
        settings = Setting.plugin_redmine_x_assets
        (1..7).to_a.map do |i|
          if Setting.non_working_week_days.include?(i.to_s)
            0
          else
            if Redmine::Plugin.installed?(:redmine_x_resources)
              hours = settings["#{key}_working_week_hours"]
              hours && hours[i.to_s] ? hours[i.to_s].to_i : 8
            else
              1
            end
          end
        end
      end

      # Returns work_days settings for resources
      # @param key [String or Integer] - id of the user for whom we want to remove the settings
      # @return [Array] - array of integers of length 7 (1st element is monday, last is sunday),
      #                   each element is number of hours in the specific day (integers 0..24)
      def self.work_days_resources(key)
        settings = Setting.plugin_redmine_x_assets
        hours = settings["#{key}_working_week_hours"]
        if hours
          return (1..7).to_a.map do |i|
            hours[i.to_s] ? hours[i.to_s].to_i : 0
          end
        end

        work_days = []
        if settings["#{key}_working_week_days"]
          (1..7).to_a.each do |i|
            work_days << (settings["#{key}_working_week_days"].include?(i.to_s) ? 8 : 0)
          end
        end

        work_days
      end

      # Returns work_days settings for ganttt
      # @param key [String or Integer] - id of the user for whom we want to remove the settings
      # @return [Array] - array of integers of length 7 (1st element is monday, last is sunday),
      #                   each element is either 1 (work day) or zero (weekend)
      def self.work_days_gantt(key)
        settings = Setting.plugin_redmine_x_assets
        work_days = []
        if settings["#{key}_working_week_days"]
          work_days = (1..7).to_a.map do |i|
            settings["#{key}_working_week_days"].include?(i.to_s) ? 1 : 0
          end
          return work_days
        end

        hours = settings["#{key}_working_week_hours"]
        if hours
          work_days = (1..7).to_a.map do |i|
            if hours[i.to_s]
              hours[i.to_s].to_i > 0 ? 1 : 0
            else
              0
            end
          end
        end

        work_days
      end

      # Returns hash of holiday setting identifiers (symbols) for particular user or default
      # used for accesing specific setting in the settings object
      # @param key [String or Integer] - id of some user or 'default' for default settings
      # @return [Hash] - symbolic setting identifiers
      def self.key_identifiers(key)
        {
          country: "#{key}_country",
          state: "#{key}_state",
          selected: "#{key}_selected",
          unselected: "#{key}_unselected",
          inherit: "#{key}_inherit_days",
          non_working: "#{key}_working_week_days",
          non_working_hrs: "#{key}_working_week_hours"
        }
      end

      # Returns array of groups and users for user select tag on the plugin settings page
      # without those who have holiday settings already defined - used for generating html
      # tag names and ids
      # @return [Array] of arrays - users and groups grouped by type
      #                             for 'grouped_options_for_select' rails method
      def self.groups_and_users
        options = []
        users_excluded = users_in_settings

        groups = Group.active
        groups = groups.where('id NOT IN (?)', users_excluded) unless users_excluded.empty?

        users = User.active
        users = users.where('id NOT IN (?)', users_excluded) unless users_excluded.empty?

        groups_arr = groups.map { |g| [g.name, g.id] }
        users_arr = users.map { |u| [u.name, u.id] }
        options << [l(:label_group_plural), groups_arr] if groups_arr.any?
        options << [l(:label_user_plural), users_arr] if users_arr.any?
        options
      end

      # Collects all user and group ids, who already have holiday settins
      # @return [Array] - array of user or group ids
      def self.users_in_settings
        users_in_settings = []

        Setting.plugin_redmine_x_assets.each do |key, value| 
          ka = key.to_s.split('_')
          unless ka.length == 3 &&
                 ka[0] != 'default' &&
                 ka[1] == 'holidays' &&
                 ka[2] == 'country'
            next
          end
          users_in_settings << ka[0].to_i
        end

        users_in_settings
      end

      # Saves current assigned_to_id user or group from issue controller
      # @param issue_id [Integer or String] - issue id for which we want to save the assigned_to_id value
      # @param assigned_to_id [Integer or String] - assigned_to_id, which we want to save
      # @return [nil] - nothing is returned
      def self.save_assigned(issue_id, assigned_to_id)
        @@assigned_to_ids[issue_id] = assigned_to_id || 0
      end

      # Retrieves current assigned_to_id user or group for the given issue
      # @param issue_id [Integer or String] - issue id for which we want to retrieve the assigned_to_id value
      # @return [Integer or String] - retrieved assigned_to_id or nil, if it doesn't exist
      def self.load_assigned(issue_id)
        @@assigned_to_ids[issue_id]
      end

    # Removes current assigned_to_id user or group for the given issue
    # @param issue_id [Integer or String] - issue id for which we want to remove the assigned_to_id value
    # @return [nil] - nothing is returned
    def self.remove_assigned(issue_id)
      @@assigned_to_ids.delete(issue_id)
    end
    end
  end
end