module RedmineXAssets
  module Helpers
    module PrioritiesHelper
      # Returns all priorities data in a format suitable for resources component
      # @return [Hash] -
      def priority_items
        priority_levels.map do |priority|
          {
            key: priority.id,
            label: priority.name,
            position_name: priority.position_name,
            position: priority.position
          }
        end
      end

      # Returns priority levels defined in the settings of redmine
      # @return [Array] of priority levels
      def priority_levels
        Enumeration.select(:id, :name, :position, :position_name, :is_default)
                  .where(type: 'IssuePriority')
                  .order(:position)
      end

    end
  end
end