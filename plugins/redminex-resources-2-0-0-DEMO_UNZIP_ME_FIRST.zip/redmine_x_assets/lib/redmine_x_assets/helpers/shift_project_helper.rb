# Enables to shift projects forward or backward by given number of days
module RedmineXAssets
  module Helpers
    module ShiftProjectHelper
      include RedmineXAssets::Helpers::CalendarsHelper
      AREL = RedmineXAssets::Helpers::ArelFunctionsHelper

      # Shifts all items of the root project, including its subprojects by shift_value in days
      # @param root_project [Object] ActiveRecord Project object,
      #   which items should be shifted including subprojects
      # @param shift_value [Integer] - no. of working days by which the project items should be shifted
      #   (can be negative)
      # @param options [Hash] - can be only set to options[:notifications] - true or false,
      #                         default value is "according to the gantt settings"
      # @return [Object] ActiveRecord Projects array, containing all projects contained in the root_project
      def shift_project(root_project, shift_value, options={})
        project_condition = root_project.project_condition(true)
        Project.where(project_condition).each do |project|
          shift_project_items(project, shift_value, options)
        end
      end

      # Shifts all items of one project by shift_value in days
      # @param project [Object] ActiveRecord Project object
      # @param shift_value [Integer] - no. of working days by which the project items should be shifted
      #   (can be negative)
      # @param options [Hash] - can be only set to options[:notifications] - true or false,
      #                         default value is "according to the gantt settings"
      # @return [Object] ActiveRecord Project object
      def shift_project_items(project, shift_value, options={})
        versions = project.versions.order(:id)
        versions_max_due_date = versions_max_due_date(versions)

        project.issues.each do |issue|
          next if precedes_relation?(issue)

          shift_issue(issue, shift_value, options)
        end

        precalculate_holiday_data('default')
        versions.each_with_index do |version, i|
          before_issues = if versions_max_due_date[i].nil?
                            true
                          else
                            version_effective_date(version) < Date.parse(versions_max_due_date[i])
                          end
          shift_version(version, shift_value, before_issues)
        end
      end

      # Finds out maximum due date of the versions issues
      # @param versions [Array] of Version objects
      # @return [Array] with max due dates of the versions issues
      def versions_max_due_date(versions)
        issues = Issue.arel_table
        start_date_condition_today = AREL.arel_db_if(issues[:start_date].eq(nil), Date.today, issues[:start_date])
        closed_on_condition = AREL.arel_db_if(issues[:closed_on].eq(nil), start_date_condition_today, issues[:closed_on])
        due_date_condition = AREL.arel_db_if(issues[:due_date].eq(nil), closed_on_condition, issues[:due_date])

        versions.map do |version|
          version.fixed_issues.maximum(due_date_condition.to_sql)
        end
      end

      # Shifts issue by shift_value in days
      # @param issue [Object] ActiveRecord Issue object
      # @param shift_value [Integer] - no. of working days by which the issue should be shifted
      #   (can be negative)
      # @param options [Hash] - can be only set to options[:notifications] - true or false,
      #                         default value is "according to the gantt settings"
      # @return [Object] - saved shifted issue
      def shift_issue(issue, shift_value, options={})
        return if issue.children.any?

        issue_notifications(issue, options)
        start_date = issue_start_date(issue)
        reschedule_date = start_date + shift_value

        issue.reschedule_on_for_project_shift(reschedule_date)
        issue.save
      end

      # Shifts version by shift_value in days
      # @param version [Object] ActiveRecord Version object
      # @param shift_value [Integer] - no. of working days by which the version should be shifted
      #   (can be negative)
      # @param before_issues [Boolean] - true if the given version is before at least one its
      #                                  issue's due date
      # @return [Object] - saved shifted version
      def shift_version(version, shift_value, before_issues)
        effective_date = version_effective_date(version)
        new_effective_date = effective_date + shift_value
        unless working_day?(new_effective_date, true)
          if shift_value > 0
            new_effective_date = next_working_date_with_calendars(new_effective_date, true)
          else
            new_effective_date = previous_working_date_with_calendars(new_effective_date, true)
          end
        end

        unless before_issues
          versions_max_due_date = Date.parse(versions_max_due_date([version]).first)
          new_effective_date = versions_max_due_date + 1 if new_effective_date <= versions_max_due_date
          # unless working_day?(new_effective_date, true)
          #   new_effective_date = next_working_date_with_calendars(new_effective_date, true)
          # end
        end

        version.effective_date = new_effective_date
        version.save
      end

      # Returns Due Date of the issue - in case due date is not filled in, we use other dates to set issue due date
      # @param issue [Object] ActiveRecord Issue object
      # @return [Date] due date of issue
      def issue_due_date(issue)
        if issue.due_date
          issue.due_date
        elsif issue.closed_on
          issue.closed_on.to_date
        else
          issue.start_date ? issue.start_date : Date.today
        end
      end

      # Returns Start Date of the issue - in case start date is not filled in, we use today date to set issue start date
      # @param issue [Object] ActiveRecord Issue object
      # @return [Date] start date of issue
      def issue_start_date(issue)
        if issue.start_date
          issue.start_date
        else
          Date.today
        end
      end

      # Returns effective date of the version - in case there is not effective date, 
      # created on date is used
      # @param version [Object] ActiveRecord Version object
      # @return [Date] of version (effective date of created on)
      def version_effective_date(version)
        if version.effective_date
          version.effective_date.to_date
        else
          version.created_on.to_date
        end
      end

      # Returns true if the issue has precedes relation (with fixed delay). If parents
      # start and end dates are derived from chidren, then parents of the issue are checked as well
      # @param issue [Object] ActiveRecord Issue object
      # @return [Boolean] - true if issue or one of its parents has precedes relation
      def precedes_relation?(issue)
        precedes_relation = false
        issue.relations_to.each do |relation|
          precedes_relation = true if relation.relation_type == 'precedes'
        end

        # Check issues parent if parent is derived
        if !precedes_relation && Setting.parent_issue_dates == 'derived' && issue.parent
          precedes_relation = precedes_relation?(issue.parent)
        end

        precedes_relation
      end

      # Writes new record to issue journal and turns on/off email notification
      # @param issue [Object] ActiveRecord Issue object
      # @param options [Hash] - can be only set to options[:notifications] - true or false,
      #                         default value is "according to the gantt settings"
      # @return nil
      def issue_notifications(issue, options={})
        journal = nil
        if options.key?(:notifications) && options[:notifications]
          journal = issue.init_journal(User.current)
          journal.notify = true
        else
          if write_to_journal?
            journal = issue.init_journal(User.current)
            journal.notify = send_notifications?
          end
        end
        journal
      end

      # Reads notificiations_on_project_move gantt plugin setting
      # @return [Boolean] - true if email notification should be sent when project is shifted
      def send_notifications?
        return true if Setting.plugin_redmine_x_gantt[:notificiations_on_project_move]
        false
      end

      # Reads journal_on_project_move gantt plugin setting
      # @return [Boolean] - true if new record in journal should be created when project is shifted
      def write_to_journal?
        return true if Setting.plugin_redmine_x_gantt[:journal_on_project_move]
        false
      end

    end
  end
end