module RedmineXAssets
  module Patches
    module IssuesControllerPatch
      def self.included(receiver)
        receiver.class_eval do

          # This method replaces Issue Controllers update action - this action is called when issue
          # is updated directly or via API. We need to ensure that issue is self-rescheduled when
          # assignee is changed and correct earliest start date is checked (corresponding to the
          # assignees calendar).
          def update
            # The following code was added:
            # When issue is modified, save assigned_to_id first, in order to update issue's calendar
            # Then potential shift of issue can be properly validated with the new calendar in use
            assigned = if params[:issue][:assigned_to_id]
                        params[:issue][:assigned_to_id].to_i
                      else
                        @issue.assigned_to_id.to_i
                      end
            RedmineXAssets::Helpers::HolidayHelper.save_assigned(@issue.id, assigned)

            return unless update_issue_from_params

            # The following code was added:
            # Shift issue if assignee is changed
            if params[:id] && params[:issue] && params[:issue][:assigned_to_id]
              @issue.relations_to.each do |relation|
                soonest_start = relation.successor_soonest_start
                if soonest_start && relation.issue_to && @issue.id == relation.issue_to.id
                  @issue.reschedule_self(soonest_start)
                end
              end
            end

            @issue.save_attachments(params[:attachments] || (params[:issue] && params[:issue][:uploads]))
            saved = false
            begin
              saved = save_issue_with_child_records
            rescue ActiveRecord::StaleObjectError
              @conflict = true
              if params[:last_journal_id]
                @conflict_journals = @issue.journals_after(params[:last_journal_id]).to_a
                @conflict_journals.reject!(&:private_notes?) unless User.current.allowed_to?(:view_private_notes, @issue.project)
              end
            end

            if saved
              render_attachment_warning_if_needed(@issue)
              flash[:notice] = l(:notice_successful_update) unless @issue.current_journal.new_record? || params[:no_flash]

              respond_to do |format|
                format.html { redirect_back_or_default issue_path(@issue, previous_and_next_issue_ids_params) }
                format.api  { render_api_ok }
              end
            else
              respond_to do |format|
                format.html { render :action => 'edit' }
                format.api  { render_validation_errors(@issue) }
              end
            end

            RedmineXAssets::Helpers::HolidayHelper.remove_assigned(@issue.id)
          end
        end
      end
    end
  end
end

unless IssuesController.included_modules.include?(RedmineXAssets::Patches::IssuesControllerPatch)
  IssuesController.send(:include, RedmineXAssets::Patches::IssuesControllerPatch)
end

