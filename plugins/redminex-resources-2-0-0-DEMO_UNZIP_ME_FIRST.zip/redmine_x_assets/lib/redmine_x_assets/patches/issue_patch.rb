module RedmineXAssets
  module Patches
    module IssuePatch
      include RedmineXAssets::Helpers::CalendarsHelper

      def self.included(receiver)
        receiver.send(:include, InstanceMethods)
        receiver.class_eval do

          # Method rerplaces validate_issue method in the Issue model - method validates issue before
          # it is saved. In this patch we only added soonest start check when assignee of the issue is
          # changed - this can lead to change of the calendar and therefore to the change of the earliest
          # start date.
          def validate_issue
            if due_date && start_date && (start_date_changed? || due_date_changed?) && due_date < start_date
              errors.add :due_date, :greater_than_start_date
            end

            # The following part was changed:
            # To this part of the code: "if start_date && start_date_changed? && soonest_start" we add
            # "assigned_to_id_changed?" to trigger soonest start check when assegnee is changed
            if start_date && (start_date_changed? || assigned_to_id_changed?) && soonest_start && start_date < soonest_start
              errors.add :start_date, :earlier_than_minimum_start_date, :date => format_date(soonest_start)
            end

            if fixed_version
              if !assignable_versions.include?(fixed_version)
                errors.add :fixed_version_id, :inclusion
              elsif reopening? && fixed_version.closed?
                errors.add :base, I18n.t(:error_can_not_reopen_issue_on_closed_version)
              end
            end

            # Checks that the issue can not be added/moved to a disabled tracker
            if project && (tracker_id_changed? || project_id_changed?)
              if tracker && !project.trackers.include?(tracker)
                errors.add :tracker_id, :inclusion
              end
            end

            if assigned_to_id_changed? && assigned_to_id.present?
              unless assignable_users.include?(assigned_to)
                errors.add :assigned_to_id, :invalid
              end
            end

            # Checks parent issue assignment
            if @invalid_parent_issue_id.present?
              errors.add :parent_issue_id, :invalid
            elsif @parent_issue
              if !valid_parent_project?(@parent_issue)
                errors.add :parent_issue_id, :invalid
              elsif (@parent_issue != parent) && (
                  self.would_reschedule?(@parent_issue) ||
                  @parent_issue.self_and_ancestors.any? {|a| a.relations_from.any? {|r| r.relation_type == IssueRelation::TYPE_PRECEDES && r.issue_to.would_reschedule?(self)}}
                )
                errors.add :parent_issue_id, :invalid
              elsif !closed? && @parent_issue.closed?
                # cannot attach an open issue to a closed parent
                errors.add :base, :open_issue_with_closed_parent
              elsif !new_record?
                # moving an existing issue
                if move_possible?(@parent_issue)
                  # move accepted
                else
                  errors.add :parent_issue_id, :invalid
                end
              end
            end
          end

          # Replaces reschedule_on method in the Issue model. Sets start_date on the given date or
          # the next working day and changes due_date to keep the same working duration (taking
          # into account custom calendar of the issue).
          def reschedule_on(date)
            key = RedmineXAssets::Helpers::HolidayHelper.load_assigned(id)

            if key.nil?
              key = assigned_to_id || 'default'
            elsif key.zero?
              key = 'default'
            end

            precalculate_holiday_data(key)
            date = next_working_date_with_calendars(date, true)

            if assigned_to_id
              unless key == assigned_to_id.to_i
                precalculate_holiday_data(assigned_to_id.to_i)
              end
            else
              precalculate_holiday_data('default') unless key == 'default'
            end

            wd = working_duration
            self.start_date = date
            self.due_date = add_working_days_with_calendars(date, wd)
          end

          # Replaces working_duration method in the Issue model. Returns the duration in working days
          # (taking into account custom calendar of the issue) using working_days_with_calendars method
          # in CalendarsHelper.
          def working_duration
            (start_date && due_date) ?  working_days_with_calendars(start_date, due_date)[:days] : 0
          end

        end
      end

      module InstanceMethods

        # This is a new method. This method is derived from reschedule_on! method in the Issue model, which
        # reschedules the issue on the given date or the next working day and saves the record. If the issue
        # is a parent task, this is done by rescheduling its subtasks. Unlike reschedule_on! this method
        # doesn't save the changes and also doesn't initializes journal.
        # @param date [Date] - soonest start of the issue
        # @return [nil] - nothing is returned
        def reschedule_self(date)
          return if date.nil?
          if leaf? || !dates_derived?
            if start_date.nil? || start_date != date
              if start_date && start_date > date
                # Issue can not be moved earlier than its soonest start date
                date = [soonest_start(true), date].compact.max
              end
              reschedule_on(date)
            end
          else
            leaves.each do |leaf|
              if leaf.start_date
                # Only move subtask if it starts at the same date as the parent
                # or if it starts before the given date
                if start_date == leaf.start_date || date > leaf.start_date
                  leaf.reschedule_self(date)
                end
              else
                leaf.reschedule_self(date)
              end
            end
          end
        end

        # This is a new method. It is a special version of reschedule_on method for shifting of
        # projects. When the project is shifted to the past, we want to use
        # previous_working_date_with_calendars method instead of nex_working_date... method
        # @param date [Date] - new start of the issue
        # @return [nil] - nothing is returned
        def reschedule_on_for_project_shift(date)
          key = RedmineXAssets::Helpers::HolidayHelper.load_assigned(id)

          if key.nil?
            key = assigned_to_id || 'default'
          elsif key.zero?
            key = 'default'
          end

          precalculate_holiday_data(key)
          if (date >= start_date)
            date = next_working_date_with_calendars(date, true)
          else
            date = previous_working_date_with_calendars(date, true)
          end

          if assigned_to_id
            unless key == assigned_to_id.to_i
              precalculate_holiday_data(assigned_to_id.to_i)
            end
          else
            precalculate_holiday_data('default') unless key == 'default'
          end

          wd = working_duration
          self.start_date = date
          self.due_date = add_working_days_with_calendars(date, wd)
        end
      end
    end
  end
end

unless Issue.included_modules.include?(RedmineXAssets::Patches::IssuePatch)
  Issue.send(:include, RedmineXAssets::Patches::IssuePatch)
end

