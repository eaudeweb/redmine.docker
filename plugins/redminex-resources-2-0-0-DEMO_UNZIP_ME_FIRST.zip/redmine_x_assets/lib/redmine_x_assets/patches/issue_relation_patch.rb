module RedmineXAssets
  module Patches
    module IssueRelationPatch
      include Redmine::I18n
      include RedmineXAssets::Helpers::CalendarsHelper

      def self.included(receiver)

          start_to_start    = 'start_to_start'
          start_to_finish   = 'start_to_finish'
          finish_to_finish  = 'finish_to_finish'
          finish_to_start   = 'finish_to_start'

          extended_types = receiver::TYPES.merge(
            start_to_start => {
              name: :relation_start_to_start,
              sym_name: :relation_start_to_start,
              order: 50,
              sym: start_to_start
            },
            start_to_finish => {
              name: :relation_start_to_finish,
              sym_name: :relation_start_to_finish,
              order: 51,
              sym: start_to_finish
            },
            finish_to_finish => {
              name: :relation_finish_to_finish,
              sym_name: :relation_finish_to_finish,
              order: 52,
              sym: finish_to_finish
            },
            finish_to_start => {
              name: :relation_finish_to_start,
              sym_name: :relation_finish_to_start,
              order: 53,
              sym: finish_to_start
            },
          )

        receiver.class_eval do
          const_set :TYPE_START_TO_START, start_to_start
          const_set :TYPE_START_TO_FINISH, start_to_finish
          const_set :TYPE_FINISH_TO_FINISH, finish_to_finish
          const_set :TYPE_FINISH_TO_START, finish_to_start

          remove_const :TYPES
          const_set :TYPES, extended_types.freeze

          inclusion_validator = _validators[:relation_type].find{|v| v.kind == :inclusion}
          inclusion_validator.instance_variable_set(:@delimiter, extended_types.keys)

          # Calculates succesor tasks earliest start_date (taking into account custom calendar)
          # for the given relation. This method replaces successor_soonest_start method in issue_relation.rb,
          # @return {Date} - earliest start date of the relation's target task
          def successor_soonest_start
            if (IssueRelation::TYPE_PRECEDES == self.relation_type) && delay && issue_from &&
              (issue_from.start_date || issue_from.due_date)

              key = RedmineXAssets::Helpers::HolidayHelper.load_assigned(issue_to.id)

              if key.nil?
                key = issue_to.assigned_to_id || 'default'
              elsif key.zero?
                key = 'default'
              end

              precalculate_holiday_data(key)
              add_working_days_with_calendars((issue_from.due_date || issue_from.start_date), (1 + delay))
            end
          end
        end
      end
    end
  end
end

unless IssueRelation.included_modules.include?(RedmineXAssets::Patches::IssueRelationPatch)
  IssueRelation.send(:include, RedmineXAssets::Patches::IssueRelationPatch)
end

