# Plugin's routes

# Holidays
get 'redmine_x_assets_holidays/get', to: 'redmine_x_assets_holidays#get', format: :json, as: 'get_rx_assets_holidays'
get 'redmine_x_assets_holidays/create', to: 'redmine_x_assets_holidays#create', format: :js, as: 'create_rx_assets_holidays'
get 'redmine_x_assets_holidays/destroy', to: 'redmine_x_assets_holidays#destroy', format: :js, as: 'destroy_rx_assets_holidays'