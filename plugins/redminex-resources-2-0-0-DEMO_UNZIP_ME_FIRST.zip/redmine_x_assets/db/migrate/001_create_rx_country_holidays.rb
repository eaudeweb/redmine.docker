class CreateRxCountryHolidays < ActiveRecord::Migration[5.2]
  def change
    create_table :rx_country_holidays do |t|
      t.string :country
      t.string :country_iso
      t.string :holiday_type
      t.date :date
      t.integer :year
      t.string :name
      t.string :state
      t.string :state_iso
    end
  end
end
