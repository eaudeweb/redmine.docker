# RedmineX Assets

Plugin providing common assets for RedmineX Gantt and RedmineX Resources plugins.