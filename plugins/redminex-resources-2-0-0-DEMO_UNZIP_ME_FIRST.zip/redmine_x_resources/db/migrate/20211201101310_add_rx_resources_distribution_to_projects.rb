class AddRxResourcesDistributionToProjects < ActiveRecord::Migration[5.2]
  def change
    add_column :projects, :rx_resources_distribution, :string, default: 'uniform_decimal', null: false
  end
end
  