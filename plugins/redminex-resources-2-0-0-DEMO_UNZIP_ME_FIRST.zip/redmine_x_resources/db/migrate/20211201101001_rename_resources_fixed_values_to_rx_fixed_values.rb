class RenameResourcesFixedValuesToRxFixedValues < ActiveRecord::Migration[5.2]
  def change
    rename_table :resources_fixed_values, :rx_fixed_values
  end
end
