module RedmineXResources
  module Helpers
    module DistributionsHelper
      include Redmine::I18n

      # Returns all distribution data in a format suitable for resources component
      # @return [Array] - of hashes with keys 'key' and 'label'
      def distribution_items
        [
          { key: Project::DISTRIBUTION_UNIFORM_WHOLE,   label: l(:distribution_uniform_whole)   },
          { key: Project::DISTRIBUTION_UNIFORM_HALF,    label: l(:distribution_uniform_half)    },
          { key: Project::DISTRIBUTION_UNIFORM_DECIMAL, label: l(:distribution_uniform_decimal) },
          { key: Project::DISTRIBUTION_FROM_START,      label: l(:distribution_from_start)      },
          { key: Project::DISTRIBUTION_FROM_END,        label: l(:distribution_from_end)        }
        ]
      end
    end
  end
end