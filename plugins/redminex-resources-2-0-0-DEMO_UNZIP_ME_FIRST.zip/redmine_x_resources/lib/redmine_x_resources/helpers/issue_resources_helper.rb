module RedmineXResources

  module Helpers

    module IssueResourcesHelper
      include RedmineXAssets::Helpers::CalendarsHelper
      include RedmineXResources::Helpers::DataHelper

      TYPE_ENTRY = 'TYPE_ENTRY'
      TYPE_FIXED = 'TYPE_FIXED'
      TYPE_DISTRIBUTION = 'TYPE_DISTRIBUTION'
      TYPE_DAYOFF = 'TYPE_DAYOFF'
      JS_DATE_FORMAT = '%a %b %d %Y'

      ID = 0
      PARENT_PROJECT = 1
      USER = 2
      ESTIMATED = 3
      SPENT = 3
      START_DATE = 4
      DUE_DATE = 5

      def projects_and_users_resources(project_and_user_list, show_closed_issues)
        store = RedmineXResources::Resources::ResourceStore.new(project_and_user_list[:users])
        user_list = project_and_user_list[:users].keys.map(&:to_i)
        project_and_user_list[:projects].each do |project_id|
          project = Project.find(project_id)

          time_entries = time_entries_data(project, user_list, show_closed_issues)
          process_time_entries(time_entries, store)

          fixed = fixed_data(project, user_list, show_closed_issues)
          process_fixed(fixed, store)

          issues = issues_data(project, user_list, show_closed_issues)
          process_issues(issues, store)
        end

        # time_entries_external = time_entries_data_external(project_and_user_list, show_closed_issues)
        # process_time_entries(time_entries_external, store, true)

        fixed_external = fixed_data_external(project_and_user_list, show_closed_issues)
        process_fixed(fixed_external, store, true)

        issues_external = issues_data_external(project_and_user_list, show_closed_issues)
        process_issues(issues_external, store, true)

        store.data
      end

      def spent_time(user_id, issues)
        time_entries = TimeEntry.arel_table

        hours = TimeEntry
                .where(time_entries[:issue_id].in(issues).and(time_entries[:user_id].eq(user_id)))
                .pluck(time_entries[:hours].sum).first
        hours || 0
      end



      # def issue_resources(issues, project_list, parents, isExternal=false)
      #   resourcesHash = {}
      #   issues.each do |issue|
      #     #p "issue_resources PARENTS".upcase, parents
      #     #puts ''
      #     resource = single_issue_resources(issue, project_list, parents, isExternal)
      #     resourcesHash["i#{issue.id}"] = resource unless resource_zero?(resource)
      #   end

      #   resourcesHash
      # end

      def resource_zero?(resource)
        resource[:fixedTotal].zero? &&
        resource[:spentTotal].zero? &&
        resource[:estimated].zero? &&
        resource[:hoursDistributionTotal].zero? &&
        resource[:lowEstimation].zero? &&
        resource[:highEstimation].zero?
      end

      # def assign_empty_parent(issue, parents, project_list)
      #   if issue.project_id && !parents[issue.project_id] && 
      #     project_list.include?(issue.project_id)

      #      parents[issue.project_id] = empty_parent(false)
      #   end
      #   user = issue.assigned_to_id ? "u#{issue.assigned_to_id}" : 'u-1'
      #   unless parents[user]
      #     parents[user] = empty_parent(true)
      #   end
      #   user
      # end

      # def empty_parent(isUser)
      #   parent = {
      #     estimated: 0,
      #     fixedTotal: 0,
      #     hoursDistributionTotal: 0,
      #     spentTotal: 0,
      #     highEstimation: false,
      #     lowEstimation: false,
      #     values: {}
      #   }
      #   parent.merge!({
      #     estimatedExternal: 0,
      #     fixedTotalExternal: 0,
      #     hoursDistributionTotalExternal: 0,
      #     spentTotalExternal: 0
      #   }) if isUser
      #   parent
      # end

      def issues_query(project, user_list, show_closed_issues)
        issues = Issue.arel_table
        issue_statuses = IssueStatus.arel_table

        issue_statuses_join = issues.join(issue_statuses).on(issue_statuses[:id].eq(issues[:status_id])).join_sources

        issue_in_user_list = AREL.arel_db_in(issues[:assigned_to_id], user_list).or(issues[:assigned_to_id].eq(nil))

        visible_issues = nil
        if show_closed_issues
          visible_issues = project.issues.visible
        else
          visible_issues = project.issues.visible.where(issue_statuses[:is_closed].eq(false))
        end

        visible_issues
        .where(issue_in_user_list)
        .joins(issue_statuses_join)
      end

      def issues_query_external(project_and_user_list, show_closed_issues)
        issues = Issue.arel_table
        issue_statuses = IssueStatus.arel_table

        min_date = projects_min_date(project_and_user_list[:projects], show_closed_issues)

        issue_statuses_join = issues.join(issue_statuses).on(issue_statuses[:id].eq(issues[:status_id])).join_sources

        start_date_condition_today = AREL.arel_db_if(issues[:start_date].eq(nil), Date.today, issues[:start_date])
        closed_on_condition = AREL.arel_db_if(issues[:closed_on].eq(nil), start_date_condition_today, issues[:closed_on])
        due_date_condition = AREL.arel_db_if(issues[:due_date].eq(nil), closed_on_condition, issues[:due_date])

        issues_condition = issues[:assigned_to_id].in(project_and_user_list[:users]).and(issues[:project_id].not_in(project_and_user_list[:projects])).and(due_date_condition.gteq(min_date))

        settings = Setting.plugin_redmine_x_assets
        if settings['holiday_tracker'] && settings['holiday_tracker'].to_i > 0
          issues_condition = issues_condition.and(issues[:tracker_id].not_eq(settings['holiday_tracker'].to_i))
        end

        visible_issues = nil
        if show_closed_issues
          visible_issues = Issue.visible
        else
          visible_issues = Issue.visible.where(issue_statuses[:is_closed].eq(false))
        end

        visible_issues
        .where(issues_condition)
        .joins(issue_statuses_join)
      end

      def issues_data(project, user_list, show_closed_issues)
        issues = Issue.arel_table

        issue_id = AREL.arel_db_concatenation('i', issues[:id])
        estimated_condition = AREL.arel_db_if(issues[:estimated_hours].eq(nil), Arel::Nodes::SqlLiteral.new('0'), issues[:estimated_hours])
        start_date_condition_today = AREL.arel_db_if(issues[:start_date].eq(nil), Date.today, issues[:start_date])
        closed_on_condition = AREL.arel_db_if(issues[:closed_on].eq(nil), start_date_condition_today, issues[:closed_on])
        due_date_condition = AREL.arel_db_if(issues[:due_date].eq(nil), closed_on_condition, issues[:due_date])
        start_date_condition = AREL.arel_db_if(issues[:start_date].eq(nil), due_date_condition, issues[:start_date])

        issues_query(project, user_list, show_closed_issues)
        .pluck(issue_id, issues[:project_id], issues[:assigned_to_id], estimated_condition, start_date_condition, due_date_condition)
      end

      def issues_data_external(project_and_user_list, show_closed_issues)
        issues = Issue.arel_table

        issue_id = AREL.arel_db_concatenation('i', issues[:id])
        estimated_condition = AREL.arel_db_if(issues[:estimated_hours].eq(nil), Arel::Nodes::SqlLiteral.new('0'), issues[:estimated_hours])
        start_date_condition_today = AREL.arel_db_if(issues[:start_date].eq(nil), Date.today, issues[:start_date])
        closed_on_condition = AREL.arel_db_if(issues[:closed_on].eq(nil), start_date_condition_today, issues[:closed_on])
        due_date_condition = AREL.arel_db_if(issues[:due_date].eq(nil), closed_on_condition, issues[:due_date])
        start_date_condition = AREL.arel_db_if(issues[:start_date].eq(nil), due_date_condition, issues[:start_date])

        issues_query_external(project_and_user_list, show_closed_issues)
        .pluck(issue_id, issues[:project_id], issues[:assigned_to_id], estimated_condition, start_date_condition, due_date_condition)
      end

      def time_entries_data(project, user_list, show_closed_issues)
        issues = Issue.arel_table
        time_entries = TimeEntry.arel_table
        time_entries_join = issues.join(time_entries).on(time_entries[:issue_id].eq(issues[:id])).join_sources

        issues_query(project, user_list, show_closed_issues)
        .joins(time_entries_join)
        .group(issues[:id])
        .pluck(issues[:id], issues[:project_id], issues[:assigned_to_id], time_entries[:hours].sum)
      end

      def time_entries_data_external(project_and_user_list, show_closed_issues)
        issues = Issue.arel_table
        time_entries = TimeEntry.arel_table
        time_entries_join = issues.join(time_entries).on(time_entries[:issue_id].eq(issues[:id])).join_sources

        issues_query_external(project_and_user_list, show_closed_issues)
        .joins(time_entries_join)
        .group(issues[:id])
        .pluck(issues[:id], issues[:project_id], issues[:assigned_to_id], time_entries[:hours].sum)
      end

      def fixed_data(project, user_list, show_closed_issues)
        issues = Issue.arel_table
        fixed_values = RxFixedValue.arel_table
        fixed_values_join = issues.join(fixed_values).on(fixed_values[:issue_id].eq(issues[:id])).join_sources

        issues_query(project, user_list, show_closed_issues)
        .joins(fixed_values_join)
        .pluck(issues[:id], issues[:project_id], issues[:assigned_to_id], fixed_values[:id], fixed_values[:date], fixed_values[:hours])
      end

      def fixed_data_external(project_and_user_list, show_closed_issues)
        issues = Issue.arel_table
        fixed_values = RxFixedValue.arel_table
        fixed_values_join = issues.join(fixed_values).on(fixed_values[:issue_id].eq(issues[:id])).join_sources

        issues_query_external(project_and_user_list, show_closed_issues)
        .joins(fixed_values_join)
        .pluck(issues[:id], issues[:project_id], issues[:assigned_to_id], fixed_values[:id], fixed_values[:date], fixed_values[:hours])
      end

      def projects_min_date(project_list, show_closed_issues)
        issues = Issue.arel_table
        issue_statuses = IssueStatus.arel_table

        issue_statuses_join = issues.join(issue_statuses).on(issue_statuses[:id].eq(issues[:status_id])).join_sources

        if show_closed_issues
          Issue.visible
               .where(issues[:project_id].in(project_list))
               .minimum(:start_date)
        else
          Issue.visible
               .joins(issue_statuses_join)
               .where(issue_statuses[:is_closed].eq(false))
               .where(issues[:project_id].in(project_list))
               .minimum(:start_date)
        end
      end

      def process_fixed(fixed, store, external=false)
        precalculate_holiday_data(fixed[USER] || 'default')
        fixed_to_delete = []
        fixed.each do |entry|
          if entry[4] < Date.today
            fixed_to_delete << entry[3]
          else
            capacity = @work_days[entry[4].wday].to_f
            store.add_value(entry, external, entry[4].strftime(JS_DATE_FORMAT), { hours: entry[5], capacity: capacity, type: TYPE_FIXED })
          end
        end
        delete_fixed(fixed_to_delete)
      end

      def process_time_entries(time_entries, store, external=false)
        time_entries.each do |entry|
          store.add(entry, external, :spentTotal, entry[SPENT])
          #store.add_value(entry, external, entry[3].strftime(JS_DATE_FORMAT), { hours: entry[4], type: TYPE_ENTRY })
        end
      end

      def process_issues(issues, store, external=false)
        issues.each do |issue|
          due_date =
            issue[DUE_DATE].class == Date ? issue[DUE_DATE] : Date.parse(issue[DUE_DATE])

          # if Date.today > due_date
          #   next
          # end

          precalculate_holiday_data(issue[USER] || 'default')

          remaining_data = calculate_remaining_hours(store, issue, external)
          distribution_type = distribution_type(issue)

          store.add(issue, external, :estimated, issue[ESTIMATED])

          if distribution_type == Project::DISTRIBUTION_FROM_END
            loop_dates_backward(issue, store, external, remaining_data, distribution_type)
          else
            loop_dates_forward(issue, store, external, remaining_data, distribution_type)
          end
        end
      end

      def loop_dates_forward(issue, store, external, remaining_data, type)
        start_date =
          issue[START_DATE].class == Date ? issue[START_DATE] : Date.parse(issue[START_DATE])
        due_date =
          issue[DUE_DATE].class == Date ? issue[DUE_DATE] : Date.parse(issue[DUE_DATE])


        current_date = Date.today <= start_date ? start_date : Date.today

        work_day_counter = 0
        remainder = 0
        if type == Project::DISTRIBUTION_FROM_START
          remainder = remaining_data[:remaining_estimated]
        end

        while current_date <= due_date
          current_value = store.data[issue[ID]][:values][current_date.strftime(JS_DATE_FORMAT)]
          unless current_value
            if working_day?(current_date, true)
              hours_value = 0
              unless remaining_data[:remaining_estimated].zero?
                hours_value, remainder, capacity = distribution_value(
                  current_date, work_day_counter, remainder, remaining_data, type
                )
              end
              store.add_value(issue, external, current_date.strftime(JS_DATE_FORMAT), { hours: hours_value, capacity: capacity, type: TYPE_DISTRIBUTION })
              work_day_counter += 1
            else
              store.add_value(issue, external, current_date.strftime(JS_DATE_FORMAT), { hours: 0, capacity: 0, type: TYPE_DAYOFF })
            end
          end
          current_date += 1
        end
      end

      def loop_dates_backward(issue, store, external, remaining_data, type)
        start_date =
          issue[START_DATE].class == Date ? issue[START_DATE] : Date.parse(issue[START_DATE])
        due_date =
          issue[DUE_DATE].class == Date ? issue[DUE_DATE] : Date.parse(issue[DUE_DATE])

        current_date = due_date
        loop_end_date = Date.today <= start_date ? start_date : Date.today

        work_day_counter = 0
        remainder = remaining_data[:remaining_estimated]

        while current_date >= loop_end_date
          current_value = store.data[issue[ID]][:values][current_date.strftime(JS_DATE_FORMAT)]
          unless current_value
            if working_day?(current_date, true)
              hours_value = 0
              unless remaining_data[:remaining_estimated].zero?
                hours_value, remainder, capacity = distribution_value(
                  current_date, work_day_counter, remainder, remaining_data, type
                )
              end
              store.add_value(issue, external, current_date.strftime(JS_DATE_FORMAT), { hours: hours_value, capacity: capacity, type: TYPE_DISTRIBUTION })
              work_day_counter += 1
            else
              store.add_value(issue, external, current_date.strftime(JS_DATE_FORMAT), { hours: 0, capacity: 0, type: TYPE_DAYOFF })
            end
          end
          current_date -= 1
        end
      end

      def distribution_value(current_date, day, remainder, remaining_data, type)
        if type == Project::DISTRIBUTION_FROM_START || type == Project::DISTRIBUTION_FROM_END
          distribution_from_start_or_end(current_date, day, remainder, remaining_data)
        else
          distribution_uniform(current_date, day, remainder, remaining_data, type)
        end
      end

      def distribution_type(issue)
        begin
          project = Project.find(issue[PARENT_PROJECT])
        rescue ActiveRecord::RecordNotFound
          return Project::DISTRIBUTION_UNIFORM_DECIMAL
        end

        return project.rx_resources_distribution
      end

      def distribution_from_start_or_end(current_date, day, remainder, remaining_data)
        return [0, 0] if remainder <= 0

        capacity = @work_days[current_date.wday].to_f
        hours_value = (capacity > remainder ? remainder : capacity)
        remainder -= hours_value

        if last_day?(day, remaining_data)
          hours_value += remainder
          remainder = 0
        end

        [hours_value, remainder, capacity]
      end

      def distribution_uniform(current_date, day, remainder, remaining_data, type)
        capacity = @work_days[current_date.wday].to_f
        hours_value = capacity / remaining_data[:working_hours].to_f *
          remaining_data[:remaining_estimated].to_f
        hours_value_rounded = round_distribution(hours_value, type)

        unless type == Project::DISTRIBUTION_UNIFORM_DECIMAL
          remainder += hours_value - hours_value_rounded
        end

        if last_day?(day, remaining_data)
          hours_value_rounded = round_distribution(hours_value + remainder, type)
          remainder = 0
        end

        [hours_value_rounded, remainder, capacity]
      end

      def round_distribution(number, type)
        case type
        when Project::DISTRIBUTION_UNIFORM_WHOLE
          return number.floor
        when Project::DISTRIBUTION_UNIFORM_HALF
          return round_down_to_half(number)
        when Project::DISTRIBUTION_UNIFORM_DECIMAL
          return number.round(1)
        end
      end

      def round_down_to_half(number)
        decimal = number - number.floor
        if 0 <= decimal && decimal < 0.5
          return number.floor
        else
          return number.floor + 0.5
        end
      end

      def last_day?(day, remaining_data)
        day == remaining_data[:working_days] - 1
      end

      def delete_fixed(fixed_to_delete)
        fixed_values = RxFixedValue.arel_table
        delete_condition = AREL.arel_db_in(fixed_values[:id], fixed_to_delete)
        RxFixedValue.where(delete_condition).delete_all
      end

      def calculate_remaining_hours(store, issue, external)
        working_days, working_hours = working_days_and_hours_for_resources(store, issue)
        id = issue[ID]
        due_date = issue[DUE_DATE].class == Date ? issue[DUE_DATE] : Date.parse(issue[DUE_DATE])
        estimated_hours = issue[ESTIMATED]
        spent_and_planned = store.data[id] ? store.data[id][:spentTotal] + store.data[id][:fixedTotal] : 0
        result = { remaining_estimated: estimated_hours - spent_and_planned }

        isPast = due_date < Date.today
        if working_days == 0 && result[:remaining_estimated] > 0
          store.add(issue, external, :highEstimation, 1) unless isPast
        elsif result[:remaining_estimated] < 0
          store.add(issue, external, :lowEstimation, 1) unless isPast
        end

        result.merge({ working_hours: working_hours, working_days: working_days })
      end

      def working_days_and_hours_for_resources(store, issue)
        issue_start_date =
          issue[START_DATE].class == Date ? issue[START_DATE] : Date.parse(issue[START_DATE])
        issue_due_date =
          issue[DUE_DATE].class == Date ? issue[DUE_DATE] : Date.parse(issue[DUE_DATE])

        start_date = issue_start_date < Date.today ? Date.today : issue_start_date
        #result = working_days_with_calendars(start_date, issue_due_date + 1)
        working_days, working_hours =
          working_days_with_calendars(start_date, issue_due_date + 1).values_at(:days, :hours)

        if store.data[issue[ID]] && store.data[issue[ID]][:values].any?
          store.data[issue[ID]][:values].each do |date_string, value|
            date = Date.parse(date_string)
            if start_date <= date && date <= issue_due_date &&
               value[:type] == TYPE_FIXED &&
               working_day?(date, true)

              working_days -= 1
              working_hours -= @work_days[date.wday]
            end
          end
        end

        [working_days, working_hours]
      end

      # def working_days_for_resources(store, issue)
      #   non_working_days = Setting.non_working_week_days
      #   start_date =
      #     issue[START_DATE].class == Date ? issue[START_DATE] : Date.parse(issue[START_DATE])
      #   due_date =
      #     issue[DUE_DATE].class == Date ? issue[DUE_DATE] : Date.parse(issue[DUE_DATE])
      #   id = issue[ID]
      #   work_days = 0

      #   current_date = start_date < Date.today ? Date.today : start_date
      #   while current_date <= due_date
      #     if working_day?(current_date, true)
      #       if !store.data[id]
      #         work_days += 1
      #       elsif !store.data[id][:values][current_date.strftime(JS_DATE_FORMAT)]
      #         work_days += 1
      #       end
      #     end
      #     current_date += 1
      #   end
      #   work_days
      # end

      # def add_to_resources(resources, date, hours, type, p_project, p_user)
      #   set_min_end_and_start_date(resources, date, hours, type)

      #   date_str = date.strftime(JS_DATE_FORMAT)
      #   if resources[:values][date_str]
      #     resources[:values][date_str][:hours] += hours
      #   else
      #     resources[:values][date_str] = { hours: hours, type: type }
      #   end

      #   add_to_parent(p_project[:values], date_str, :hours, hours) if p_project
      #   add_to_parent(p_user[:values], date_str, :hours, hours)
      # end

      # def add_to_parent(parent, key, value_name, value, isExternal=false)
      #   return unless parent

      #   if parent[key]
      #     if value_name
      #       derived_key = isExternal ? (value_name.to_s + 'External').to_sym : value_name
      #       if value.class == Integer || value.class == Float
      #         parent[key][derived_key] += value
      #       elsif !isExtrenal
      #         parent[key][derived_key] ||= value
      #       end
      #     else
      #       derived_key = isExternal ? (key.to_s + 'External').to_sym : key
      #       if value.class == Integer || value.class == Float
      #         parent[derived_key] += value
      #       elsif !isExtrenal
      #         parent[derived_key] ||= value
      #       end
      #     end
      #   else
      #     if value_name
      #       parent[key] = {}
      #       derived_key = isExternal ? (value_name.to_s + 'External').to_sym : value_name
      #       parent[key][derived_key] = value
      #     else
      #       derived_key = isExternal ? (key.to_s + 'External').to_sym : key
      #       parent[derived_key] = value
      #     end
      #   end
      # end

      # def set_min_end_and_start_date(resources, date, hours, type)
      #   if type == TYPE_ENTRY && hours > 0
      #     if resources[:min_end_date]
      #       resources[:min_end_date] = date.to_time if resources[:min_end_date] < date
      #     else
      #       resources[:min_end_date] = date.to_time
      #     end

      #     if resources[:min_start_date]
      #       resources[:min_start_date] = date.to_time if resources[:min_start_date] > date
      #     else
      #       resources[:min_start_date] = date.to_time
      #     end
      #   end
      # end

      # def due_date(issue)
      #   if issue.due_date
      #     issue.due_date
      #   elsif issue.closed_on
      #     issue.closed_on
      #   elsif issue.start_date
      #     issue.start_date
      #   else
      #     Date.today
      #   end
      # end

      # def is_non_working_day?(date)
      #   non_working_days = Setting.non_working_week_days
      #   if date.wday == 0
      #     day_number = '7'
      #   else
      #     day_number = date.wday.to_s
      #   end
      #   non_working_days.include?(day_number)
      # end
    end
  end
end