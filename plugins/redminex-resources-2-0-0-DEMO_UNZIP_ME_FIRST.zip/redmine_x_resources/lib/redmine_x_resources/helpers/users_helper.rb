  module RedmineXResources
  module Helpers
    module UsersHelper
      include Redmine::I18n
      AREL = RedmineXAssets::Helpers::ArelFunctionsHelper
      OTHER_USERS_GROUP_ID = 1000000

      # Returns all users data in a format suitable for resources component
      # @param [Array] project_list - array of project ids, which we want to get the user items for
      # @param [Hash] options - list of options with following possiblities:
      #   users_excluded (Array) - array of user ids which don't want to include
      #   exclude_unassigned_user_group (Boolean) - true = we don't want to add special user type for
      #                                             tasks, which are not assigned to any user
      #   include_closed_issues (Boolean) - true = include users which are linked to the closed issues
      # @return [Hash] - data of all users including groups and helper groups
      def self.user_items(project_list, options={})
        users_query = users_query(project_list, options)
        user_values = item_values(users_query)

        users = user_values[:values]
        users += other_users_group if users_query[:users_without_group] || user_values[:unassigned_user_group]
        users += unassigned_user_group unless options[:exclude_unassigned_user_group]
        users
      end

      # Converts user query values into hash, which is sent by the API
      # @param [Array] items - array of arrays of values of users
      # @return [Array] - array of hashes of values of users
      def self.item_values(items)
        unassigned_user_group = false

        unique_items = {}
        items[:users].each do |user|
          if unique_items.include?(user[0])
            item = unique_items[user[0]]
            if items[:groups].include?(user[2]) && !items[:groups].include?(item[2])
              unique_items[user[0]] = user
            end
          else
            unique_items[user[0]] = user
          end
        end

        values = unique_items.map do |_key, item|
          parent = user_parent(item, items[:groups])
          unassigned_user_group = true if parent == OTHER_USERS_GROUP_ID
          {
            id: item[0],
            key: item[0],
            text: item[1],
            label: item[1],
            parent: parent,
            uid: "u#{item[0]}",
            uparent: parent ? "u#{parent}" : nil,
            utype: item[3].downcase
          }
        end
        { values: values, unassigned_user_group: unassigned_user_group }
      end

      def self.user_parent(user, groups)
        if groups.include?(user[2])
          user[2]
        elsif user[3] == 'User'
          OTHER_USERS_GROUP_ID
        else
          nil
        end
      end

      # SQL query to get all users in project_list
      # @param [Array] project_list - list of ids of projects, which members shell be loaded
      # @param [Hash] options - list of options with following possiblities:
      #   users_excluded (Array) - array of user ids which don't want to load
      #   include_closed_issues (Boolean) - true = include users which are linked to the closed issues
      # @return [Array] - array of all users except locked ones and anonymous
      def self.users_query(project_list, options={})
        projects = Project.arel_table
        users = User.arel_table
        members = Member.arel_table
        groups_users = Arel::Table.new('groups_users')
        issues = Issue.arel_table

        groups_users_join = users.join(groups_users, Arel::Nodes::OuterJoin).on(groups_users[:user_id].eq(users[:id])).join_sources

        user_name = AREL.arel_db_if(
          users[:firstname].eq(nil).or(users[:firstname].eq('')),
          users[:lastname],
          AREL.arel_db_concatenation(users[:firstname], ' ', users[:lastname])
        )

        unassigned_condition = users[:type].eq('User').and(groups_users[:group_id].eq(nil))

        parent = AREL.arel_db_if(
          unassigned_condition,
          Arel::Nodes::SqlLiteral.new(OTHER_USERS_GROUP_ID.to_s),
          groups_users[:group_id].maximum
        )

        if project_list
          user_clauses = []

          #members_condition = members.where(members[:project_id].in(projects.where(projects[:id].in(project_list)).project(projects[:id]))).project(members[:user_id])
          members_condition = Member.where(members[:project_id].in(project_list)).distinct.pluck(:user_id)
          user_clauses << users[:id].in(members_condition)

          issue_list = options[:include_closed_issues] ? Issue.all : Issue.open
          #issues_input_author_id = issues.where(issues[:project_id].in(projects.where(projects[:id].in(project_list)).project(projects[:id]))).project(issues[:author_id])
          issues_input_author_id = issue_list.where(issues[:project_id].in(project_list)).distinct.pluck(:author_id)
          user_clauses << users[:id].in(issues_input_author_id)

          #issues_input_assg_to_id = issues.where(issues[:project_id].in(projects.where(projects[:id].in(project_list)).project(projects[:id]))).project(issues[:assigned_to_id])
          issues_input_assg_to_id = issue_list.where(issues[:project_id].in(project_list)).distinct.pluck(:assigned_to_id)
          user_clauses << users[:id].in(issues_input_assg_to_id)

          user_clauses << users[:id].eq(User.current.id)

          users_condition = users.grouping(
            user_clauses.reduce do |clause, cond|
              Arel::Nodes::Or.new(clause, cond)
            end
          )
        else
          users_condition = ''
        end

        users_excluded_condition = users[:id].not_in(options[:users_excluded] || [])
        users_group_condition = users[:type].eq('Group')
        users_user_group_condition = users[:type].eq('Group').or(users[:type].eq('User'))

        result_users =
          Principal
          .joins(groups_users_join)
          .where(users_condition)
          .where(users_user_group_condition)
          .where(users_excluded_condition)
          .group(users[:id], groups_users[:group_id])
          .order(users[:type], users[:id], groups_users[:group_id])
          .pluck(users[:id], user_name, parent, users[:type])

        users_without_group =
          Principal
          .joins(groups_users_join)
          .where(users_condition)
          .where(users_user_group_condition)
          .where(users_excluded_condition)
          .where(unassigned_condition)
          .group(users[:id])
          .pluck(users[:id])
          .count

        groups =
          Principal
          .where(users_condition)
          .where(users_excluded_condition)
          .where(users_group_condition)
          .group(users[:id])
          .pluck(users[:id])

        { users: result_users, users_without_group: users_without_group > 0, groups: groups }
      end

      # Creates group for users who are not members of any group
      # @return [Hash] - other users group values
      def self.other_users_group
        [
          {
            id: OTHER_USERS_GROUP_ID,
            key: OTHER_USERS_GROUP_ID,
            text: l(:other_users_group, { scope: :redmine_x_resources }),
            label: l(:other_users_group, { scope: :redmine_x_resources }),
            parent: nil,
            uid: "u#{OTHER_USERS_GROUP_ID}",
            utype: 'group',
            uparent: nil
          }
        ]
      end

      # Creates unassigned user (used in resources to label task without assigned user)
      # @return [Hash] - unassigned user values
      def self.unassigned_user_group
        [
          {
            id: -1,
            key: -1,
            text: l(:task_unassigned, { scope: :redmine_x_resources }),
            label: l(:task_unassigned, { scope: :redmine_x_resources }),
            parent: nil,
            uid: "u-1",
            utype: 'group',
            uparent: nil
          }
        ]
      end

      # Hierarchize user items (groups = level 0, users = level 1)
      # @param [Array] item - array of hashes of values of users
      # @return [Array] - array of hashes of values of users
      def self.hierarchize_items(items)
        groups = []
        children = []
        items.each do |item|
          if item[:utype] == 'group'
            item[:level] = 0
            groups << item
          else
            item[:level] = 1
            children << item
          end
        end
        result = []

        groups.each do |group|
          result << group
          i = 0
          while i < children.count
            if children[i][:parent] == group[:id]
              result << children[i] 
              children.delete_at(i)
            else
              i += 1
            end
          end
        end
        result
      end

    end
  end
end
