module RedmineXResources
  module Patches
    module ProjectPatch
      def self.included(receiver)
        distribution_uniform_whole   = 'uniform_whole'
        distribution_uniform_half    = 'uniform_half'
        distribution_uniform_decimal = 'uniform_decimal'
        distribution_from_start      = 'from_start'
        distribution_from_end        = 'from_end'

        distributions = [
          distribution_uniform_whole,
          distribution_uniform_half,
          distribution_uniform_decimal,
          distribution_from_start,
          distribution_from_end
        ]

        receiver.class_eval do
          const_set(:DISTRIBUTION_UNIFORM_WHOLE  , distribution_uniform_whole)
          const_set(:DISTRIBUTION_UNIFORM_HALF   , distribution_uniform_half)
          const_set(:DISTRIBUTION_UNIFORM_DECIMAL, distribution_uniform_decimal)
          const_set(:DISTRIBUTION_FROM_START     , distribution_from_start)
          const_set(:DISTRIBUTION_FROM_END       , distribution_from_end)

          validates_inclusion_of(:rx_resources_distribution, in: distributions)
        end
     end
    end
  end
end
unless Project.included_modules.include?(RedmineXResources::Patches::ProjectPatch)
  Project.send(:include, RedmineXResources::Patches::ProjectPatch)
end

