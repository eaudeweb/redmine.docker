const FIXED_VALUES_URL = '/redmine_x_resources/api/v1/fixed.json';
/**
* Saving functionality - collects all changes and then sends them on the save button click
*/

export class Saver extends RXA.Saver {
    constructor() {
        super();

        gantt.fixedSendingStack = [];
    }

    /**
     * Adds one fixed value to the sending stack
     * @param {Date object} date - date of the fixed value
     * @param {Float} hours - float value of fixed hours (0..24)
     * @param {String} taskId - id of task, for which the fixed value belongs
     * @return {void}
     */
    addFixedToSendingStack(date, hours, taskId) {
        gantt.fixedSendingStack.push(
            {
                hours,
                date: date.toDateString(),
                author_id: userId,
                issue_id: RXA.common.cleanId(taskId)
            }
        );
    }

    /**
     * Prepares all fixed values in fixedSendingStack for sending
     * @return {Object} - returns object with fixed values in correct format for sending
     */
    prepareFixedForSending() {
        const url = `${pathsToActions.plugin}/api/v1/fixed.json`;
        const data = { fixed_values: [] }
        for (let i = 0; i < gantt.fixedSendingStack.length; i++) {
            delete gantt.fixedSendingStack[i]['count'];
            data.fixed_values.push(gantt.fixedSendingStack[i]);
        }

        return { url, method: 'POST', data };
    }

    /**
    * Save action is started here. Sends all changes in sending stack and shows info
    * to the user (in case of error or success)
    * @param {Event Object} event - details about click event
    * @return {void} nothing is returned sending stack is modified directly
    */
   async saveButtonOnClick(event) {
        const common = RXA.common;
        event.target.disabled = true;

        let message;
        let number = super.countItemsInSendingStack();
        let numberOfFixed = 0;
        gantt.fixedSendingStack.forEach(item => numberOfFixed += item.count ? 1 : 0)

        if (await this.sendStacks()) {
            message = `<u>${I18n.saving_succesful}</u>` +
            (number[common.TYPE_PROJECT] > 0 ? `<br/>${number[common.TYPE_PROJECT]} ${I18n.saving_project_operations}` : '' ) +
            (number[common.TYPE_TASK] > 0 ? `<br/>${number[common.TYPE_TASK]} ${I18n.saving_task_operations}` : '' ) +
            (number[common.TYPE_MILESTONE] > 0 ? `<br/>${number[common.TYPE_MILESTONE]} ${I18n.saving_milestone_operations}` : '') +
            (number[common.TYPE_LINK] > 0 ? `<br/>${number[common.TYPE_LINK]} ${I18n.saving_link_operations}` : '')

            if (numberOfFixed === 1) {
                message += `<br/>${numberOfFixed} ${I18n.saving_fixed_operations}`;
            } else if (1 < numberOfFixed && numberOfFixed < 5) {
                message += `<br/>${numberOfFixed} ${I18n.saving_fixed_operations_plural_1}`;
            } else if (5 <= numberOfFixed) {
                message += `<br/>${numberOfFixed} ${I18n.saving_fixed_operations_plural_2}`;
            }

            gantt.message.position = 'bottom';
            gantt.message({ type: 'info', text: message, expire: 10000 });
        } else {
            message = `<u>${I18n.saving_error}</u><br/><br/>`
            this.errorMessagesStack.forEach(error => { message += `${error}<br/>`});

            gantt.alert({ text: message, title: "Error!", ok: "OK", type: "gantt-modal-error" });
            this.errorMessagesStack = [];
        }

        event.target.disabled = false;
    }

    /**
    * Sends all items from both stacks to Redmine using Redmine API
    * @return {Boolean} false in case of errors, true, when everything was saved ok
    */
    async sendStacks() {
        const common = RXA.common;
        let result;
        console.log('Sending stack before sending', this.sendingStack, gantt.fixedSendingStack);
        // Copy the sending stacks to new object and empty the global stacks
        const sendingStackCopy = common.deepCopy(this.sendingStack);
        this.sendingStack = [];

        // If there are link operations, which include links leading to or from tasks,
        // which will be deleted, we have to remove these operations from the stack
        super.checkLinksSendingStack(sendingStackCopy);

        // Send tasks operations synchronously
        for (let i = 0; i < sendingStackCopy.length; i++) {
            try {
                result = await super.sendOneItem(sendingStackCopy[i]);
            } catch (error) {
                super.handleFetchError(sendingStackCopy[i], error);
            }
            if (sendingStackCopy[i].type === common.TYPE_TASK) {
                super.handleTasksResult(result, sendingStackCopy[i], sendingStackCopy);
            } else if (sendingStackCopy[i].type === common.TYPE_MILESTONE) {
                super.handleMilestonesResult(result, sendingStackCopy[i], sendingStackCopy);
            } else {
                super.handleLinksResult(result, sendingStackCopy[i]);
            }
            sendingStackCopy.splice(i, 1);
            i--;
        }

        if (gantt.fixedSendingStack.length > 0) {
            try {
                result = await super.sendOneItem(this.prepareFixedForSending());
                gantt.fixedSendingStack = [];
            } catch (error) {
                super.handleFetchError( { action: common.ACTION_FIXED }, error);
            }
        }

        // If there were errors, we copy the operations, which were not completed
        // succesfully back to the global stacks to enable retry
        this.sendingStack = common.deepCopy(sendingStackCopy);

        return (this.errorMessagesStack.length === 0);
    }

    handleTasksResult(result, task, sendingStackCopy) {
        if (result && result.issue) {
            const newId = `i${result.issue.id}`;
            gantt.changeTaskId(task.id, newId);

            const store = gantt.resourcesStore.store;
            if (store[task.uid]) {
                delete Object.assign(store, {[newId]: store[task.uid] })[task.uid];
            }

            for (let i = 0; i < sendingStackCopy.length; i ++) {
                let item = sendingStackCopy[i];
                if (item.type === TYPE_LINK && item.action === ACTION_CREATE) {
                    if (item.data.relation.issue_to_id === task.id.toString()) {
                        item.data.relation.issue_to_id = result.issue.id;
                    }
                    if (item.url.search(task.id) > 0) {
                        item.url = item.url.replace(task.id, result.issue.id);
                    }
                }
                if (item.type === TYPE_TASK && item.action === ACTION_CREATE) {
                    if (item.data.issue.parent_issue_id === task.id.toString()) {
                        item.data.issue.parent_issue_id = result.issue.id;
                    }
                }
                if (item.type === TYPE_TASK && item.id === task.id) {
                    item.data.id = result.issue.id;
                    item.url = item.url.replace(task.id, result.issue.id);
                }
            }

            const newTask = gantt.getTask(newId);
            newTask.type = "task";
            gantt.refreshTask(newId);
        }
    }
}