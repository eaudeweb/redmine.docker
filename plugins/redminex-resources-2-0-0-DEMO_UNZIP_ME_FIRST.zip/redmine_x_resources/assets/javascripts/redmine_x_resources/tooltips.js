import { round1D, calculateUserCapacity, calculateGroupCapacity, nextEndDate } from './common.js';
export class Tooltips extends RXA.Tooltips {
    initTooltips() {
        gantt.plugins({ tooltip: true });

        gantt.attachEvent('onGanttReady', () => {
            const tooltips = gantt.ext.tooltips;

            // // Tooltip for links
            tooltips.tooltipFor({
                selector: '.gantt_task_link',
                html: this.setLinksTooltipText.bind(this),
            });

            // Tooltip for spent time grid header
            tooltips.tooltipFor({
                selector: '.gantt_grid_head_spent',
                html: this.setSpentTimeTooltipText.bind(this),
            });

            // Tooltip for tasks
            tooltips.tooltipFor({
                selector: '.gantt_task_line',
                html: this.setTaskTooltipText.bind(this),
            });

            // Tooltip for tasks
            tooltips.tooltipFor({
                selector: 'div.resource-task-box',
                html: this.setTaskTooltipText.bind(this),
            });

            // Tooltip for grid warnings (triangular warning icon)
            tooltips.tooltipFor({
                selector: '.gantt_row',
                html: (event, node) => {
                    if (event.target.classList.contains('warning-icon') ||
                        event.target.classList.contains('fa-exclamation-triangle'))
                    {
                        return this.setWarningIconTooltipText(node.querySelector('div.warning-icon'));
                    } else {
                        return '';
                    }
                }
            });
        });
    }

    /**
    * Returns html of item (task, project, milestone) tooltip, depending on the type of item
    * @param {Object} event - original mouse event, which triggered the tooltip
    * @param {Object} node - html element, which the mouse pointer is pointing on,
    *                        when the tooltip was triggered
    * @return {String} - html of tooltip
    */
    setTaskTooltipText(event, node) {
        const bodyR = node.getBoundingClientRect();
        if (event.screenX < bodyR.x || bodyR.x + bodyR.width < event.screenX) {
            return null;
        }

        const id = node.dataset.taskId;
        const task = gantt.getTask(id);

        switch(task.type) {
            case RXA.common.TYPE_TASK:
                return(this.taskHtml(event, bodyR, task));
            case RXA.common.TYPE_PROJECT:
                return(this.projectHtml(event, bodyR, task));
            case RXA.common.TYPE_MILESTONE:
                return(this.milestoneBasicHtml(task));
        }
        return null;
    }

    /**
     * Returns html for project (user, group) tooltip
     * @param {Object} event - original mouse event, which triggered the tooltip
     * @param {Object} bodyR - project task dimensions object obtained by the getBoundingClientRect
     *                         function
     * @param {Object} task - task object for which the tooltip is intended for
     * @returns {String} - html string of the tooltip
     */
    projectHtml(event, bodyR, task) {
        const currentMarker = this.getCurrentMarker(event, bodyR, task);
        const planned = currentMarker ? parseFloat(currentMarker.innerText) : NaN;

        let html = ''
        if (currentMarker && !isNaN(planned)) {
            html += this.periodHtml(currentMarker, task);
            html += this.horizontalLine(14);
        }
        html += this.wholeProjectHtml(task);

        return html;
    }

    /**
     * Returns html for task tooltip
     * @param {Object} event - original mouse event, which triggered the tooltip
     * @param {Object} bodyR - task dimensions object obtained by the getBoundingClientRect
     *                         function
     * @param {Object} task - task object for which the tooltip is intended for
     * @returns {String} - html string of the tooltip
     */
    taskHtml(event, bodyR, task) {
        const currentMarker = this.getCurrentMarker(event, bodyR, task);

        let html = '';
        if (currentMarker) {
            html += this.periodHtml(currentMarker, task);
            html += this.horizontalLine(14);
        }
        html += this.wholeTaskHtml(task);

        return html;
    }

    /**
     * Returns html for one resource marker depending on the period (day, week, month...)
     * @param {Object} currentMarker - html element of the resource marker for which the html
     *                                 should be generated
     * @param {Object} task - task object for which the tooltip is intended for
     * @returns {String} - html of the resource marker tooltip, which is part of the whole task tooltip
     */
    periodHtml(currentMarker, task) {
        let calendar;
        if (task.type == RXA.common.TYPE_TASK) {
            calendar = gantt.getTaskCalendar(task);
        } else if (task.type == RXA.common.TYPE_PROJECT) {
            if (task.utype && task.key) {
                calendar = gantt.getCalendar(task.key);
            }
        }
        if (!calendar) calendar = gantt.getCalendar('global');

        const holidaysConfig = calendar.getConfig();

        if (task.type == RXA.common.TYPE_TASK) {
            return (
                this.periodTitleHtml(currentMarker, holidaysConfig) +
                this.taskCapacityHtml(currentMarker, calendar)
            );
        } else if (task.type == RXA.common.TYPE_PROJECT) {
            return (
                this.periodTitleHtml(currentMarker, holidaysConfig) +
                this.projectCapacityHtml(task, currentMarker)
            );
        }

        return '';
    }

    /**
     * Retruns html element of the resource marker on which the mouse pointer points
     * @param {Object} event - original mouse event, which triggered the tooltip
     * @param {Object} bodyR - project task dimensions object obtained by the getBoundingClientRect
     *                         function
     * @param {Object} task - task object for which the tooltip is intended for
     * @returns {Object} - html element of the current resource marker
     */
    getCurrentMarker(event, bodyR, task) {
        const level = gantt.ext.zoom.getCurrentLevel();
        const zoom = gantt.ext.zoom.getLevels()[level].name;

        if (zoom === RXA.common.ZOOM_DAY)
        {
            const taskX = event.screenX - bodyR.x;
            const taskPos = gantt.getTaskPosition(task);
            const date = gantt.dateFromPos(taskPos.left + taskX).toDateString();
            const resourceBox = document.querySelector(`#resource-${task.uid}`);
            return resourceBox.querySelector(`div.resource-marker[data-start-date="${date}"]`);
        } else {
            if (task.type == RXA.common.TYPE_TASK) {
                const taskPos = gantt.getTaskPosition(task);
                const cursorDate = gantt.dateFromPos(event.screenX - bodyR.left + taskPos.left);
                if (RXA.common.diffDates(new Date(), cursorDate) < 0) return null;
                const nextEnd = nextEndDate(new Date(cursorDate.toDateString()), task.end_date, zoom);
                const resourceMarker = document.querySelector(`#resource-${task.uid} div.resource-marker[data-end-date="${nextEnd.toDateString()}"]`);
                return resourceMarker;
            } else {
                const resourceMarkers = document.querySelectorAll(`#resource-${task.uid} div.resource-marker`);
                const markerWidth = bodyR.width / resourceMarkers.length;
                const markerNum = Math.floor((event.screenX - bodyR.x) / markerWidth);
                return resourceMarkers[markerNum];
            }
        }
    }

    /**
     * Returns html of the title of the resource marker tooltip = name of the period (day, week, month..)
     * and further info about the period (working, non-working, holiday etc.)
     * @param {Object} currentMarker - html element of the resource marker for which the title is intended for
     * @param {Object} holidaysConfig - holiday object with all holidays in the calendar of the task, which
     *                                  contains currentMarker element
     * @returns {String} - html string of the title of the resource marker tooltip
     */
    periodTitleHtml(currentMarker, holidaysConfig) {
        const start = new Date(currentMarker.dataset.startDate);
        const end = new Date(currentMarker.dataset.endDate);

        if (RXA.common.diffDates(start, end) > 1) {
            return this.titleHtml(currentMarker.dataset.periodName.toUpperCase());
        }

        let dayTypeHtml = '';
        let holidayType = '';
        const nonWorkingDay = currentMarker.classList.contains('dayoff');
        if (nonWorkingDay) {
            const holiday = this.findHoliday(start, holidaysConfig);
            dayTypeHtml = ` (${I18n.tooltip_non_working_day})`;

            holidayType = holiday ? `${holiday.type} (${holiday.name})</br>` + this.marginDivHtml(3) : '';
        }  else {
            dayTypeHtml = ` (${I18n.tooltip_working_day})`;
        }
        return (
            this.titleHtml(currentMarker.dataset.periodName.toUpperCase() + dayTypeHtml) +
            holidayType
        );
    }

    /**
     * Returns html of the capacity box of the period (day, week, month...) of a task defined by
     * the given resource marker
     * @param {Object} currentMarker - html element of the resource marker for which the capacity box
     *                                 is intended for
     * @param {Object} calendar - calendar of the task, which contains currentMarker element
     * @returns {String} - html string of the capacity box and its legend
     */
    taskCapacityHtml(currentMarker, calendar) {
        const level = gantt.ext.zoom.getCurrentLevel();
        const zoom = gantt.ext.zoom.getLevels()[level].name;

        const start = new Date(currentMarker.dataset.startDate);
        const end = new Date(currentMarker.dataset.endDate);

        const workDays = calendar.calculateDuration(start, end);
        const workHours = calendar._calculateDuration(start, end, 'hour', 1);

        let html = '';


        if (zoom !== RXA.common.ZOOM_DAY) {
            html += this.legendValueHtml(I18n.tooltip_total_capacity, `${workHours}h/${workDays}d`);
        }

        let planned = parseFloat(currentMarker.innerText);
        let plannedStyle = 'border: 1px solid black; color: black';
        if (planned > workHours) {
            plannedStyle = 'border: 1px solid red; color: red';
        } else if (planned > 0) {
            plannedStyle = 'border: 1px solid green; color: green';
        }

        html += this.divTagHtml('display: flex; align-items: center;',
            this.divTagHtml('',
                `<b>${I18n.tooltip_planned}/${I18n.tooltip_capacity} ${I18n.tooltip_hour_short}: </b>`
            ) +
            this.divTagHtml(`padding: 2px 3px; ${plannedStyle}; border-radius: 3px; margin-left: 4px; line-height: 10px;`,
                `<b>${planned} / ${workHours}</b>`
            ) +
            '</br>'
        );

        return html;
    }

    /**
     * Returns html of the capacity box of the period (day, week, month...) of a project (user, group)
     * defined by the given resource marker
     * @param {Object} task - task object of the project for which the capacity box html is intended for
     * @param {Object} currentMarker - html element of the resource marker for which the capacity box
     *                                 is intended for
     * @returns {String} - html string of the capacity box and its legend
     */
    projectCapacityHtml(task, currentMarker) {
        const start = new Date(currentMarker.dataset.startDate);
        const end = new Date(currentMarker.dataset.endDate);

        let workHours = null;
        if (gantt.$groupMode && task.utype == 'user') {
            workHours = calculateUserCapacity(task, start, end);
        } else if (gantt.$groupMode && task.utype == 'group') {
            workHours = calculateGroupCapacity(task, start, end);
        }

        let html = '';

        const planned = parseFloat(currentMarker.innerText);
        const here = parseFloat(currentMarker.dataset.here);
        const external = parseFloat(currentMarker.dataset.external);


        let plannedColor = 'black';
        if (gantt.$groupMode && task.utype == 'user') {
            if (planned > workHours) {
                plannedColor = 'red';
             } else if (planned > 0) {
                 plannedColor = 'green';
             }
        }

        const plannedBoxStyle =
            `padding: 2px 3px; border: 1px solid ${plannedColor}; color: ${plannedColor}; border-radius: 3px; margin-left: 4px; line-height: 10px;`;

        const capacityLegend =
            workHours ? `<b>${I18n.tooltip_planned}/${I18n.tooltip_capacity} ${I18n.tooltip_hour_short}: </b>` : `<b>${I18n.tooltip_planned} ${I18n.tooltip_hour_short}: </b>`;

        const capacityValue =
            workHours ? `<b>${planned} / ${workHours}</b>` : `<b>${planned}</b>`;

        html += this.divTagHtml('display: flex; align-items: center;',
            this.divTagHtml('', capacityLegend) +
            this.divTagHtml(plannedBoxStyle, capacityValue)
        );

        if (gantt.$groupMode && task.uid != 'u-1') {
            html += this.marginDivHtml(5);
            html += this.tableCapacity(planned, here, external, workHours, plannedColor);
        }

        return html;
    }

    /**
     * Returns type of the holiday (+further info) for the given date (if there is any)
     * @param {Date} date - date for which we want to find out the holiday type
     * @param {Date} holidaysConfig - holiday object with all holidays in the calendar of the task,
     *                                for which we want to find the holiday info for
     * @returns {Object} - object with type of the holiday (public, private) and name (for public holidays
     *                     => name, for private => user or group name).
     */
    findHoliday(date, holidaysConfig) {
        const boundaries = holidaysConfig.parsed.customWeeksBoundaries;
        let holidayObject = { type: '', items: [] };
        for (let i = 0; i < boundaries.length; i++) {
            if (boundaries[i].from <= date.getTime() && date.getTime() < boundaries[i].to) {
                const name = this.holidaysName(boundaries[i].name);
                if (name) {
                    if (name.type == 'public' || holidayObject.type != 'public') {
                        if (name.type == 'public') {
                            holidayObject.items = [name.item];
                        } else {
                            holidayObject.items.push(name.item);
                        }
                        holidayObject.type = name.type;
                    }
                }
            }
        }
        if (holidayObject.type == '') return null;

        const result = {}
        result.name = holidayObject.items.join(', ');
        if (result.name.length > 100) {
            result.name = holidayObject.name.substring(0, 100) + '...';
        }

        if (holidayObject.type == 'public') {
            result.type = I18n.tooltip_public_holiday;
        } else {
            result.type = I18n.tooltip_personal_holiday;
        }

        return result;
    }

    /**
     * Decomposes holiday name string into type and item info
     * @param {String} name - name string of the specific holiday
     * @returns {Object} - object with type and item keys, with extracted holiday info
     */
    holidaysName(name) {
        const nameSplited = name.split('##');
        if (nameSplited.length <= 2) {
            return null;
        }

        return { type: nameSplited[0], item: nameSplited[1] };
    }

    /**
     * Returns html of warning icon tooltip
     * @param {Object} event - standard event object of event, which triggered tooltip
     * @param {Object} node - element object of link, which triggered the tooltip event
     * @return {String} - html of tooltip
     */
    setWarningIconTooltipText(node) {
        const warning = node.dataset.warning;
        let message = '';
        if (warning.includes('hours_overflow')) {
            message += `<u><b>${I18n.tooltip_hours_overflow_title}</b></u>` +
                       `<p>${I18n.tooltip_hours_overflow_text}</p>`
        }
        if (warning.includes('estimation_high')) {
            message += `<u><b>${I18n.tooltip_estimation_high_title}</b></u>` +
                       `<p>${I18n.tooltip_estimation_high_text}</p>`
        }
        if (warning.includes('estimation_low')) {
            message += `<u><b>${I18n.tooltip_estimation_low_title}</b></u>` +
                       `<p>${I18n.tooltip_estimation_low_text}</p>`
        }

        message = `<div style="width: 160px;white-space: normal !important;">${message}</div>`;

        return message;
    }

    /**
     * Returns html of spent time grid column tooltip
     * This tooltip explains how spent itme is presented in the grid
     * @param {Object} event - standard event object of event, which triggered tooltip
     * @param {Object} node - element object of link, which triggered the tooltip event
     * @return {String} - html of tooltip
     */
    setSpentTimeTooltipText(event, node) {
         const message = '<u><b>Spent time</b></u><br>' +
                         '<ul class="tooltip-spent-time-list">' +
                         `<li>${I18n.tooltip_grid_spent_time_task}</li>` +
                         `<li>${I18n.tooltip_grid_spent_time_group}</li>` +
                         '</ul>';
        return message;
    }

    /**
     * Returns task's parent task(s)
     * @param {Task Object} task - task for which the parents we want to get
     * @return {String} - html (text) of task's parents
     */
    getTaskParents(task) {
        let taskParents = '';

        let currentTask = task;
        while (currentTask.parent) {
            const parent = gantt.getTask(currentTask.parent);
            if (parent.type === RXA.common.TYPE_PROJECT) {
                return taskParents;
            }

            if (taskParents.length > 0) {
                taskParents += ' -> ';
            }

            const parentName = parent.text.length > 50 ? `${parent.text.substring(0, 50)}...` : parent.text;
            taskParents += `${RXA.common.subjectTaskId(parent)} ${parentName}`;
            currentTask = parent;
        }

        return taskParents;
    }

    /**
     * Returns html of the whole project (user, group) task tooltip - this is html of the whole task
     * (not time period specific)
     * @param {Task Object} task - project for which the tooltip html is prepared for
     * @return {String} - html string of the whole project task tooltip
     */
    wholeProjectHtml(task) {
        if (gantt.$groupMode) {
            const store = gantt.resourcesStore.store;
            let planned = 0;
            let plannedExternal = 0;
            let fixed = 0;
            let fixedExternal = 0;
            let distributionTotal = 0;
            let distributionTotalExternal = 0;
            let estimated = 0;
            let estimatedExternal = 0;
            let spent = 0;
            let spentExternal = 0;
            let remaining = 0;
            let remainingExternal = 0;
            let remainingEstimated = 0;
            let remainingEstimatedExternal = 0;
            let warning = '';

            if (store[task.uid]) {
                const data = store[task.uid].resourceObject.data

                estimated                   = round1D(data.estimated);
                estimatedExternal           = round1D(data.estimatedExternal) || 0;
                spent                       = round1D(data.spentTotal);
                spentExternal               = round1D(data.spentTotalExternal) || 0;
                remaining                   = round1D(data.estimated - data.spentTotal);
                remainingExternal           = round1D(data.estimatedExternal - data.spentTotalExternal) || 0;
                remainingEstimated          = round1D(data.estimated - data.spentTotal -
                                                      data.hoursDistributionTotal - data.fixedTotal);
                remainingEstimatedExternal  = round1D(data.estimatedExternal - data.spentTotalExternal -
                                                      data.hoursDistributionTotalExternal - data.fixedTotalExternal) || 0;
                planned                     = round1D(data.hoursDistributionTotal + data.fixedTotal);
                plannedExternal             = round1D(data.hoursDistributionTotalExternal +
                                                      data.fixedTotalExternal) || 0;
                fixed                       = round1D(data.fixedTotal);
                fixedExternal               = round1D(data.fixedTotalExternal) || 0;
                distributionTotal           = round1D(data.hoursDistributionTotal);
                distributionTotalExternal   = round1D(data.hoursDistributionTotalExternal) || 0;

                if (store[task.uid].resourceObject.data.highEstimation) {
                    warning = this.marginDivHtml(5) +
                              `<span style="color:red">${I18n.tooltip_estimation_high_title}:</span><br/>`;
                }
                if (store[task.uid].resourceObject.data.lowEstimation) {
                    warning = this.marginDivHtml(5) +
                              `<span style="color:red">${I18n.tooltip_estimation_low_title}:</span><br/>`;
                }

                if (warning.length > 0) {
                    warning += `${I18n.grid_column_estimated} - ${I18n.grid_column_spent} - ${I18n.tooltip_planned} =<br/>` +
                    `= ${estimated + estimatedExternal} - ${spent + spentExternal} - ${planned + plannedExternal} ` +
                    `= <b><span style="color:red">${remainingEstimated + remainingEstimatedExternal} h</span></b>`;
                }
            }

            const hereExternal = `(${I18n.tooltip_here}/${I18n.tooltip_external})`;

            return (
                this.titleHtml(`${RXA.common.TYPE_TRANSLATIONS[task.utype].toUpperCase()} ${task.text}`) +
                this.divTagHtml('display: flex',
                    this.divTagHtml('margin-right: 10px',
                        this.tableValuesHtml(
                            [`${I18n.grid_column_estimated} ${I18n.tooltip_hour_short} ${hereExternal}`, `${estimated} / ${estimatedExternal}`],
                            [`${I18n.grid_column_spent} ${I18n.tooltip_hour_short} ${hereExternal}`    , `${spent} / ${spentExternal}`        ],
                            [`${I18n.grid_column_remaining} ${I18n.tooltip_hour_short} ${hereExternal}`, `${remaining} / ${remainingExternal}`],
                        )
                    ) +
                    this.divTagHtml('',
                        this.tableValuesHtml(
                            [`${I18n.tooltip_planned} ${I18n.tooltip_hour_short} ${hereExternal}`, `${planned} / ${plannedExternal}`                    ],
                            [`${I18n.tooltip_distribution_total} ${hereExternal}`                , `${distributionTotal} / ${distributionTotalExternal}`],
                            [`${I18n.tooltip_fixed} ${hereExternal}`                             , `${fixed} / ${fixedExternal}`                        ],
                        )
                    )
                ) +
                warning
            );
        } else {
            let parentProject = ''
            if (task.parent_project_id) {
                parentProject =
                    this.legendValueHtml(
                        I18n.parent_project,
                        `#${task.parent_project_id}: ${task.parent_project_name}`,
                    ) + this.marginDivHtml(5);
            }

            return (
                this.titleHtml(`${RXA.common.TYPE_TRANSLATIONS[task.utype].toUpperCase()} ${task.text}`) +
                parentProject +
                this.divTagHtml('display: flex',
                    this.divTagHtml('margin-right: 10px',
                        this.tableValuesHtml(
                            [ I18n.field_start_date      , RXA.common.dateToStr(task.start_date)                          ],
                            [ I18n.field_due_date        , RXA.common.dateToStr(gantt.date.add(task.end_date, -1, "day")) ],
                        )
                    ) +
                    this.divTagHtml('',
                        this.tableValuesHtml(
                            [ I18n.field_estimated_hours , task.estimated_hours || 0                                      ],
                            [ I18n.label_total_time      , task.total_hours || 0                                          ],
                        )
                    )
                )
            );
        }
    }

    /**
     * Returns html of whole task tooltip - this is html of the whole task (not time period specific)
     * @param {Task Object} task - task for which the tooltip html is prepared for
     * @return {String} - html string of the whole task tooltip
     */
    wholeTaskHtml(task) {
        const store = gantt.resourcesStore.store;
        let planned = 0;
        let fixed = 0;
        let distributionTotal = 0;
        let estimated = 0;
        let spent = 0;
        let remaining = 0;
        let remainingEstimated = 0;
        let warning = '';

        const projectId = RXA.common.getProjectId({ task });
        const project = gantt.getTask(projectId);
        const parents = this.getTaskParents(task);

        if (store[task.uid]) {
            planned = store[task.uid].resourceObject.data.hoursDistributionTotal +
                    store[task.uid].resourceObject.data.fixedTotal;
            fixed = store[task.uid].resourceObject.data.fixedTotal;
            distributionTotal = store[task.uid].resourceObject.data.hoursDistributionTotal;

            estimated           = round1D(task.estimated_hours);
            spent               = round1D(task.total_hours);
            remaining           = round1D((task.estimated_hours - task.total_hours));
            remainingEstimated  = round1D((estimated - spent - planned));
            planned             = round1D(planned);
            fixed               = round1D(fixed);
            distributionTotal   = round1D(distributionTotal);
            planned             = round1D(planned);

            if (store[task.uid].resourceObject.data.highEstimation) {
                warning = this.marginDivHtml(5) +
                            `<b><span style="color:red">${I18n.tooltip_estimation_high_title}:</span></b><br/>`;
            }
            if (store[task.uid].resourceObject.data.lowEstimation) {
                warning = this.marginDivHtml(5) +
                            `<b><span style="color:red">${I18n.tooltip_estimation_low_title}:</span></b><br/>`;
            }

            if (warning.length > 0) {
                warning += `${I18n.grid_column_estimated} - ${I18n.grid_column_spent} - ${I18n.tooltip_planned} =<br/>` +
                `= ${estimated} - ${spent} - ${planned} = <b><span style="color:red">${remainingEstimated} h</span></b>`;
            }
        }

        return (
            this.titleHtml(`${RXA.common.TYPE_TRANSLATIONS[task.type].toUpperCase()} ${RXA.common.subjectTaskId(task)}: ${task.text}`) +
            this.legendValueHtml(I18n.label_project, `#${project.id} ${project.name}`) +
            (parents.length > 0 ? this.legendValueHtml(I18n.tooltip_parent_tasks, parents) : '') +
            this.marginDivHtml(5) +
            this.divTagHtml('display: flex',
                this.divTagHtml('margin-right: 10px',
                    this.tableValuesHtml(
                        [`${I18n.grid_column_estimated} ${I18n.tooltip_hour_short}`, estimated],
                        [`${I18n.grid_column_spent} ${I18n.tooltip_hour_short}`    , spent    ],
                        [`${I18n.grid_column_remaining} ${I18n.tooltip_hour_short}`, remaining],
                    )
                ) +
                this.divTagHtml('',
                    this.tableValuesHtml(
                        [`${I18n.tooltip_planned} ${I18n.tooltip_hour_short}`, planned          ],
                        [I18n.tooltip_distribution_total                     , distributionTotal],
                        [I18n.tooltip_fixed                                  , fixed            ],
                    )
                )
            ) +
            warning
        );
    }

    // /**
    //  * Returns html of the div element creating margin in the tooltip body
    //  * @param {Integer} margin - size of the margin in pixels
    //  * @returns {String} - html string of the margin div
    //  */
    // marginDivHtml(margin) {
    //     return `<div style="margin-top:${margin}px"></div>`;
    // }

    // /**
    //  * Returns html of the div element creating title in the tooltip body
    //  * @param {String} text - text of the title
    //  * @returns {String} - html string of the title div
    //  */
    // titleHtml(text) {
    //     return `<div style="font-size:12px; margin-bottom:5px;"><b>${text}</b></div>`;
    // }

    /**
     * Returns html of the div element representing horizontal line with top and bottom margin
     * @param {Integer} margin - size of the margin in pixels
     * @returns {String} - html string of the horizontal line div
     */
    horizontalLine(margin) {
        return `<div style="border-bottom: 1px solid black;margin:${margin}px 0;"></div>`;
    }

    // /**
    //  * Returns html of the legend - value pair
    //  * @param {String} legend - text of the legend
    //  * @param {String} value - text of the value
    //  * @param {Boolean} newLine - true if new line <br> should be included after the pair
    //  * @returns {String} - html string of the legend value pair
    //  */
    // legendValueHtml(legend, value, newLine=true) {
    //     return (
    //         `<b>${legend}:</b> <span>${value}</span>` +
    //         (newLine ? '</br>' : '')
    //     );
    // }

    /**
     * Returns html of the div element with the given styling
     * @param {String} style - style attribute text of the div
     * @param {String} innerHtml - inner html string
     * @returns {String} - html string of the div
     */
    divTagHtml(style, innerHtml) {
        return `<div style="${style}">${innerHtml}</div>`;
    }

    /**
     * Returns html of the table with legend value pairs (1st column = legend, 2nd column = value)
     * @param  {...any} lines - arbitrary number of lines - each line is array of two items
     *                          (legend and value)
     * @returns {String} - html string of the table
     */
    tableValuesHtml(...lines) {
        let html = '';
        const tdLegendStyle = 'style="padding: 0"';
        const tdValueStyle = 'style="padding: 0;text-align: right"';
        const marginStyle = 'style="margin-right: 5px"';
        html += '<table><tbody>'

        for (let i = 0; i < lines.length; i++) {
            html += '<tr>';
            html += `<td ${tdLegendStyle}><b><span ${marginStyle}>${lines[i][0]}:</span></b></td>`
            html += `<td ${tdValueStyle}>${lines[i][1]}</td>`
            html += '</tr>';
        }

        html += '</tbody></table>'
        return html;
    }

    /**
     * Returns html of the capacity table for user and group tasks, explaining the comparison between
     * spent and planned time vs. total capacity
     * @param {Float} planned - total planned time of the current group's or user's time period
     * @param {Float} here - total planned time of the current group's or user's tiem period of the tasks
     *                       present on the current resources graph
     * @param {Float} external - total planned time of the current group's or user's time period of the tasks
     *                           which are not present on the current resources graph
     * @param {Float} capacity - total capacity time of the current group's or user's time period
     * @param {String} color - css color value, which will be used for the numbers in the table
     * @returns {String} - html string of the capacity table
     */
    tableCapacity(planned, here, external, capacity, color) {
        let compareSym = '=';
        if (planned > capacity) {
            compareSym = '>';
        } else if (planned < capacity) {
            compareSym = '<';
        }

        const thStyle = 'style="padding: 5px 5px 0 5px;text-align: center;"'
        const thStylePlanned = 'style="padding: 0 5px;text-align: center; width: 20%;"'
        const thStyleSymbol = 'style="padding: 0 5px;text-align: center; width: 4%;"'
        const thStyleTotal = 'style="padding: 0 5px;text-align: center; width: 28%;"'
        const tdStyle = `style="padding: 5px 0;text-align: center;color: ${color};font-weight: bold;"`;

        const html =
            this.divTagHtml('background: #F2F2F2; display: flex; justify-content: center;',
                '<table style="background: #F2F2F2; width: auto;"><thead>' +

                '<tr>' +
                    `<th colspan="5" ${thStyle}>${I18n.tooltip_planned} ${I18n.tooltip_hour_short}</th>` +
                    `<th ${thStyle}></th>` +
                    `<th ${thStyle}>${I18n.tooltip_capacity} ${I18n.tooltip_hour_short}</th>` +
                '</tr>' +

                '<tr>' +
                    `<th ${thStylePlanned}>${I18n.tooltip_total}</th>` +
                    `<th ${thStyleSymbol}></th>` +
                    `<th ${thStylePlanned}>${I18n.tooltip_here}</th>` +
                    `<th ${thStyleSymbol}></th>` +
                    `<th ${thStylePlanned}>${I18n.tooltip_external}</th>` +
                    `<th ${thStyleSymbol}></th>` +
                    `<th ${thStyleTotal}>${I18n.tooltip_total   }</th>` +
                '</tr>' +

                '</thead><tbody>' +

                '<tr>' +
                    `<td ${tdStyle}>${planned}</td>` +
                    `<td ${tdStyle}>=</td>` +
                    `<td ${tdStyle}>${here}</td>` +
                    `<td ${tdStyle}>+</td>` +
                    `<td ${tdStyle}>${external}</td>` +
                    `<td ${tdStyle}>${compareSym}</td>` +
                    `<td ${tdStyle}>${capacity}</td>` +
                '</tr>' +

                '</tbody></table>'
            )

        return html;
    }
}