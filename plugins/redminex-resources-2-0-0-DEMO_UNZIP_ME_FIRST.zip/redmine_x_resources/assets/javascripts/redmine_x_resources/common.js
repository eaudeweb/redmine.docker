/**
* Some common global configuration variables and methods
*/

/**
* Prepares list of owners for lightbox and inline owner editor
* @param {Task Object} task - task for which we want to get the list of possible owners
* @return {Array} - array of hashes, each with key (id of the user) and label (name of the user)
*/
export const availableOwners = (task, isNew) => {
    if (task.type === RXA.common.TYPE_PROJECT ||
        task.type === RXA.common.TYPE_MILESTONE)
    {
        return [];
    }

    const projectId = RXA.common.getProjectId({ task });
    const users = gantt.serverList('users').filter(user => Permissions[projectId].members.includes(user.key));
    if (isNew) {
        users.push({ key: userId, label: `<< ${I18n.label_me} >>`});
    } else {
        let authorIncluded = false;
        let currentOwnerIncluded = false;

        for (let i = 0; i < users.length; i++) {
            if (users[i].key.toString() === task.author_id.toString()) {
                authorIncluded = true;
            }
            if (users[i].key.toString() === task.owner_id.toString()) {
                currentOwnerIncluded = true;
            }
        }
        let authorId;
        if (!authorIncluded && task.author.trim().toLowerCase() != 'anonymous' && task.author_id > 0) {
            users.push({ key: task.author_id, label: task.author });
            authorId = task.author_id;
        }
        if (!currentOwnerIncluded && task.owner_id > 0 && authorId !== task.owner_id) {
            users.push({ key: task.owner_id, label: byId(gantt.serverList('users'), task.owner_id) });
        }
    }

    return users;
}

/**
 * Finds id in a serverList
 * @param {Array} list - array of items (e.g. users) in a serverList
 * @param {Integer} id - id of an item, which should be found
 * @return {String} - label of an item, which we found, if nothing is found, empty string is returned
 */
export const byId = (list, id) => {
    for (let i = 0; i < list.length; i++) {
        if (list[i].key == id)
            return list[i].label || '';
    }
    return '';
}

/**
 * Fetch data from redmine from given url with given json data
 * @param {String} url - url
 * @param {Object} data - data object, which will be converted to json
 * @returns {Object} - response data object
 */
export const fetchEntries = async (url, data) => {
    const urlWithKey = `${url}?key=${userApiToken}`;

    const parameters = {
        method: 'get',
        mode: 'cors',
        cache: 'no-cache',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json',
        },
        redirect: 'follow',
        referrerPolicy: 'no-referrer',
    };

    if (data) {
        parameters.method = 'post';
        parameters.body = JSON.stringify(data);
    }

    const response = await fetch(urlWithKey, parameters);

    const responseText = await response.text();
    const result = responseText ? JSON.parse(responseText) : null;

    if (!response.ok) {
        let message;
        if (result && result.errors) {
            message = result.errors.join(', ');
        }
        throw new Error(`${response.status} ${message}`)
    }
    return result;
}

/**
 * Rounds number according to the given distribution type
 * @param {Float} number - number to round
 * @param {String} type - distribution type -
 *                        see RXA.common.DISTRIBUTION_... constants
 * @returns {Float} - rounded number
 */
export const roundDistribution = (number, type) => {
    switch (type) {
        case RXA.common.DISTRIBUTION_UNIFORM_WHOLE:
            return Math.floor(number);
        case RXA.common.DISTRIBUTION_UNIFORM_HALF:
            return roundDownToHalf(number);
        case RXA.common.DISTRIBUTION_UNIFORM_DECIMAL:
            return round1D(number);
        default:
            return number;
    }
}

/**
 * Returns distribution type for the given task. If task has not distribution property itself,
 * distribution type is obtained from the project and assigned to the task for future use.
 * @param {Object} task - gantt task object for which we want to find the distribution type
 * @returns {String} - distribution type - see RXA.common.DISTRIBUTION_... constants
 */
 export const distributionType = (task) => {
    if (task.distribution) return task.distribution;

    if (task.utype !== RXA.common.TYPE_TASK && task.utype !== RXA.common.TYPE_PROJECT) {
        return '';
    }

    const projectId = RXA.common.getProjectId({ taskId: task.parent });
    const projectTask = gantt.getTask(projectId);
    task.distribution = projectTask.distribution;

    return projectTask.distribution;
}

/**
 * Calculates total capacity in hours of a user for the given time period (= sum of the capacities
 * of the workday between the given dates)
 * @param {Object} task - task object of the user for which we want to calculate the capacity
 * @param {Date} start - start date of the time period for which we want to calculate the capacity
 * @param {Date} end - end date of the time period for which we want to calculate the capacity
 * @returns {Integer} - total capacity in hours
 */
export const calculateUserCapacity = (task, start, end) => {
    let calendar = gantt.getCalendar(task.key);
    if (!calendar) calendar = gantt.getCalendar('global');
    return calendar._calculateDuration(start, end, 'hour', 1);
}

/**
 * Calculates total capacity in hours of a group for the given time period (= sum of the capacities
 * of the group's children=users)
 * @param {Object} task - task object of the group for which we want to calculate the capacity
 * @param {Date} start - start date of the time period for which we want to calculate the capacity
 * @param {Date} end - end date of the time period for which we want to calculate the capacity
 * @returns {Integer} - total capacity in hours
 */
 export const calculateGroupCapacity = (task, start, end) => {
    let workHours = 0;
    const children = gantt.getChildren(task.id);
    for (let i = 0; i < children.length; i++) {
        const child = gantt.getTask(children[i]);
        if (child.utype && child.utype == 'user') {
            let childCalendar = gantt.getCalendar(child.key);
            if (!childCalendar) childCalendar = gantt.getCalendar('global');
            workHours += childCalendar._calculateDuration(start, end, 'hour', 1);
        }
    }
    return workHours;
}

/**
 * Rounds float number down to nearest half (e.g. 1.99 will be rounded to 1.5)
 * @param {Float} number - number to round
 * @returns {Float} - rounded number
 */
export const roundDownToHalf = (number) => {
    const decimal = number - Math.floor(number);
    if (0 <= decimal && decimal < 0.5) {
        return Math.floor(number);
    } else {
        return Math.floor(number) + 0.5;
    }
}

/**
 * Rounds float number to one decimal place (e.g. 1.145 will be rounded to 1.1)
 * @param {Float} number - number to round
 * @returns {Float} - rounded number
 */
export const round1D = (number) => {
    return (Math.round(number * 10) / 10.0);
}

/**
 * Calculate next end date form the given date and current zoom level
 * @param {Object} fromDate - date object for which we want to get the end date
 * @param {Object} maxDate - maximum date (if we want to limit the result)
 * @param {String} zoom - name of the zoom level
 * @returns {Object} - date of the end date
 */
export const nextEndDate = (fromDate, maxDate, zoom) => {
    let resultDate;
    if (zoom === RXA.common.ZOOM_DAY)
    {
        if (RXA.common.diffDates(fromDate, maxDate) <= 0) {
            return maxDate;
        } else {
            return gantt.date.add(fromDate, 1, 'day');
        }
    } else if (zoom === RXA.common.ZOOM_WEEK) {
        const day = fromDate.getDay();
        const add = day === 0 ? 1 : 8 - day;
        resultDate = gantt.date.add(fromDate, add , 'day');
    } else if (zoom === RXA.common.ZOOM_MONTH) {
        const month = fromDate.getMonth();
        const nextMonth = month === 11 ? 0 : month + 1;

        if (nextMonth === 0) {
            resultDate = new Date(fromDate.getFullYear() + 1, nextMonth, 1);
        } else {
            resultDate = new Date(fromDate.getFullYear(), nextMonth, 1);
        }
    } else if (zoom === RXA.common.ZOOM_QUARTER) {
        const month = fromDate.getMonth();
        if (0 <= month && month <= 2) {
            resultDate = new Date(fromDate.getFullYear(), 3, 1);
        } else if (3 <= month && month <= 5) {
            resultDate = new Date(fromDate.getFullYear(), 6, 1);
        } else if (6 <= month && month <= 8) {
            resultDate = new Date(fromDate.getFullYear(), 9, 1);
        } else {
            resultDate = new Date(fromDate.getFullYear() + 1, 0, 1);
        }

    } else if (zoom === RXA.common.ZOOM_YEAR) {
        resultDate = new Date(fromDate.getFullYear() + 1, 0, 1);
    } else {
        return undefined;
    }
    if (RXA.common.diffDates(maxDate, resultDate) >= 0) {
        return maxDate;
    } else {
        return resultDate;
    }
}




