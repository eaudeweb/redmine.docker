import { TYPE_ENTRY, TYPE_FIXED, TYPE_DISTRIBUTION, TYPE_DAYOFF,
         PARENT_MODE_ADD, PARENT_MODE_REMOVE } from './resource_actions.js';
import { distributionType, roundDistribution, calculateUserCapacity,
         calculateGroupCapacity, nextEndDate } from './common.js';
export class ResourceObject {
    constructor(task, data) {
        this.task = task;
        if (!data || Object.keys(data).length === 0) {
            this.data = this.emptyData();
        } else {
            this.data = data;
        }
        this.capacities = {}
        this.zoomData = {};
        this.length = RXA.common.diffDates(this.task.start_date, this.task.end_date);
        this.children = {};
        const children = gantt.getChildren(task.id);
        for (let i = 0; i < children.length; i++) {
            const child = gantt.getTask(children[i]);
            if (child.utype !== RXA.common.TYPE_MILESTONE) {
                this.children[child.uid] = this.emptyData();
            }
        }
    }

    get resourceData() {
        return this.data;
    }

    set resourceData(data) {
        this.data = data;
        this.zoomData = {};
    }

    get childrenData() {
        return this.children;
    }

    updateChildData(mode, newData, oldData, start, end) {
        if (mode === PARENT_MODE_ADD || mode === PARENT_MODE_REMOVE) {
            this.addOrRemoveChildData(mode, newData, start, end);
        } else {
            this.changeChildData(newData, oldData, start, end)
        }
        this.zoomData = {};
    }

    addOrRemoveChildData(mode, newData, start, end) {
        const factor = mode === PARENT_MODE_ADD ? 1 : -1;
        let currentDate = new Date(start.getTime());
        let dateString;

        do {
            dateString = currentDate.toDateString();
            if (newData.values[dateString]) {
                if (this.data.values[dateString]) {
                    this.data.values[dateString].hours += factor * newData.values[dateString].hours;
                } else {
                    this.data.values[dateString] = RXA.common.deepCopy(newData.values[dateString]);
                }
            }
            currentDate = gantt.date.add(currentDate, 1, 'day');
        } while (RXA.common.diffDates(currentDate, end) >= 0)

        if (newData.highEstimation > 0) {
            this.data.highEstimation += factor * newData.highEstimation;
        }
        if (newData.lowEstimation > 0) {
            this.data.lowEstimation += factor * newData.lowEstimation;
        }
        this.data.fixedTotal += factor * newData.fixedTotal;
        this.data.hoursDistributionTotal += factor * newData.hoursDistributionTotal;
        this.data.spentTotal += factor * newData.spentTotal;
        this.data.estimated += factor * newData.estimated;
    }

    changeChildData(newData, oldData, start, end) {
        let currentDate = new Date(start.getTime());
        let dateString;
        let change;

        do {
            dateString = currentDate.toDateString();
            change = 0;

            if (newData.values[dateString]) {
                if (oldData.values[dateString]) {
                    change = newData.values[dateString].hours - oldData.values[dateString].hours;
                } else {
                    change = newData.values[dateString].hours;
                }
            } else if (oldData.values[dateString]) {
                change = -1 * oldData.values[dateString].hours;
            }

            if (this.data.values[dateString]) {
                this.data.values[dateString].hours += change;
            } else {
                if (RXA.common.diffDates(new Date(), currentDate) >= 0) {
                    const calendar = gantt.getTaskCalendar(this.task);
                    if (calendar.isWorkTime(currentDate)) {
                        this.data.values[dateString] =
                            { hours: change, type: TYPE_DISTRIBUTION }
                    } else {
                        this.data.values[dateString] =
                            { hours: change, type: TYPE_DAYOFF }
                    }
                } else {
                    this.data.values[dateString] =
                        { hours: change, type: TYPE_ENTRY }
                }
            }
            currentDate = gantt.date.add(currentDate, 1, 'day');
        } while (RXA.common.diffDates(currentDate, end) >= 0)

        if (newData.highEstimation !== oldData.highEstimation) {
            this.data.highEstimation += newData.highEstimation - oldData.highEstimation;
        }
        if (newData.lowEstimation !== oldData.lowEstimation) {
            this.data.lowEstimation += newData.lowEstimation - oldData.lowEstimation;
        }
        this.data.fixedTotal += newData.fixedTotal - oldData.fixedTotal;
        this.data.hoursDistributionTotal += newData.hoursDistributionTotal - oldData.hoursDistributionTotal;
        this.data.spentTotal += newData.spentTotal - oldData.spentTotal;
        this.data.estimated += newData.estimated - oldData.estimated;
    }

    emptyData() {
        const empty = {
            values: {},
            highEstimation: 0,
            lowEstimation: 0,
            fixedTotal: 0.0,
            hoursDistribution: 0.0,
            hoursDistributionTotal: 0.0,
            spentTotal: 0.0,
            estimated: 0.0
        }
        return empty;
    }

    clearData() {
        this.data.values = {}
        this.highEstimation = 0
        this.lowEstimation = 0
        this.fixedTotal = 0.0
        this.hoursDistribution = 0.0
        this.hoursDistributionTotal = 0.0
        this.spentTotal = 0.0
        this.estimated = 0.0
    }

    updateTask(task, data) {
        this.task = task;
        if (data) {
            this.data = data;
            this.data.capacities = {};
        } else {
            for (const dateString in this.data.values) {
                const date = new Date(dateString)
                const start = this.task.ustart_date ? new Date(this.task.ustart_date) : this.task.start_date;
                const end = this.task.uend_date ? new Date(this.task.uend_date) : this.task.end_date;
                const fromStart = RXA.common.diffDates(start, date);
                const toEnd = RXA.common.diffDates(date, end);
                if (fromStart < 0 || toEnd <= 0) {
                    delete this.data.values[dateString];
                }
            }
        }

        this.zoomData = {};
        this.length = RXA.common.diffDates(this.task.start_date, this.task.end_date);
    }

    getValuesForZoomLevel() {
        const level = gantt.ext.zoom.getCurrentLevel();
        const zoom = gantt.ext.zoom.getLevels()[level].name;

        const zoomObject = {};
        zoomObject.values = [];
        let currentStart = this.task.start_date;
        let nextEnd;
        const today = new Date(new Date().toDateString());

        if (this.zoomData[zoom]) {
            return this.zoomData[zoom];
        }

        if (this.task.type === RXA.common.TYPE_TASK) {
            if (RXA.common.diffDates(this.task.end_date, today) >= 0) 
            {
                this.zoomData[zoom] = zoomObject;
                return this.zoomData[zoom];
            }

            if (RXA.common.diffDates(today, this.task.start_date) >= 0) {
                currentStart = this.task.start_date;
            } else {
                currentStart = today;
            }
        }

        zoomObject.isOverflow = false;
        zoomObject.firstDayOfPeriod = this.getFirstDayOfPeriod(currentStart, zoom);

        do {
            nextEnd = nextEndDate(currentStart, this.task.end_date, zoom);

            const value = this.getValue(currentStart, nextEnd);
            if (value.isOver) {
                zoomObject.isOverflow = true;
            }
            if (zoom !== RXA.common.ZOOM_DAY) {
                if ((this.task.utype === RXA.common.TYPE_GROUP && this.task.uid !== 'u-1') ||
                     this.task.utype === RXA.common.TYPE_USER)
                {
                    value.capacity = this.getCapacity(currentStart, zoom);
                    if (value.hours > value.capacity) {
                        value.isOk = false;
                        value.isOver = true;
                    } else {
                        value.isOk = true;
                        value.isOver = false;
                    }
                }
            }

            zoomObject.values.push({ start: currentStart, end: nextEnd, val: value });

            currentStart = nextEnd;
        } while (RXA.common.diffDates(nextEnd, this.task.end_date) > 0);

        zoomObject.lastDayOfPeriod = this.getLastDayOfPeriod(nextEnd, zoom);
        zoomObject.highEstimation = this.data.highEstimation;
        zoomObject.lowEstimation = this.data.lowEstimation;
        this.zoomData[zoom] = zoomObject;

        return this.zoomData[zoom];
    }

    getFirstDayOfPeriod(date, zoom) {
        if (zoom === RXA.common.ZOOM_DAY)
        {
            return date;
        } else if (zoom === RXA.common.ZOOM_WEEK) {
            if (date.getDay() === 1) {
                return date;
            } else if (date.getDay() == 0) {
                return gantt.date.add(date, -6, 'day');
            } else {
                return gantt.date.add(date, 1 - date.getDay(), 'day');
            }
        } else if (zoom === RXA.common.ZOOM_MONTH) {
            return new Date(date.getFullYear(), date.getMonth(), 1);
        } else if (zoom === RXA.common.ZOOM_QUARTER) {
            const month = date.getMonth();
            if (0 <= month && month <= 2) {
                return new Date(date.getFullYear(), 0, 1);
            } else if (3 <= month && month <= 5) {
                return new Date(date.getFullYear(), 3, 1);
            } else if (6 <= month && month <= 8) {
                return new Date(date.getFullYear(), 6, 1);
            } else {
                return new Date(date.getFullYear(), 9, 1);
            }
        } else if (zoom === RXA.common.ZOOM_YEAR) {
            return new Date(date.getFullYear(), 0, 1);
        }
    }

    getLastDayOfPeriod(date, zoom) {
        if (zoom === RXA.common.ZOOM_DAY)
        {
            return date;
        } else if (zoom === RXA.common.ZOOM_WEEK) {
            if (date.getDay() === 1) {
                return date;
            } else if (date.getDay() == 0) {
                return gantt.date.add(date, 1, 'day');
            } else {
                return gantt.date.add(date, 8 - date.getDay(), 'day');
            }
        } else if (zoom === RXA.common.ZOOM_MONTH) {
            if (date.getDate() === 1) {
                return date;
            } else if (date.getMonth() === 11) {
                return new Date(date.getFullYear() + 1, 0, 1);
            } else {
                return new Date(date.getFullYear(), date.getMonth() + 1, 1);
            }
        } else if (zoom === RXA.common.ZOOM_QUARTER) {
            const month = date.getMonth();
            if (date.toDateString() === new Date(date.getFullYear(), 0, 1).toDateString()) {
                return date;
            } else if (0 <= month && month <= 2 ||
                       date.toDateString() === new Date(date.getFullYear(), 3, 1).toDateString())
            {
                return new Date(date.getFullYear(), 3, 1);
            } else if (3 <= month && month <= 5 ||
                       date.toDateString() === new Date(date.getFullYear(), 6, 1).toDateString())
            {
                return new Date(date.getFullYear(), 6, 1);
            } else if (6 <= month && month <= 8 ||
                       date.toDateString() === new Date(date.getFullYear(), 9, 1).toDateString())
            {
                return new Date(date.getFullYear(), 9, 1);
            } else {
                return new Date(date.getFullYear() + 1, 0, 1);
            }
        } else if (zoom === RXA.common.ZOOM_YEAR) {
            if (date.toDateString() === new Date(date.getFullYear(), 0, 1).toDateString()) {
                return date;
            } else {
                return new Date(date.getFullYear() + 1, 0, 1);
            }
        }
    }

    getValue(startDateInput, endDateInput) {
        const calendar = gantt.getTaskCalendar(this.task);
        let startDate, endDate;
        const result = {
            hours: 0, planned: 0, external: 0, isOver: false, isOk: false, isFixed: false, isNotFixed: false
        }

        let start = RXA.common.diffDates(this.task.start_date, startDateInput);
        let end = RXA.common.diffDates(this.task.start_date, endDateInput);

        if (start > end) {
            return result;
        }
        if (start >= this.length) {
            return result;
        }
        if (end < 0) {
            return result;
        }

        startDate = start < 0 ? this.task.start_date : startDateInput;
        endDate = end >= this.length ? this.task.end_date : endDateInput;

        const today = new Date(new Date().toDateString());
        if (this.task.type === RXA.common.TYPE_PROJECT &&
            RXA.common.diffDates(endDate, today) >= 0)
        {
            result.hours = -1;
            return result;
        }

        let currentDate = startDate;
        do {
            const dateString = currentDate.toDateString();
            if (this.data.values && this.data.values[dateString]) {
                const dateString = currentDate.toDateString();
                let valueObject = {};
                result.hours += this.data.values[dateString].hours;
                result.planned += this.data.values[dateString].hours;
                valueObject.hours = this.data.values[dateString].hours;

                if (this.data.valuesExternal && this.data.valuesExternal[dateString]) {
                    result.hours += this.data.valuesExternal[dateString].hours;
                    result.external += this.data.valuesExternal[dateString].hours;
                    valueObject.hours += this.data.valuesExternal[dateString].hours;;
                }

                valueObject.type = this.data.values[dateString].type;

                if (this.task.utype === RXA.common.TYPE_TASK ||
                    (this.task.utype === RXA.common.TYPE_USER && this.task.uid !== 'u-1')) {
                    const hoursPerDay = calendar.getHoursPerDay(currentDate);
                    valueObject = this.setFlags(valueObject, hoursPerDay);
                }
                if (valueObject.isOk) {
                    result.isOk = true;
                }
                if (valueObject.isOver) {
                    result.isOver = true;
                }
                if (valueObject.isFixed) {
                    result.isFixed = true;
                } else if (calendar.isWorkTime(currentDate)) {
                    result.isNotFixed = true;
                }
            }
            currentDate = gantt.date.add(currentDate, 1, 'day');
        } while (RXA.common.diffDates(currentDate, endDate) > 0)

        if (result.isOver) result.isOk = false;
        if (result.isNotFixed) result.isFixed = false;

        if (RXA.common.diffDates(startDate, endDate) > 1) {
            const type = distributionType(this.task);
            result.hours = roundDistribution(result.hours, type)
        }

        return result;
    }

    getCapacity(date, zoom) {
        const start = this.getFirstDayOfPeriod(date, zoom);
        const startString = start.toDateString();

        if (this.capacities[zoom] && this.capacities[zoom][startString]) {
            return this.capacities[zoom][startString];
        }

        let end;
        if (RXA.common.diffDates(start, date) == 0) {
            end = this.getLastDayOfPeriod(gantt.date.add(date, 1, 'day'), zoom);
        } else {
            end = this.getLastDayOfPeriod(date, zoom);
        }

        if (!this.capacities[zoom]) this.capacities[zoom] = {};

        if (this.task.utype == RXA.common.TYPE_USER) {
            this.capacities[zoom][startString] = calculateUserCapacity(this.task, start, end);
        }
        if (this.task.utype == RXA.common.TYPE_GROUP) {
            this.capacities[zoom][startString] = calculateGroupCapacity(this.task, start, end);
        }
        return this.capacities[zoom][startString];
    }

    setFlags(valueObject, hoursPerDay) {
        if (!valueObject.type || valueObject.type === TYPE_DISTRIBUTION) {
            if (valueObject.hours == 0) {
                valueObject.isOver = valueObject.isOk = valueObject.isFixed = false;
            } else if (0 < valueObject.hours && valueObject.hours <= hoursPerDay) {
                valueObject.isOver = valueObject.isFixed = false;
                valueObject.isOk = true;
            } else {
                valueObject.isOk = valueObject.isFixed = false;
                valueObject.isOver = true;
            }
        } else if (valueObject.type === TYPE_ENTRY) {
            valueObject.isOver = valueObject.isOk = valueObject.isFixed = false;
        } else if (valueObject.type === TYPE_FIXED) {
            if (valueObject.hours <= hoursPerDay) {
                valueObject.isOver = false;
                valueObject.isOk = valueObject.isFixed = true;
            } else {
                valueObject.isOk = false;
                valueObject.isOver = valueObject.isFixed = true;
            }
        } else if (valueObject.type === TYPE_DAYOFF) {
            valueObject.isOver = valueObject.isOk = valueObject.isFixed = false;
        }
        return valueObject;
    }

    setValue(startDateInput, endDateInput, value) {
        endDateInput = gantt.date.add(endDateInput, -1, 'day');
        let startDate, endDate;
        let calendar = gantt.getTaskCalendar(this.task);
        let start = RXA.common.diffDates(new Date(), startDateInput);
        let end = RXA.common.diffDates(new Date(), endDateInput);
        let today = RXA.common.diffDates(this.task.start_date, new Date());

        if (start > end) {
            return 0;
        }
        if (start >= this.length - today) {
            return 0;
        }
        if (end < 0) {
            return 0;
        }

        startDate = start < 0 ? new Date() : startDateInput;
        endDate = end >= this.length - today ? this.task.end_date : endDateInput;
        const periodLength = calendar.calculateDuration(
            new Date(startDate.toDateString()),
            new Date(gantt.date.add(endDate, 1, 'day').toDateString())
        );

        let currentDate = startDate;
        while(RXA.common.diffDates(endDate, currentDate) <= 0) {
            const dateString = currentDate.toDateString();
            if (calendar.isWorkTime(currentDate) || start === end) {
                const unitValue = value / periodLength;
                this.data.values[dateString] = { hours: unitValue, type: TYPE_FIXED }
                this.addFixedToSendingStack(currentDate, unitValue, true);
            } else if (this.data.values[dateString]) {
                this.data.values[dateString] = { hours: 0, type: TYPE_DISTRIBUTION };
                this.addFixedToSendingStack(currentDate, 0, true, 'destroy');
            }
            currentDate = gantt.date.add(currentDate, 1, 'day');
        }
    }

    unsetValue(startDateInput, endDateInput) {
        endDateInput = gantt.date.add(endDateInput, -1, 'day');
        let startDate, endDate;
        let start = RXA.common.diffDates(new Date(), startDateInput);
        let end = RXA.common.diffDates(new Date(), endDateInput);
        let today = RXA.common.diffDates(this.task.start_date, new Date());

        if (start > end) {
            return 0;
        }
        if (start >= this.length - today) {
            return 0;
        }
        if (end < 0) {
            return 0;
        }

        startDate = start < 0 ? new Date() : startDateInput;
        endDate = end >= this.length - today ? this.task.end_date : endDateInput;

        let currentDate = startDate;
        while(RXA.common.diffDates(endDate, currentDate) <= 0) {
            const dateString = currentDate.toDateString();
            if (this.data.values[dateString]) {
                this.data.values[dateString] = { hours: 0, type: TYPE_DISTRIBUTION };
                this.addFixedToSendingStack(currentDate, 0, true, 'destroy');
            }
            currentDate = gantt.date.add(currentDate, 1, 'day');
        }
    }

    // cleanFixed() {
    //     for (let date in this.data) {
    //         if (this.data[date].type === TYPE_FIXED) {
    //             const fromToday = RXA.common.diffDates(new Date(), new Date(date));
    //             const toEnd = RXA.common.diffDates(new Date(date), this.task.end_date);

    //             if (fromToday < 0 || toEnd <=0 ) {
    //                 delete this.data[date];
    //                 this.addFixedToSendingStack(new Date(date), 0, true, 'destroy');
    //             }
    //         }
    //     }
    // }

    /**
     * Adds one fixed value to the sending stack
     * @param {Date object} date - date of the fixed value
     * @param {Float} hours - float value of fixed hours (0..24)
     * @param {String} taskId - id of task, for which the fixed value belongs
     * @return {void}
     */
    addFixedToSendingStack(date, hours, count, mode) {
        const fixedValue = {
            hours,
            date: date.toDateString(),
            author_id: userId,
            issue_id: RXA.common.cleanId(this.task.id),
            count
        }

        if (mode) {
            fixedValue.mode = mode;
        }
        gantt.fixedSendingStack.push(fixedValue);
    }
}