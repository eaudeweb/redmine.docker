/**
* Configures tasks properties
*/
import { OPEN_EDIT_BOX } from './resources_store.js';
export class Tasks extends RXA.Tasks {
    constructor() {
        super();
        this.taskDragMessage = false;
    }
    /**
    * Initializes some task functionalities - i.e. task css classes, task description
    * position
    * @return {void}
    */
    initTasks() {
        this.taskCss();
        this.taskNamePosition();
        this.verifyTaskDrag();
        this.cancelProjectDrag();
        this.showEditBoxAfterClick();
    }

    /**
    * Sets position of the task name - if length of name is too wide and doesn't fit
    * in to the body of the task, name is placed to the right of the task
    * @return {void}
    */
    taskNamePosition() {
        gantt.config.font_width_ratio = 7;

        gantt.templates.rightside_text = (start, end, task) => {
            if (task.utype === 'user' || task.utype === 'group') {
                let margin = 0;
                if (task.end_date) {
                    const level = gantt.ext.zoom.getCurrentLevel();
                    const zoom = gantt.ext.zoom.getLevels()[level].name;
                    margin = gantt.posFromDate(this.nextEndDate(task.end_date, zoom)) - gantt.posFromDate(task.end_date);
                }
                return `<span style="margin-left:${margin}px">${this.taskNameText(task)}</span>`;
            } else {
                return this.taskNameText(task);
            }
        };

        gantt.templates.task_text = (start, end, task) => {
            return '';
        };
    }

    /**
    * Verifies if task can be dragged - moved or resized
    * @return {void} - nothing is returned
    */
    verifyTaskDrag() {
        gantt.attachEvent('onTaskDrag', (id, mode, task, original, e) => {
            if (parentTaskSettings.dates_derived && task.has_children) {
                task.start_date = original.start_date;
                task.end_date = original.end_date;
                task.duration = original.duration;
                return false;
            }
            if (task.type === RXA.common.TYPE_TASK) {
                if (RXA.common.diffDates(task.start_date, task.end_date) < 1 || task.duration < 1) {
                    task.start_date = original.start_date;
                    task.end_date = original.end_date;
                    task.duration = original.duration;
                    return false;
                }
            }

            return true;
        });
    }

    /**
    * Cancel project change, if user tries to drag it (move it or resize it)
    * @return {void} - nothing is returned
    */
    cancelProjectDrag() {
        gantt.attachEvent('onBeforeTaskDrag', (id, mode, e) => {
            const task = gantt.getTask(id);
            if (task.type === RXA.common.TYPE_PROJECT) {
                return false;
            } else {
                return true;
            }
        });
    }

    showEditBoxAfterClick() {
        document.getElementById('resources_here').addEventListener('mousedown', (event) => {
            gantt.ganttClickStart = +new Date();
        });

        gantt.attachEvent('onTaskDblClick', (id, event) => {
            console.log('Task DOUBLE click');
            this.dblClick = true;
            return true;
        });

        gantt.attachEvent('onTaskClick', (id, event) => {
            const taskBody = document.querySelector(`div[data-task-id="${id}"] div.gantt_task_progress_wrapper`);
            if (!taskBody) return true;

            const rect = taskBody.getBoundingClientRect();

            if (this.dblClick) this.dblClick = false;
            if (rect.left <= event.clientX && event.clientX <= rect.right &&
                rect.top  <= event.clientY && event.clientY <= rect.bottom)
            {
                const task = gantt.getTask(id);
                if (task.type === 'task') {
                    setTimeout(() => {
                        if (!this.dblClick) {
                            gantt.resourcesStore.processAction(OPEN_EDIT_BOX, { task, event, rect });
                        }
                    }, 250);
                }
            }
            return true;
        });
    }

    nextEndDate(fromDate, zoom) {
        if (zoom === RXA.common.ZOOM_DAY)
        {
            return fromDate;
        } else if (zoom === RXA.common.ZOOM_WEEK) {
            const day = fromDate.getDay();
            if (day === 1) {
                return fromDate;
            } else {
                const add = day === 0 ? 1 : 8 - day;
                return gantt.date.add(fromDate, add , 'day');
            }
        } else if (zoom === RXA.common.ZOOM_MONTH) {
            if (fromDate.getDate() === 1) {
                return fromDate;
            } else {
                const month = fromDate.getMonth();
                const nextMonth = month === 11 ? 0 : month + 1;

                if (nextMonth === 0) {
                    return new Date(fromDate.getFullYear() + 1, nextMonth, 1);
                } else {
                    return new Date(fromDate.getFullYear(), nextMonth, 1);
                }
            }
        } else if (zoom.name === RXA.common.ZOOM_QUARTER) {
            const month = fromDate.getMonth();
            if (fromDate.toDateString() === new Date(fromDate.getFullYear(), 0, 1).toDateString()) {
                return fromDate;
            } else if (0 <= month && month <= 2 ||
                       fromDate.toDateString() === new Date(fromDate.getFullYear(), 3, 1).toDateString())
            {
                return new Date(fromDate.getFullYear(), 3, 1);
            } else if (3 <= month && month <= 5 ||
                       fromDate.toDateString() === new Date(fromDate.getFullYear(), 6, 1).toDateString())
            {
                return new Date(fromDate.getFullYear(), 6, 1);
            } else if (6 <= month && month <= 8 ||
                       fromDate.toDateString() === new Date(fromDate.getFullYear(), 9, 1).toDateString())
            {
                return new Date(fromDate.getFullYear(), 9, 1);
            } else {
                return new Date(fromDate.getFullYear() + 1, 0, 1);
            }
        } else if (zoom === RXA.common.ZOOM_YEAR) {
            if (fromDate.getDate() === 1 && fromDate.getMonth() === 0) {
                return fromDate;
            } else {
                return new Date(fromDate.getFullYear() + 1, 0, 1);
            }
        } else {
            return undefined;
        }
    }
}