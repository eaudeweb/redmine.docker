/**
* Configures gantt grid
*/
import { Links } from './links.js'
import { UPDATE_TASK } from './resources_store.js';
import { fetchEntries, availableOwners, byId } from './common.js';

export class Grid extends RXA.Grid {

    /**
    * Initialize grid of the gantt based on the current view (group by projects, group by resources)
    * @param {String} projectId - id of Project if in a Project (not global) mode
    * @return {void} - nothing is returned
    */
    initGrid(projectId) {
        // Keep inline creation of task turned off for now
        //turnOnInlineTaskAddition();

        // Use definition below instead of the one from gantt
        this.defineGridColumnsProjects();

        super.gridEndDateConfig();
        super.preventEditing();
        super.onTaskClick();

        this.changeItemsIcons();

        // Initialize switching between group by project and group by resource
        this.initGrouping();

        //this.initBeforeSaveActions(projectId);

        // Resources actions
        this.initResourceDataStore();
        //this.toggleGroups(document.getElementById('gantt-groupby-btn'));
        gantt.attachEvent('onLoadEnd', () => {
            const resourcesStore = gantt.getDatastore(gantt.config.resource_store);
            resourcesStore.parse(gantt.serverList('users'));

            if (gantt.localStorage.getGroupUsers()) {
                document.querySelector(`input[name="display"][value="resources"]`).checked = true;
                this.switchGrouping(true);
            } else {
                document.querySelector(`input[name="display"][value="projects"]`).checked = true;
            }

            gantt.config.scale_offset_minimal = false;
            gantt.config.start_date = gantt.date.add(gantt.getState().min_date, -2, 'day');
            gantt.config.end_date = gantt.date.add(gantt.getState().max_date, 30, 'day');
            gantt.config.show_tasks_outside_timescale = true;
            //gantt.config.fit_tasks = true;
            gantt.render();
        });

        this.oldOwnerId = null;
        gantt.attachEvent('onBeforeLightbox', (id) => {
            if (gantt.$groupMode) {
                if (gantt.isTaskExists(id)) {
                    const task = gantt.getTask(id);
                    this.oldOwnerId = task.owner_id;
                } else {
                    this.oldOwnerId = 'new';
                }
            }
            return true;
        });

        gantt.attachEvent('onAfterTaskUpdate', (id, item) => {
            console.log('onAfterTaskUpdate', id);
            if (gantt.$groupMode) {
                if ((this.oldOwnerId && this.oldOwnerId != item.owner_id) ||
                     this.oldOwnerId === 'new')
                {
                    this.sortGroupedGrid();
                    this.oldOwnerId = null;
                }
            }
        });

        gantt.attachEvent("onAfterTaskAdd", (id, item) => {
            if (gantt.$groupMode) {
                this.sortGroupedGrid();
            }
        });

        gantt.attachEvent("onTaskLoading", function(task) {
            if (task.utype === 'user' || task.uid === 'u-1' ||
                (task.utype === 'project' && !localResources)) {
                task.$open = false;
                if (gantt.isTaskExists(task.id)) {
                    gantt.refreshTask(task.id);
                }
            }
            return true;
        });

        gantt.ext.inlineEditors.attachEvent('onBeforeSave', (state) => {
            console.log(state);
            const result = RXA.scheduling.gridInlineEditScheduling(state);
            if (!result) {
                state.newValue = state.oldValue;
            } else {
                let task = gantt.getTask(state.id);
                while(task.$rendered_parent) {
                    gantt.refreshTask(task.$rendered_parent);
                    task = gantt.getTask(task.$rendered_parent);
                }

                task = gantt.getTask(state.id);
                if (state.columnName === 'owner') {
                    task.uparent = `u${task.owner_id}`;
                    gantt.resourcesStore.processAction(UPDATE_TASK, { task });
                }
            }
        });
    }

    /**
    * Enables grouping of grid view by resources after button is clicked
    * @return {void} - nothing is returned
    */
    initGrouping() {
        gantt.plugins({
            grouping: true
        });

        const radios = document.getElementsByName('display');
        for (let i = 0; i < radios.length; i++) {
            radios[i].onclick = (event) => {
                if (event.target.value === 'projects') {
                    gantt.localStorage.setGroupUsers(false);
                    this.switchGrouping(false);
                } else {
                    gantt.localStorage.setGroupUsers(true);
                    this.switchGrouping(true);
                }
                event.target.checked = true;
            };
        }
    }

    /**
    * Switch between group by project and group by resource grid view
    * @param {Object} input - button DOM element, which is responsible for switching
    * @return {void} - nothing is returned
    */
    switchGrouping(users) {
        const links = new Links();
        if (users) {
            gantt.$groupMode = true;
            gantt.$groupCounter = gantt.$groupCounter ? gantt.$groupCounter + 1 : 1;
            this.defineGridColumnsResources();
            gantt.groupBy({
                groups: gantt.serverList('users'),
                relation_property: 'owner_id',
                group_id: 'key',
                group_text: 'label',
            });
            this.changeUserAndGroupCalendars();
            this.sortGroupedGrid();
            //this.closeParentsOnGroupedGrid();
            gantt.config.drag_links = false;
        } else {
            gantt.$groupMode = false;
            gantt.$groupCounter = gantt.$groupCounter ? gantt.$groupCounter + 1 : 1;
            this.defineGridColumnsProjects();
            gantt.groupBy(false);
            //this.closeParentsOnGroupedGrid();
            gantt.config.drag_links = true;
        }
        links.lagText();
        gantt.render();
        RXA.todayMarker.scrollToToday(false);
    }

    /**
     * Sorts gantt - tasks which are on the same level as groups will be always displayed first
     * Used for resources grouping only
     * @return {void}
     */
    sortGroupedGrid() {
        gantt.sort(this.sorting);
    }

    /**
     * Resources sorting function, which ensures correct order of tasks and groups
     * @param {Object} a - 1st task object to compare
     * @param {Object} b - 2nd task object to compare
     * @returns {Integer} - 1, if order a, b is ok, -1 if order should be switched, 0 if a, b are equal
     */
    sorting(a, b) {
        if (a.utype === RXA.common.TYPE_TASK && 
            b.utype === RXA.common.TYPE_TASK &&
            a.uparent === b.uparent) 
        {
            return a.start_date < b.start_date ? 1 : (a.start_date > b.start_date ? -1 : 0);
        }

        if (a.utype === RXA.common.TYPE_GROUP &&
            b.utype === RXA.common.TYPE_GROUP &&
            b.uid === 'u-1') 
        {
                return 1;
        }

        if (a.utype === RXA.common.TYPE_GROUP &&
            a.uid === 'u-1' &&
            b.utype === RXA.common.TYPE_GROUP) 
        {
                return -1;
        }

        if (a.utype === RXA.common.TYPE_USER && 
            b.utype === RXA.common.TYPE_TASK &&
            a.uparent === b.uparent) 
        {
            return 1;
        }
        if (a.utype === RXA.common.TYPE_TASK && 
            b.utype === RXA.common.TYPE_USER &&
            a.uparent === b.uparent) 
        {
            return -1;
        }
        return 0;
    }

    /**
     * Updates owner_id of user and group virtual tasks on the grouped gantt, in order to
     * assign user's (group's) own calendar to the user's (groups's) virtual task - normal
     * state after grouping is, that every task has its owner=parent task calendar, which is
     * not correct for user or group virtual tasks
     * @returns {void} - nothing is returned
     */
    changeUserAndGroupCalendars() {
        gantt.batchUpdate(() => {
            gantt.eachTask((task) => {
                if (task.$virtual) {
                    let calendar = gantt.getCalendar(task.key);
                    if (calendar) {
                        task.calendar_id = calendar.id;
                    } else {
                        task.calendar_id = 'global';
                    }
                    gantt.refreshTask(task.id)
                }
            })
        })
    }

    /**
     * Closes parent 'tasks' (users, projects) and unassigned group
     * Used for resources grouping only
     * @return {void}
     */
    closeParentsOnGroupedGrid() {
        gantt.$data.tasksStore.visibleOrder.forEach((id) => {
            const task = gantt.getTask(id);
            if (task.utype === 'user' || task.uid === 'u-1' || task.utype === 'project') {
                gantt.close(task.id);
            }
        });
    }

    /**
    * Defines grid columns for a view where tasks are grouped by resources
    * @return {void} - nothing is returned
    */
    defineGridColumnsResources() {
        const { textEditor, durationEditor, estimatedEditor } = this.defineOtherInlineEditors();
        gantt.config.columns = [
            {name: 'text', tree: true, width: 200, resize: true, editor: textEditor},
            {name: 'estimated', label: `${I18n.grid_column_estimated} ${I18n.tooltip_hour_short}`, width:68, align: 'center', resize: true, editor: estimatedEditor,
                template: task => {
                    if (task.type === RXA.common.TYPE_MILESTONE) {
                        return '';
                    } else if (task.type === RXA.common.TYPE_PROJECT) {
                        task.estimated_hours = this.calculateEstimatedHours(task);
                    }
                    return Math.round(task.estimated_hours * 10) / 10;
                }
            },
            {name: 'spent', label: `${I18n.grid_column_spent} ${I18n.tooltip_hour_short}`, resize: true, width: 68, align: 'center',
                template: task => {
                    if (task.type === RXA.common.TYPE_MILESTONE) {
                        return '';
                    } else if (task.type === RXA.common.TYPE_PROJECT) {
                        if (task.utype == 'group' || task.utype == 'user') {
                            task.total_hours = this.calculateSpentHoursGroup(task);
                        }
                    }
                    return Math.round(task.total_hours * 10) / 10;
                }
            },
            {name: 'remaining', label: `${I18n.grid_column_remaining} ${I18n.tooltip_hour_short}`, resize: true, width: 68, align: 'center',
                template: task => {
                    if (task.type === RXA.common.TYPE_MILESTONE) {
                        return '';
                    } else if (task.type === RXA.common.TYPE_PROJECT) {
                        if (task.utype == 'group') {
                            task.remaining_hours = this.calculateRemainingHoursGroup(task);
                        } else if (task.utype == 'user') {
                            task.remaining_hours = this.calculateRemainingHoursUser(task);
                        }
                    } else {
                        if (task.total_hours && task.estimated_hours) {
                            task.remaining_hours = parseFloat(task.estimated_hours) - parseFloat(task.total_hours);
                        } else if (task.total_hours) {
                            task.remaining_hours = -parseFloat(task.total_hours);
                        } else {
                            task.remaining_hours = parseFloat(task.estimated_hours);
                        }
                    }

                    return Math.round(task.remaining_hours * 10) / 10;
                }
            },
            {name: 'duration', width:80, align: 'center', resize: true, editor: durationEditor,
                template: task => {
                    if (task.type === RXA.common.TYPE_MILESTONE) {
                        return '';
                    } else if (task.type === RXA.common.TYPE_PROJECT) {
                        if (!this.hasNonZeroChildren(task)) {
                            return '0h / 0d';
                        }
                    }
                    const calendar = gantt.getTaskCalendar(task);
                    const workHours = calendar._calculateDuration(task.start_date, task.end_date, 'hour', 1);
                    return `${workHours}h / ${task.duration}d`;
                }
            },
            {name: 'link_to_task', width: 45, label: '', align: 'center', resize: false,
                template: this.gridLinkColumnTemplate
            }
        ];
        if (Permissions.add) {
            gantt.config.columns.push({name: 'add', label: '', width: 45, align: 'center' });
        }
    }

    /**
    * Defines grid columns for a view where tasks are grouped by projects (this is default)
    * @param {Object} editors - object with editors used by the column templates (startDateEditor,
    *    endDateEditor, textEditor, durationEditor
    * @return {void} - nothing is returned
    */
    defineGridColumnsProjects(editors) {
        const { textEditor, durationEditor, estimatedEditor, ownerEditor } = this.defineOtherInlineEditors();
        //ownerEditor.options = gantt.serverList('users');
        gantt.config.columns = [
            {name: 'text', tree: true, width: 200, resize: true, editor: textEditor},
            {name: 'owner', label: I18n.lightbox_assigned_to, resize: true, width: 135, align: 'center', editor: ownerEditor,
                template: task => {
                    if(task.type == RXA.common.TYPE_PROJECT ||
                    task.type == RXA.common.TYPE_MILESTONE)
                    {
                        return '';
                    }
                    return byId(gantt.serverList('users'), task.owner_id);
                }
            },
            {name: 'estimated_hours', width:68, align: 'center', resize: true, editor: estimatedEditor,
            template: task => {
                    if (task.type === RXA.common.TYPE_MILESTONE) {
                        return '';
                    } else if (task.type === RXA.common.TYPE_PROJECT) {
                        task.estimated_hours = this.calculateEstimatedHours(task);
                    }
                    return Math.round(task.estimated_hours * 10) / 10;
                }
            },
            {name: 'duration', width:80, align: 'center', resize: true, editor: durationEditor,
                template: task => {
                    if (task.type === RXA.common.TYPE_MILESTONE) {
                        return '';
                    } else if (task.type === RXA.common.TYPE_PROJECT) {
                        if (!this.hasNonZeroChildren(task)) {
                            return '0h / 0d';
                        }
                    }
                    const calendar = gantt.getTaskCalendar(task);
                    const workHours = calendar._calculateDuration(task.start_date, task.end_date, 'hour', 1);
                    return `${workHours}h / ${task.duration}d`;
                }
            },
            {name: 'link_to_task', width: 45, label: '', align: 'center', resize: false,
                template: this.gridLinkColumnTemplate
            }
        ];
        if (Permissions.add) {
            gantt.config.columns.push({name: 'add', label: '', width: 45, align: 'center' });
        }
    }

    defineOtherInlineEditors() {
        super.defineCustomDatePickerEditor();
        this.defineCustomDurationEditor();
        this.defineCustomEstimatedEditor();
        this.defineCustomOwnerEditor();

        const durationFormatter = gantt.ext.formatters.durationFormatter({
            enter: 'day',
            store: 'day',
            format: 'auto',
        });

        const textEditor = {type: 'text', map_to: 'text'};
        const durationEditor = {type: 'custom_duration_editor', map_to: 'duration', formatter: durationFormatter};
        const estimatedEditor = {type: 'custom_estimated_editor', map_to: 'estimated_hours' };
        const ownerEditor = {type:'custom_owner_editor', map_to:'owner_id' }
        return { textEditor, durationEditor, estimatedEditor, ownerEditor }
    }

    defineCustomDurationEditor() {
        gantt.config.editor_types.custom_duration_editor = {
            show: (id, column, config, placeholder) => {
                const task = gantt.getTask(id);
                if (gantt.getChildren(id).length > 0 && parentTaskSettings.dates_derived) {
                    return;
                }
                let min = 1;
                placeholder.innerHTML = `<div><input type='number' min=${min} max=500 id='duration_${id}' name='` +
                                        `${column.name}' value='${task.duration}'></div>`;
                const duration = document.getElementById(`duration_${id}`);
                duration.focus();
                duration.select();
            },

            hide: (node) => {
            },

            set_value: (value, id, column, node) => {
                let min = 1;
                const duration = document.getElementById(`duration_${id}`);
                if (duration) {
                    duration.value = value < min ? min : value;
                }
            },

            get_value: (id, column, node) => {
                const task = gantt.getTask(id);
                const duration = document.getElementById(`duration_${id}`);
                if (!duration) {
                    return task.duration;
                }
                let value = document.getElementById(`duration_${id}`).value;
                let min = 1;
                if (value < min) {
                    return min;
                } else {
                    return value;
                }
            },

            is_changed: (value, id, column, node) => {
                return true;
            },
            is_valid: (value, id, column, node) => {
                let min = 1;
                if (value < min) {
                    return false;
                } else {
                    return true;
                }
            },
            save: (id, column, node) => {
            },
            focus: (node) => {
            }
        };
    }

    defineCustomEstimatedEditor() {
        gantt.config.editor_types.custom_estimated_editor = {
            show: (id, column, config, placeholder) => {
                const task = gantt.getTask(id);
                if (task.type !== RXA.common.TYPE_TASK) {
                    return;
                }

                placeholder.innerHTML = `<div><input type='number' min=${0} id='estimated_hours_${id}' name='` +
                                        `${column.name}' value='${task.estimated_hours}'></div>`;
                const estimated = document.getElementById(`estimated_hours_${id}`);

                estimated.focus();
                estimated.select();
            },

            hide: (node) => {
            },

            set_value: (value, id, column, node) => {
                const estimated = document.getElementById(`estimated_hours_${id}`);
                if (estimated) {
                    estimated.value = value < 0 ? 0 : value;
                }
            },

            get_value: (id, column, node) => {
                const estimated = document.getElementById(`estimated_hours_${id}`);
                if (!estimated) {
                    return 0;
                }
                if (estimated.value < 0) {
                    return 0;
                } else {
                    return estimated.value;
                }
            },

            is_changed: (value, id, column, node) => {
                return true;
            },
            is_valid: (value, id, column, node) => {
                if (value < 0) {
                    return false;
                } else {
                    return true;
                }
            },
            save: (id, column, node) => {
            },
            focus: (node) => {
            }
        };
    }

    defineCustomOwnerEditor() {
        gantt.config.editor_types.custom_owner_editor = {
            show: (id, column, config, placeholder) => {
                const task = gantt.getTask(id);
                if (task.type !== RXA.common.TYPE_TASK) {
                    return;
                }

                const users = availableOwners(task);
                let options = '';
                for (let i = 0; i < users.length; i++) {
                    options += `<option value="${users[i].key}">${users[i].label}</option>`;
                }

                placeholder.innerHTML = `<div><select id='owner_${id}' name='${column.name}'>` +
                                        options +
                                        `</select></div>`;
                const ownerSelect = $(`#owner_${id}`);

                ownerSelect.select2({
                    placeholder: {
                        id: '-1', // the value of the option
                        text: I18n.task_unassigned,
                    },
                    allowClear: true,
                    selectOnClose: true,
                }).on('select2:unselecting', () => {
                    ownerSelect.data('unselecting', true);
                }).on('select2:opening', e => {
                    if (ownerSelect.data('unselecting')) {
                        ownerSelect.removeData('unselecting');
                        e.preventDefault();
                    }
                });
            },

            set_value: (value, id, column, node) => {
                const task = gantt.getTask(id);
                const ownerSelect = $(`#owner_${id}`);
                ownerSelect.val(task.owner_id);
                ownerSelect.trigger('change');
            },

            get_value: (id, column, node) => {
                const ownerSelect = $(`#owner_${id}`);;
                const selectedOption = ownerSelect.select2('data');
                if (selectedOption && selectedOption.length > 0) {
                    return selectedOption[0].id;
                } else {
                    return -1;
                }
            },

            hide: (node) => {},
            is_changed: (value, id, column, node) => { return true },
            is_valid: (value, id, column, node) => { return true },
            save: (id, column, node) => {},
            focus: (node) => {}
        };
    }

    /**
    * Initialize data store for resources
    * @return {void} - nothing is returned
    */
    initResourceDataStore() {
        const resourcesStore = gantt.createDatastore({
            name: gantt.config.resource_store,
            type: 'treeDatastore',
            initItem: (item) => {
                item.parent = item.parent || gantt.config.root_id;
                item[gantt.config.resource_property] = item.parent;
                item.open = true;
                return item;
            }
        });

        resourcesStore.attachEvent('onParse', () => {
            const users = [];
            resourcesStore.eachItem((res) => {
                if(res.id >= -1) {
                    const copy = gantt.copy(res);
                    delete copy.id;
                    delete copy.text;
                    users.push(copy);
                }
            });
            gantt.updateCollection('users', users);
        });

        //gantt.resourceDataStore = {};
    }
    /**
     * Customize project and task icons
     */
    changeItemsIcons() {
        gantt.templates.grid_file = (task) => {
            let showIcon = 'none';
            let dataWarning = '';
            const store = gantt.resourcesStore.store;
            if (store[task.uid]) {
                if (store[task.uid].elementObject.valuesObject.highEstimation) {
                    showIcon = 'block';
                    dataWarning += 'estimation_high ';
                }
                if (store[task.uid].elementObject.valuesObject.lowEstimation) {
                    showIcon = 'block';
                    dataWarning += 'estimation_low ';
                }
                if (store[task.uid].elementObject.valuesObject.isOverflow) {
                    showIcon = 'block';
                    dataWarning += 'hours_overflow ';
                }
            }
            return (`<div id='warning-icon-${task.uid}' class="warning-icon" data-warning="${dataWarning}" style='display: ${showIcon};margin: 0 5px;color: red;'>` +
                    "<i class='far fa fa-exclamation-triangle'></i>" +
                    "</div>");
        };

        gantt.templates.grid_folder = (task) => {
            let showIcon = 'none';
            let dataWarning = '';
            const store = gantt.resourcesStore.store;
            if (store[task.uid]) {
                if (store[task.uid].elementObject.valuesObject.highEstimation) {
                    showIcon = 'block';
                    dataWarning += 'estimation_high ';
                }
                if (store[task.uid].elementObject.valuesObject.lowEstimation) {
                    showIcon = 'block';
                    dataWarning += 'estimation_low ';
                }
                if (store[task.uid].elementObject.valuesObject.isOverflow) {
                    showIcon = 'block';
                    dataWarning += 'hours_overflow ';
                }
            }
            return (`<div id='warning-icon-${task.uid}' class="warning-icon" data-warning="${dataWarning}" style='display: ${showIcon};margin: 0 5px;color: red;'>` +
                    "<i class='far fa fa-exclamation-triangle'></i>" +
                    "</div>");
        };
    }

    calculateEstimatedHours(task) {
        let hours = 0;
        if (task.type === RXA.common.TYPE_TASK && task.estimated_hours) {
            hours = parseFloat(task.estimated_hours)
        }

        const children = gantt.getChildren(task.id);
        if (children.length > 0) {
            for (let i = 0; i < children.length; i++) {
                const childTask = gantt.getTask(children[i]);
                hours += parseFloat(this.calculateEstimatedHours(childTask));
            }
        }
        return hours;
    }

    calculateSpentHoursGroup(task) {
        let hours = 0;
        if (task.type === RXA.common.TYPE_TASK && task.total_hours) {
            hours = parseFloat(task.total_hours);
        }

        const children = gantt.getChildren(task.id);
        if (children.length > 0) {
            for (let i = 0; i < children.length; i++) {
                const childTask = gantt.getTask(children[i]);
                hours += parseFloat(this.calculateSpentHoursGroup(childTask));
            }
        }
        return hours;
    }

    calculateRemainingHoursGroup(task) {
        let hours = 0;

        if (task.type === RXA.common.TYPE_TASK) {
            if (task.total_hours && task.estimated_hours) {
                hours = parseFloat(task.estimated_hours) - parseFloat(task.total_hours);
            } else if (task.total_hours) {
                hours = -parseFloat(task.total_hours);
            } else {
                hours = parseFloat(task.estimated_hours);
            }
        }

        const children = gantt.getChildren(task.id);
        if (children.length > 0) {
            for (let i = 0; i < children.length; i++) {
                const childTask = gantt.getTask(children[i]);
                hours += parseFloat(this.calculateRemainingHoursGroup(childTask));
            }
        }
        return hours;
    }

    calculateRemainingHoursUser(task) {
        const hours = parseFloat(task.estimated_hours) - parseFloat(task.total_hours);
        return hours || 0;
    }

    calculateSpentHoursUser(task) {
        if (task.$total_hours_arrived) {
            task.$total_hours_arrived = false;
            return task.total_hours;
        } else {
            const children = gantt.getChildren(task.id);
            if (children.length <= 0) {
                return 0;
            } else {
                const issues = children.map(child => RXA.common.cleanId(child));
                task.$total_hours_arrived = false;
                this.fetchUserSpentTime(task, task.key, issues);
                return task.total_hours;
            }
        }
    }

    updateEstimatedHours(task, change) {
        if (task.$rendered_parent && gantt.isTaskExists(task.$rendered_parent)) {
            const parentTask = gantt.getTask(task.$rendered_parent);
            parentTask.estimated_hours = parseInt(parentTask.estimated_hours, 10) + change;
            gantt.refreshTask(parentTask.id);
            this.updateEstimatedHours(parentTask);
        }
    }

    hasNonZeroChildren(task) {
        if (task.duration <= 1 && gantt.getChildren(task.id).length <= 0) {
            return false;
        }
        const children = gantt.getChildren(task.id);
        for (let i = 0; i < children.length; i++) {
            const child = gantt.getTask(children[i]);
            if (child.type === RXA.common.TYPE_TASK) {
                return true;
            }
            if (this.hasNonZeroChildren(child)) {
                return true;
            }
        }
    }

    async fetchUserSpentTime(task, userId, issues) {
        const requestData = {
            user_spent_time: {
                user_id: userId,
                issues: issues
            }
        };
        fetchEntries(`${pathsToActions.plugin}/api/v1/resources/user_spent_time.json`, requestData)
            .then(result => {
                if (result && result.hours != undefined) {
                    task.total_hours = result.hours;
                } else {
                    task.total_hours = 0;
                }
                task.$total_hours_arrived = true;
                gantt.refreshTask(task.id);
            });
    }

    gridLinkColumnTemplate(task) {
        let link;
        if (task.utype == RXA.common.TYPE_PROJECT) {
            link = `<a href="${pathsToActions.projects}/${task.id}" target="_blank">` +
                '<i class="icon-gantt-external"></i></a>';
        } else if (task.utype == RXA.common.TYPE_USER) {
            link = `<a href="${pathsToActions.users}/${RXA.common.cleanId(task.uid)}" target="_blank">` +
                '<i class="icon-gantt-external"></i></a>';
        } else if (task.utype == RXA.common.TYPE_GROUP) {
            if (task.uid ===  'u-1' || task.uid === 'u1000000') {
                link = `<a href="javascript:void(0)" class="unsaved-task-link">` +
                '<i class="icon-gantt-external"></i></a>';
            } else {
                link = `<a href="${pathsToActions.groups}/${RXA.common.cleanId(task.uid)}" target="_blank">` +
                    '<i class="icon-gantt-external"></i></a>';
            }
        } else if (isNaN(task.id) && task.type == RXA.common.TYPE_TASK) {
            link = `<a href="${pathsToActions.issues}/${RXA.common.cleanId(task.id)}" target="_blank">` +
                '<i class="icon-gantt-external"></i></a>';
        } else if (isNaN(task.id) && task.type == RXA.common.TYPE_MILESTONE) {
            link = `<a href="${pathsToActions.milestones}/${RXA.common.cleanId(task.id)}" target="_blank">` +
                '<i class="icon-gantt-external"></i></a>';
        } else {
            link = `<a href="javascript:void(0)" class="unsaved-task-link">` +
                '<i class="icon-gantt-external"></i></a>';
        }

        return link;
    }
}
