
/**
* Lightbox (dialog for creation and modification of items on the gantt) customization
* according to the user rights and item type + new items for resources (assignee and priority)
*/
import { CREATE_TASK, UPDATE_TASK } from './resources_store.js';
import { availableOwners } from './common.js';
export class LightBox extends RXA.LightBox {

    initLightbox() {
        gantt.serverList('distributions', window.distributionsServerList);

        super.initLightbox();

        this.numberEditor();
        this.timeEditor();
        this.selectOwnerEditor();
        this.parentChange = null;
        this.allowedProjectsList = null;

        gantt.attachEvent('onTaskClick', (id) => {
            this.taskClickedId = id;
            return true;
        });

        gantt.attachEvent("onBeforeTaskAdd", (id, item) => {
            if (item.type === RXA.common.TYPE_TASK) {
                if (gantt.isTaskExists(id)) {
                    const task = gantt.getTask(id);
                    task.owner_id = RXA.common.cleanId(item.uparent);
                }
                item.owner_id = RXA.common.cleanId(item.uparent);
            }

            return true;
        })
    }

    onBeforeLightbox(id) {
        this.currentGanttPosition = gantt.getScrollState();
        const task = gantt.getTask(id);

        if (task.$new) {
            if (gantt.$groupMode) {
                task.type = RXA.common.TYPE_TASK;

                const parent = gantt.getTask(this.taskClickedId);
                let ownerId = task.owner_id;
                if (parent.type === RXA.common.TYPE_TASK) {
                    ownerId = parent.owner_id;
                    task.parent = parent.id;
                }
                this.allowedProjectsList = [];
                for (let i = 0; i < gantt.serverList('projects').length; i++) {
                    if (gantt.serverList('projects')[i].add_issues) {
                        if (!ownerId || ownerId == -1 ||
                            (
                                ownerId &&
                                Permissions[gantt.serverList('projects')[i].key].members.includes(ownerId) &&
                                Permissions[gantt.serverList('projects')[i].key].trackers.length > 0
                            ))
                        {
                            this.allowedProjectsList.push({ key: gantt.serverList('projects')[i].key, label: gantt.serverList('projects')[i].label });
                        }
                    }
                }
                if (parent.type === RXA.common.TYPE_PROJECT) {
                    if (this.allowedProjectsList.length > 0) {
                        task.parent = this.allowedProjectsList[0].key;
                    } else {
                        gantt.message({ type: 'error', text: I18n.no_project_user_warning, expire: 10000 });
                        gantt.deleteTask(id);
                        setTimeout(this.scrollBack.bind(this), 50);
                        return false;
                    }
                }
            } else {
                task.owner_id = -1;
            }
        }
        if (task.utype == RXA.common.TYPE_GROUP || task.utype == RXA.common.TYPE_USER) {
            return false;
        }

        return super.onBeforeLightbox(id);
    }

    /**
    * Redefines sections of edit lightbox defined in RedmineX Gantt light box (adds prioriy and owner)
    * @return {void} - nothing is returned
    */
    lightboxUpdate(task) {
        super.lightboxUpdateHeaderTemplate();
        const users = availableOwners(task);

        const taskLightboxSection = [
            { name: "description", height: 70, map_to: "text", type: "textarea" },
            { name: 'owner', height: 20, map_to: 'owner_id', type: 'select_owner_editor', options: users },
        ];
        if (gantt.hasChild(task.id) && parentTaskSettings.priority_derived) {
            taskLightboxSection.push({ name: "priority_message", height: 102, type: "priority_message_editor", map_to: "message1" });
        } else {
            taskLightboxSection.push({ name: 'priority', height: 20, map_to: 'priority_id', type: 'select', options: gantt.serverList('priorities')});
        }

        taskLightboxSection.push({ name: 'hours', height: 20, map_to: 'estimated_hours', type: 'number_editor', task: task });

        if (gantt.hasChild(task.id) && parentTaskSettings.dates_derived) {
            taskLightboxSection.push({ name: "date_message", height: 102, type: "date_message_editor", map_to: "message2" });
        } else {
            taskLightboxSection.push({ name: 'time', height: 20, map_to: 'auto', type: 'resources_time_editor' });
        }

        gantt.config.lightbox.sections = taskLightboxSection;

        gantt.config.lightbox.milestone_sections = [
            { name: 'description', height: 70, map_to: 'text', type: 'textarea' },
            { name: 'time', height: 72, type: 'duration', map_to: 'auto', single_date: true }
        ];

        gantt.config.lightbox.project_sections = [
            { name: "distribution", height: 72, type: "select", map_to: "distribution", options: gantt.serverList('distributions') }
        ];
    };

    /**
    * Redefines sections of new lightbox defined in RedmineX Gantt light box (adds prioriy and owner)
    * @return {void} - nothing is returned
    */
    lightboxNew(filter, task, isMilestone = false, isParentProject) {
        super.lightboxNewHeaderTemplate();
        if (gantt.$groupMode) {
            gantt.config.lightbox.sections = [
                { name: 'description', height: 70, map_to: 'text', type: 'textarea', default_value: '' } ];

            if (isParentProject) {
                gantt.config.lightbox.sections.push(
                    { name: 'project', height: 20, map_to: 'parent', type: 'select', options: this.allowedProjectsList }
                );
            }

            gantt.config.lightbox.sections = gantt.config.lightbox.sections.concat([
                { name: 'priority', height: 20, map_to: 'priority_id', type: 'select', options: gantt.serverList('priorities')},
                { name: 'hours', height: 20, map_to: 'estimated_hours', type: 'number_editor', default_value: 0 },
                { name: 'time', height: 20, map_to: 'auto', type: 'resources_time_editor' },
            ]);
        } else {
            const users = availableOwners(task, true);

            gantt.config.lightbox.sections = [
                { name: 'description', height: 70, map_to: 'text', type: 'textarea' },
                { name: 'type', type: 'typeselect', map_to: 'type', filter: filter },
                { name: 'owner', height: 20, map_to: 'owner_id', type: 'select_owner_editor', options: users, default_value: ""},
                { name: 'priority', height: 20, map_to: 'priority_id', type: 'select', options: gantt.serverList('priorities')},
                { name: 'hours', height: 20, map_to: 'estimated_hours', type: 'number_editor' },
                { name: 'time', height: 20, map_to: 'auto', type: 'resources_time_editor' },
            ];
        }
        gantt.config.lightbox.milestone_sections = [
            { name: 'description', height: 70, map_to: 'text', type: 'textarea', default_value: '' },
            { name: 'type', type: 'typeselect', map_to: 'type', filter: filter },
            { name: 'time', height: 72, type: 'duration', map_to: 'auto', single_date: true }
        ];
    }

    /**
    * Defines owner editor of task
    * @return {void} - nothing is returned
    */
     selectOwnerEditor() {
        gantt.form_blocks["select_owner_editor"] = {
            render: (sns) => { //sns - the section's configuration object
                let optionsHtml = '';
                for (let i = 0; i < sns.options.length; i++) {
                    optionsHtml += `<option value="${sns.options[i].key}">${sns.options[i].label}</option>`
                }
                return "<div class='gantt-owner-editor'>" +
                       `<select id='gantt-owner-select'>${optionsHtml}</select>` +
                       "</div>";
            },
            set_value: (node, value, task, section) => {
                const selectBox = $(node).find('#gantt-owner-select');
                selectBox.select2({
                    dropdownParent: $('div[role="dialog"].gantt_cal_light'),
                    placeholder: {
                        id: '-1', // the value of the option
                        text: I18n.task_unassigned,
                    },
                    allowClear: true,
                    selectOnClose: true,
                }).on('select2:unselecting', () => {
                    selectBox.data('unselecting', true);
                }).on('select2:opening', e => {
                    if (selectBox.data('unselecting')) {
                        selectBox.removeData('unselecting');
                        e.preventDefault();
                    }
                });

                selectBox.val(task.owner_id);
                selectBox.trigger('change');

                const timeEditorNode = $('div.gantt-time-editor');
                selectBox.change(() => this.onTimeEditorChange(timeEditorNode));
            },
            get_value: (node, task, section) => {
                const selectBox = $(node).find("#gantt-owner-select");
                const selectedOption = selectBox.select2('data');
                if (selectedOption.length > 0) {
                    return selectedOption[0].id;
                } else {
                    return -1;
                }
            },
            focus: node => {}
        }
    }

    /**
    * Defines number editor for input of estimated time
    * @return {void} - nothing is returned
    */
    numberEditor() {
        gantt.form_blocks['number_editor'] = {
            render: sns => {
                return "<div class='gantt_cal_ltext' style='height:23px;'>" +
                    "<input class='number_editor' type='number' min='0'>" +
                    "</div>";
            },
            set_value: (node, value, task) => {
                const estimatedInput = node.querySelector('.number_editor');
                estimatedInput.addEventListener('change', () => this.onEstimatedEditorChange(node));
                estimatedInput.value = value || 0;
            },
            get_value: (node, task) => {
                return parseInt(node.querySelector(".number_editor").value, 10);
            },
            focus: node => {}
        };
    }

    /**
     * Changes duration and end date of the time editor based on current estimated hours
     * and task owner (=calendar)
     * @param {*} node - html div element enclosing estimation input
     * @return {void} - nothing is returned
     */
    onEstimatedEditorChange(node) {
        const estimatedInput = $(node).find('input.number_editor');
        const durationInput = $('div.gantt-time-editor input[name="duration"]');
        const startDate = $('div.gantt-time-editor input[name="start"]').datepicker('getDate');
        const ownerId = $('#gantt-owner-select').val();
        const calendar = gantt.getCalendar(ownerId);

        // Change duration according to the estimated time value;
        if (Number.isNaN(estimatedInput.val()) ||  estimatedInput.val() < 0 || estimatedInput.val().trim() === '') {
            estimatedInput.val(0);
        }

        if (durationInput) {
            let endDate = calendar.calculateEndDate(startDate, estimatedInput.val(), 'hour');
            if (endDate.getHours() > 0) {
                endDate = new Date(endDate.getTime() + (24 - endDate.getHours()) * 60 * 60 * 1000);
            }
            const duration = calendar.calculateDuration(startDate, endDate);
            if (durationInput.val() < duration) {
                durationInput.val(duration);
                const timeEditorNode = $('div.gantt-time-editor');
                this.onTimeEditorChange(timeEditorNode);
            }
        }
    }

    /**
    * Defines our custom time editor, which allows user to input start date and duration
    * - end date is then calculated automatically
    * @return {void} - nothing is returned
    */
    timeEditor() {
        gantt.form_blocks["resources_time_editor"] = {
            render: (sns) => { //sns - the section's configuration object
                return "<div class='gantt-time-editor'><input type='text' name='start'>" +
                       "<input type='number' min='1' value='1' name='duration'>" +
                       "<span class='gantt-label-days'></span>" +
                       "<span class='gantt-lb-datepicker-label'></span></div>";
            },
            set_value: (node, value, task, section) => {
                const startDate = $(node).find("input[name='start']");
                const duration = $(node).find("input[name='duration']");
                const daysLabel = $(node).find("span.gantt-label-days");
                const endDateLabel = $(node).find("span.gantt-lb-datepicker-label");

                const datepickerOptions = { 
                    dateFormat: dateFormat.jQuery,
                    onSelect: () => this.onTimeEditorChange(node, task),
                }

                if (task.min_start_date) {
                    datepickerOptions.maxDate = task.min_start_date;
                }

                startDate.datepicker(datepickerOptions);
                startDate.datepicker( $.datepicker.regional[ I18n.date_jquery_locale ] );
                startDate.datepicker('setDate', task.start_date);

                duration.val(task.duration || 1);
                duration.change(() => this.onTimeEditorChange(node, task));

                const startValue = startDate.datepicker('getDate');
                const endDate = gantt.calculateEndDate({
                    start_date: startValue, duration: duration.val(), task: task
                })

                if (duration.val() >= 5) {
                    daysLabel.text(I18n.date_label_day_plural_2);
                } else if (duration.val() == 1) {
                    daysLabel.text(I18n.date_label_day);
                } else {
                    daysLabel.text(I18n.label_day_plural);
                }

                endDateLabel.text(RXA.common.dateToStr(gantt.date.add(endDate, -1, 'day')));
            },
            get_value: (node, task, section) => {
                const startDate = $(node).find("input[name='start']");
                const duration = $(node).find("input[name='duration']");

                const startValue = startDate.datepicker('getDate');
                const endDate = gantt.calculateEndDate({
                    start_date: startValue, duration: duration.val(), task: task
                })

                task.start_date = startValue;
                task.duration = parseInt(duration.val(), 10);
                task.end_date = endDate;

                return {
                    start_date: task.start_date,
                    end_date: task.end_date,
                    duration: task.duration
                }
            },
            focus: node => {}
        }
    }

    /**
     * Changes end date of the time editor based on the current duration and task owner (=calendar)
     * @param {*} node - html div element enclosing time editor inputs and labels
     * @return {void} - nothing is returned
     */
    onTimeEditorChange(node) {
        const startDate = $(node).find("input[name='start']");
        const duration = $(node).find("input[name='duration']");
        const daysLabel = $(node).find("span.gantt-label-days");
        const endDateLabel = $(node).find("span.gantt-lb-datepicker-label");
        const ownerId = $('#gantt-owner-select').val();
        let calendar = gantt.getCalendar(ownerId);
        if (!calendar) calendar = gantt.getCalendar('global');

        const startValue = startDate.datepicker('getDate');

        if (Number.isNaN(duration.val()) || duration.val() < 1 || duration.val().trim() === '') {
            duration.val(1);
        }

        if (parseInt(duration.val(), 10) < 1) {
            duration.val(1);
        }

        const durationValue = duration.val();
        let endDate;

        if(startValue && durationValue) {
            endDate = calendar.calculateEndDate({
                start_date: startValue, duration: durationValue,
            })
        }

        if (duration.val() >= 5) {
            daysLabel.text(I18n.date_label_day_plural_2);
        } else if (duration.val() == 1) {
            daysLabel.text(I18n.date_label_day);
        } else {
            daysLabel.text(I18n.label_day_plural);
        }

        endDateLabel.text(RXA.common.dateToStr(gantt.date.add(endDate, -1, 'day')));
    }

    verifySave(id, task, is_new) {
        const oldTask = gantt.getTask(id);

        if (task.type === RXA.common.TYPE_PROJECT) {
            if (task.distribution !== oldTask.distribution) {
                const tasks = RXA.common.getAllChildrenTasks(id, false).tasks;
                for (let i = 0; i < tasks.length; i++) {
                    const child = gantt.getTask(tasks[i].key);
                    child.distribution = task.distribution;
                    if (RXA.common.diffDates(new Date(), child.end_date) > 0)
                    {
                        if (!gantt.resourcesStore.store[child.uid]) {
                            gantt.resourcesStore.processAction(CREATE_TASK, { task: child });
                        }
                        gantt.resourcesStore.processAction(UPDATE_TASK, { task: child });
                    }
                }
            }
            return true;
        }

        const parentTask = gantt.getTask(task.parent);

        if (task.text.trim() === '') {
            gantt.message({ type: 'error', text: `${I18n.field_subject} ${I18n.blank}`, expire: 5000 });
            return false;
        }

        if (task.parent) {
            if (parentTask.type === RXA.common.TYPE_MILESTONE) {
                task.milestone = RXA.common.cleanId(parentTask.id);
            }
            if (parentTask.type === RXA.common.TYPE_TASK) {
                parentTask.has_children = true;
            }
        }

        if (task.type === RXA.common.TYPE_TASK) {
            this.prepareTaskForSave(task, is_new);
        } else if (task.type === RXA.common.TYPE_MILESTONE) {
            this.prepareMilestoneForSave(task, is_new);
        }

        if (is_new) {
            if (!RXA.scheduling.onBeforeTaskChanged(null, 'mode_new', oldTask, null, task)) return false;
        } else {
            if (!RXA.scheduling.onBeforeTaskChanged(null, null, oldTask, null, task)) return false;
        }

        if (!is_new && task.type === RXA.common.TYPE_TASK) {
            gantt.resourcesStore.processAction(UPDATE_TASK, { task });
        }

        return true;
    }

    prepareTaskForSave(task, is_new) {
        const priorities = gantt.serverList('priorities');
        priorities.forEach(priority => {
            if (priority.key.toString() === task.priority_id.toString()) {
                task.priority = priority.position_name;
                task.priority_position = priority.position;
            }
        });

        if (is_new) {
            const parentTask = gantt.getTask(task.parent);
            if (gantt.$groupMode && parentTask.type === RXA.common.TYPE_TASK) {
                task.owner_id = parentTask.owner_id;
            }
            task.total_hours = 0;
            task.uid = task.id;
            task.uparent = `u${task.owner_id}`;
            task.type = RXA.common.TYPE_TASK;
            task.utype = RXA.common.TYPE_TASK;
            this.newTaskId = task.id;
            task.author = userName;
            task.author_id = userId;
            task.has_children = false;
        } else {
            task.uparent = `u${task.owner_id}`;
        }
    }

    prepareMilestoneForSave(task, is_new) {
        if (is_new) {
            task.project_id = task.parent;
            task.owner_project_id = task.parent;
            task.open = true;
            task.shared = false;
        }
    };

    changeTaskOwner(task, oldTask, is_new) {
        if (gantt.$groupMode && is_new) {
            this.parentChange = {
                newOwnerId: `u${task.owner_id}`,
                start: task.start_date,
                end: gantt.date.add(task.end_date, -1, 'day'),
            };
        } else if (!gantt.$groupMode && is_new) {
            this.parentChange = {
                taskParentId: RXA.common.getProjectId({ taskId: task.parent }),
                start: task.start_date,
                end: gantt.date.add(task.end_date, -1, 'day'),
            };
        } else if (gantt.$groupMode && oldTask.owner_id.toString() !== task.owner_id.toString()) {
            task.uparent = `u${task.owner_id}`;
            this.parentChange = {
                taskParentId: task.parent,
                oldOwnerId: `u${oldTask.owner_id}`,
                newOwnerId: `u${task.owner_id}`,
                start: task.start_date,
                end: gantt.date.add(task.end_date, -1, 'day'),
            };
        }
    }

    verifyDelete(id) {
        const task = gantt.getTask(id);
        if (task.type === RXA.common.TYPE_MILESTONE &&
            id.toString().startsWith(RXA.common.PREFIX_ID_MILESTONE) &&
            gantt.getChildren(id).length > 0)
        {
            gantt.message({ type: 'error', text: I18n.lightbox_unable_delete_milestone, expire: 5000 });
            return false;
        }
        return true;
    }

    // onAfterLightbox() {
    //     super.onAfterLightbox();
    //     console.log('on after lightbox');

    //     // if (this.parentChange) {
    //     //     gantt.resourcesStore.processAction(UPDATE_USERS_CHILDREN_TASKS, this.parentChange);
    //     //     this.parentChange = null;
    //     // }
    // }

    showAddButtonClass(start, end, task) {
        if (!task.type) {
            return '';
        }

        const projectId = RXA.common.getProjectId({ task });

        if (gantt.$groupMode) {
            switch (task.utype) {
                case RXA.common.TYPE_USER:
                    let addIssue = false;
                    for (const id in Permissions) {
                        if (id === 'add' || id === 'cross_project_links') {
                            continue;
                        } else if (Permissions[id].add_issues) {
                            addIssue = true;
                            break;
                        }
                    }
                    if (!addIssue) {
                        return 'hide-add-button';
                    }
                    break;
                case RXA.common.TYPE_TASK:
                    if (!Permissions[projectId].manage_subtasks || !Permissions[projectId].add_issues) {
                        return 'hide-add-button';
                    }
                    break;
            }
        } else {
            switch (task.utype) {
                case RXA.common.TYPE_PROJECT:
                    if (!Permissions[projectId] ||
                        (Permissions[projectId].manage_versions === false &&
                        Permissions[projectId].add_issues === false))
                    {
                        return 'hide-add-button';
                    }
                    break;
                case RXA.common.TYPE_MILESTONE:
                case RXA.common.TYPE_TASK:
                    if (!Permissions[projectId].manage_subtasks || !Permissions[projectId].add_issues) {
                        return 'hide-add-button';
                    }
                    break;
            }
        }
        return '';
    }

    newLigthbox(task) {
        if (gantt.$groupMode) {
            const parent = gantt.getTask(task.parent);
            if (parent.type === RXA.common.TYPE_PROJECT) {
                this.lightboxNew(null, task, false, true);
            } else {
                this.lightboxNew(null, task, false, false);
            }
            gantt.resetLightbox();
            return true;
        } else {
            const parentTask = gantt.getTask(task.parent);
            const projectId = RXA.common.getProjectId({ task: task });
            switch (parentTask.type) {
                case RXA.common.TYPE_PROJECT:
                    if (Permissions[projectId].manage_versions && Permissions[projectId].add_issues) {
                        this.lightboxNew(this.filterTaskAndMilestone, task);
                    } else if (Permissions[projectId].manage_versions) {
                        this.lightboxNew(this.filterMilestoneOnly, task, true);
                    } else if (Permissions[projectId].add_issues) {
                        this.lightboxNew(this.filterTaskOnly, task);
                    } else {
                        return false;
                    }
                    gantt.resetLightbox();
                    return true;
                case RXA.common.TYPE_MILESTONE:
                    if (Permissions[projectId].add_issues) {
                        this.lightboxNew(this.filterTaskOnly, task);
                    } else {
                        return false;
                    }
                case RXA.common.TYPE_TASK:
                    if (Permissions[projectId].manage_subtasks && Permissions[projectId].add_issues) {
                        this.lightboxNew(this.filterTaskOnly, task);
                        gantt.resetLightbox();
                        return true;
                    } else {
                        return false;
                    }
            }
        }
    }
}