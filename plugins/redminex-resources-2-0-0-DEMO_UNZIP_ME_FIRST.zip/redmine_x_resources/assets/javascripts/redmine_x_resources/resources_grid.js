/**
* Configures resources grid
*/
export class ResourcesGrid {
    /**
    * Initializes resources data store and loads data into it
    * @return {void} - nothing is returned
    */
    initResourcesGrid() {
        this.drawResources();
    }

    /**
    * Adds renderer function, which renders resource bars in the data layer above the tasks
    * @return {void} - nothing is returned
    */
    drawResources() {
        gantt.addTaskLayer({
            renderer: {
                render: (task) => {
                    const element = gantt.resourcesStore.getEl(task);
                    return element;
                },
                // define getRectangle in order to hook layer with the smart rendering
                getRectangle: (task, view) => {
                    return gantt.getTaskPosition(task);
                }
            }
        });
    }

}
