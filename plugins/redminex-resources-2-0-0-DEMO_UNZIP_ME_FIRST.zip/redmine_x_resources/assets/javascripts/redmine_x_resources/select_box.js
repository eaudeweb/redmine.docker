export class SelectBox  {
    constructor() {
        this.removedUsersArr = [];
        this.removedProjectsArr = [];
        this.warningFilter = false;
    }

    initSelectBox() {
        this.initUsersSelect();
        if (!localResources) {
            this.initProjectsSelect();
        }
        this.showTasksWithWarning();
        this.filter()
    }

    initUsersSelect() {
        const buttonLeft = document.getElementById("users-btn-left");
        const buttonRight = document.getElementById("users-btn-right");

        buttonLeft.addEventListener('click', (event) => this.moveUserItem('users-box-left', 'users-box-right'));
        buttonRight.addEventListener('click', (event) => this.moveUserItem('users-box-right', 'users-box-left'));

        const buttonSubmit = document.getElementById("users-btn-submit");
        buttonSubmit.addEventListener('click', (event) => this.submitUserFilter());
        this.fillUserSelects();
    }

    initProjectsSelect() {
        const buttonLeft = document.getElementById("projects-btn-left");
        const buttonRight = document.getElementById("projects-btn-right");

        buttonLeft.addEventListener('click', (event) => this.moveItem('projects-box-left', 'projects-box-right'));
        buttonRight.addEventListener('click', (event) => this.moveItem('projects-box-right', 'projects-box-left'));

        const buttonSubmit = document.getElementById("projects-btn-submit");
        buttonSubmit.addEventListener('click', (event) => this.submitProjectFilter());
        this.fillProjectSelects();
    }

    getChildren(box, item) {
        if (parseInt(item.dataset.level, 10) > 0) return [];

        const children = [];
        const parentId = item.value;
        let findChildren = false;
        for (let i = 0; i < box.options.length; i++) {
            if (box.options[i].value == item.value) {
                findChildren = true;
                continue;
            }
            // When we find the position of the item, go through all following ones
            // to find out all potential subitems
            if (findChildren) {
                if (box.options[i].dataset.parent == parentId) {
                    children.push(box.options[i]);
                }
            }
        }
        return children;
    }

    getParent(box, item) {
        if (parseInt(item.dataset.level, 10) <= 0) return null;

        for (let i = 0; i < box.options.length; i++) {
            if (box.options[i].value == item.dataset.parent) {
                return(box.options[i]);
            }
        }
    }

    findItem(box, item) {
        for (let i = 0; i < box.options.length; i++) {
            if (box.options[i].value == item.value) {
                return box.options[i];
            }
        }
        return null;
    }

    appendToParent(box, parent, item) {
        let findChildren = false
        for (let i = 0; i < box.options.length; i++) {
            if (box.options[i].value == parent.value) {
                findChildren = true;
                continue;
            }
            if (findChildren) {
                if (box.options[i].parent != parent.value) {
                    box.options[i].before(item);
                    return;
                }
            }
        }
        box.appendChild(item);
    }

    moveUserItem(from, to) {
        const fromBox = document.getElementById(from);
        const toBox = document.getElementById(to);

        // Go through all selected options in fromBox
        while (fromBox.selectedOptions.length > 0) {
            // Find what position selected option is on and add it to itemsToMove along with its
            // potential children
            const item = fromBox.selectedOptions[0];
            const isParent = parseInt(item.dataset.level, 10) == 0;
            const children = this.getChildren(fromBox, item);

            if (isParent) {
                // Parent
                const toParent = this.findItem(toBox, item);
                if (toParent) {
                    for (let i = 0; i < children.length; i++) {
                        this.appendToParent(toBox, toParent, children[i]);
                    }
                    item.remove();
                } else {
                    toBox.appendChild(item);
                    for (let i = 0; i < children.length; i++) {
                        toBox.appendChild(children[i]);
                    }
                }
            } else {
                // Child
                const parent = this.getParent(fromBox, item);
                const parentChildren = this.getChildren(fromBox, parent);
                const toParent = this.findItem(toBox, parent);
                if (toParent) {
                    this.appendToParent(toBox, toParent, item);
                } else {
                    toBox.appendChild(parent.cloneNode(true));
                    toBox.appendChild(item);
                }
                if (parentChildren.length <= 1) {
                    parent.remove();
                }
            }
        }
    }

    moveItem(from, to) {
        const fromBox = document.getElementById(from);
        const toBox = document.getElementById(to);

        //const length = fromBox.selectedOptions.length;
        // for (let i = 0; i < length; i++) {
        //     toBox.appendChild(fromBox.selectedOptions[0]);
        // }
        let itemsToMove = [];
        let topLevel = null;
        let appended = false;
        // Go through all selected options in fromBox
        while (fromBox.selectedOptions.length > 0) {
            // Find where on what position selected option is
            for (let i = 0; i < fromBox.options.length; i++) {
                if (fromBox.options[i].value === fromBox.selectedOptions[0].value) {
                    itemsToMove.push(fromBox.options[i]);
                    topLevel = parseInt(fromBox.options[i].dataset.level, 10);
                    continue;
                }
                // When we found the position of the selected option, go through all following ones
                // to find out all potential subitems
                if (topLevel != null) {
                    if (parseInt(fromBox.options[i].dataset.level) > topLevel) {
                        itemsToMove.push(fromBox.options[i]);
                        continue;
                    } else {
                        break;
                    }
                }
            }
            topLevel = null;

            // Now we have first selecte option plus its subitems in itemsToMove array
            appended = false;

            // Go through all options in toBox to find out, if we have 
            for (let i = 0; i < toBox.options.length; i++) {
                if (toBox.options[i].value == itemsToMove[0].dataset.parent) {
                    for (let j = itemsToMove.length - 1; j >= 0; j--) {
                        toBox.options[i].after(itemsToMove[j]);
                    }
                    appended = true;
                    break;
                } else if (parseInt(toBox.options[i].dataset.level, 10) > 0) {
                    for (let j = 0; j < itemsToMove.length; j ++) {
                        if (itemsToMove[j].value == toBox.options[i].dataset.parent) {
                            if (j === itemsToMove.length - 1) {
                                itemsToMove.push(toBox.options[i]);
                            } else {
                                itemsToMove.splice(j + 1, 0, toBox.options[i]);
                            }
                        }
                    }
                }
            }
            if (!appended) {
                if (toBox.options.length > 0) {
                    for (let j = itemsToMove.length - 1; j >= 0; j--) {
                        toBox.options[0].before(itemsToMove[j]);
                    }
                } else {
                    for (let j = 0; j < itemsToMove.length; j++) {
                        toBox.appendChild(itemsToMove[j]);
                    }
                }
            }
            itemsToMove = [];
        }
    }

    fillUserSelects() {
        const selectedBox = document.getElementById('users-box-right');

        const unselected = gantt.localStorage.getUsersFilter();
        for (let i = 0; i < selectedBox.options.length; i++) {
            for (let j = 0; j < unselected.length; j++) {
                if (selectedBox.options[i].value.toString() === unselected[j].toString()) {
                    selectedBox.options[i].selected = true;
                }
            }
        }
        this.moveUserItem('users-box-right', 'users-box-left');
    }

    fillProjectSelects() {
        const unselectedBox = document.getElementById('projects-box-left');
        const selectedBox = document.getElementById('projects-box-right');

        const unselected = gantt.localStorage.getProjectsFilter();
        for (let i = 0; i < selectedBox.options.length; i++) {
            for (let j = 0; j < unselected.length; j++) {
                if (selectedBox.options[i].value.toString() === unselected[j].toString()) {
                    unselectedBox.appendChild(selectedBox.options[i]);
                }
            }
        }
    }

    submitUserFilter() {
        const selectedBox = document.getElementById('users-box-right');
        const unselectedBox = document.getElementById('users-box-left');
        const unselected = [];

        for(let i = 0; i < unselectedBox.options.length; i++) {
            if (parseInt(unselectedBox.options[i].dataset.level, 10) > 0 ||
                !this.findItem(selectedBox, unselectedBox.options[i]))
            {
                unselected.push(unselectedBox.options[i].value);
            }
        }

        gantt.localStorage.setUsersFilter(unselected);

        setTimeout(() => {
            this.removedProjectsArr = [];   
            this.removedUsersArr = [];
            gantt.render();
        }, 50);
    }

    submitProjectFilter() {
        const unselectedBox = document.getElementById('projects-box-left');
        const unselected = [];

        for(let i = 0; i < unselectedBox.options.length; i++) {
            unselected.push(unselectedBox.options[i].value)
        }

        gantt.localStorage.setProjectsFilter(unselected);

        setTimeout(() => {
            this.removedProjectsArr = [];
            this.removedUsersArr = [];
            gantt.render();
        }, 50);
    }

    filter() {
        gantt.attachEvent("onBeforeTaskDisplay", (id, task) => {
            if (task.type === RXA.common.TYPE_TASK && task.external === true) {
                return false;
            }
            const userOptions = document.getElementById('users-box-left').options;
            const userBoxRight = document.getElementById('users-box-right');
            for (let i = 0; i < userOptions.length; i++) {
                if (task.key && userOptions[i].value == task.key) {
                    if (parseInt(userOptions[i].dataset.level, 10) > 0 || !this.findItem(userBoxRight, userOptions[i])) {
                        return false;
                    }
                } else if (task.owner_id && userOptions[i].value == task.owner_id) {
                    if (parseInt(userOptions[i].dataset.level, 10) > 0 || !this.findItem(userBoxRight, userOptions[i])) {
                        return false;
                    }
                }
            }
            const projectBox = document.getElementById('projects-box-left');
            if (projectBox) {
                const projectOptions = projectBox.options;
                for (let i = 0; i < projectOptions.length; i++) {
                    if (projectOptions[i].value == task.id) {
                        return false;
                    } else if (task.parent && projectOptions[i].value == task.parent) {
                        return false;
                    }
                }
            }
            if (gantt.$groupMode) {
                if (task.type === RXA.common.TYPE_MILESTONE) {
                    return false;
                }
            }
            if (this.warningFilter) {
                const resources = gantt.resourcesStore.store[task.uid];
                if (resources && 
                    (resources.elementObject.valuesObject.isOverflow ||
                     resources.elementObject.valuesObject.highEstimation ||
                     resources.elementObject.valuesObject.lowEstimation))
                {
                    return true;
                } else {
                    return false;
                }
            }
            return true;
        });
    }

    showTasksWithWarning() {
        const radios = document.getElementsByName('tasks');
        for (let i = 0; i < radios.length; i++) {
            radios[i].onclick = (event) => {
                if (event.target.value === 'warning') {
                    gantt.localStorage.setWarningTasks(true);
                    this.warningFilter = true;
                    gantt.render();
                } else {
                    gantt.localStorage.setWarningTasks(false);
                    this.warningFilter = false;
                    gantt.render();
                }
                event.target.checked = true;
            };
        }
    }

}