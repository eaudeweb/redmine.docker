import { FIXED_VALUE_SET, FIXED_VALUE_UNSET } from './resources_store.js';
import { nextEndDate }                        from './common.js';

const CHANGES_SAVE = 'save';
const CHANGES_CANCEL = 'cancel';
const CHANGES_RESET = 'reset';

export class EditBoxElement {
    constructor(task, taskElement) {
        this.task = task;
        this.taskElement = taskElement;
        this.inputElement = null;
        this.sendAction = gantt.resourcesStore.sendAction;
    }

    update(task) {
        this.task = task;
    }

    showEditBox(event=null, rect=null, index=null) {
        const sizes = gantt.getTaskPosition(this.task);
        let taskX;
        if (event && rect) {
            taskX = event.clientX - rect.left;
        }
        const level = gantt.ext.zoom.getCurrentLevel();
        const zoom = gantt.ext.zoom.getLevels()[level];

        if (zoom.name === RXA.common.ZOOM_DAY) {
            const columnWidth = gantt.posFromDate(gantt.date.add(this.task.start_date, 1, 'day')) - gantt.posFromDate(this.task.start_date);
            index = index || Math.floor(taskX / columnWidth);
            let date;
            if (gantt.config.skip_off_time) {
                const tempEndDate = gantt.calculateEndDate(this.task.start_date, index + 1);
                date = gantt.date.add(tempEndDate, -1, 'day');
            } else {
                date = gantt.date.add(this.task.start_date, index, 'day');
            }

            if (RXA.common.diffDates(new Date(), date) < 0) {
                return;
            }

            const element = this.createEditElement(columnWidth * index, columnWidth, date);
            this.inputAddional(element);
        } else {
            const nextEnd = nextEndDate(this.task.start_date, this.task.end_date, zoom.name);

            const firstWidth = gantt.posFromDate(nextEnd) - gantt.posFromDate(this.task.start_date);

            if (taskX && firstWidth >= taskX) {
                const resourceElement = this.taskElement.querySelector(`div.resource-values div[data-start-date="${this.task.start_date.toDateString()}"]`);
                const endDate = new Date(resourceElement.dataset.endDate);
                if (RXA.common.diffDates(new Date(), endDate) < 0) {
                    return;
                }
                const element = this.createEditElement(0, firstWidth, this.task.start_date);
                this.inputAddional(element);
            } else {
                const start = nextEnd;
                const end = nextEndDate(start, new Date(2040, 0, 1), zoom.name);
                const columnWidth = gantt.posFromDate(end) - gantt.posFromDate(start);
                const resourceElement = this.taskElement.querySelector(`div.resource-values div[data-start-date="${start.toDateString()}"]`);

                if (!index) {
                    const rest = taskX - firstWidth;
                    index = Math.floor(rest / columnWidth) + 1;
                }

                const endDate = new Date(resourceElement.dataset.endDate);
                if (RXA.common.diffDates(new Date(), endDate) < 0) {
                    return;
                }
                const left = (index - 1) * columnWidth + firstWidth;
                const width = (left + columnWidth) <= sizes.width ? columnWidth : sizes.width - left;
                const element = this.createEditElement(left, width, start);
                this.inputAddional(element);
            }
        }
    }

    inputAddional(element) {
        this.inputElement = element.cloneNode(true);
        this.taskElement.appendChild(element);
        element.querySelector('.resource-input').focus();
        element.querySelector('.resource-input').select();
    }

    createEditElement(left, width, startDate) {
        const parentElement = document.createElement('div');
        parentElement.className = 'resource-input-box';
        parentElement.dataset.startDate = startDate;
        parentElement.dataset.taskId = this.task.id;

        const button = document.createElement('button');
        button.className = 'resource-input-button';
        button.innerHTML = '<i class="far fa-trash-alt"></i>';

        const element = document.createElement('input');

        parentElement.appendChild(element);

        element.className = `resource-input`;
        element.setAttribute('type', 'number');
        element.setAttribute('min', '0');

        parentElement.style.position = 'absolute';
        parentElement.style.top = 0 + 'px';
        parentElement.style.left = left + width / 2 - 24 + 'px';

        //const valuesParent = this.taskElement.querySelector('.resource-values');
        const resourceElement = this.taskElement.querySelector(`div.resource-values div[data-start-date="${startDate.toDateString()}"]`);
        if (resourceElement) {
            element.value = resourceElement.innerText;
            if (resourceElement.classList.contains('value-fixed')) {
                parentElement.appendChild(button);
            }
        }
        // if (valuesParent.children.length > index) {
        //     element.value = valuesParent.children[index].innerText;
        //     if (valuesParent.children[index].classList.contains('value-fixed')) {
        //         parentElement.appendChild(button);
        //     }
        // }

        button.addEventListener('click', (event) => {
            event.stopPropagation();
            this.closeEditElement(CHANGES_RESET);
        })

        element.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') {
                parentElement.dataset.noBlur = '1';
                this.closeEditElement(CHANGES_SAVE);
            } else if (event.key === 'Escape') {
                parentElement.dataset.noBlur = '1';
                this.closeEditElement(CHANGES_CANCEL);
            }
            else if (event.shiftKey && event.key === 'Tab') {
                event.preventDefault();
                parentElement.dataset.noBlur = '1';
                const index = parseInt(parentElement.dataset.index, 10);
                this.closeEditElement(CHANGES_SAVE);
                if (index != 0) {
                    this.showEditBox(null, null, index - 1);
                }
            } else if (event.key === 'Tab') {
                event.preventDefault();
                parentElement.dataset.noBlur = '1';
                const valuesParent = this.taskElement.querySelector('.resource-values');
                const index = parseInt(parentElement.dataset.index, 10);
                this.closeEditElement(CHANGES_SAVE);
                if (valuesParent.children.length > index + 1) {
                    this.showEditBox(null, null, index + 1);
                }
            } else if (0 <= parseInt(event.key, 10) && parseInt(event.key, 10) <= 9) {
                parentElement.dataset.changed = '1';
            }
        });

        element.addEventListener('change', (event) => {
            parentElement.dataset.changed = '1';
        });

        this.documentOnClick = this.documentClickHandler.bind(this);
        document.addEventListener('click', this.documentOnClick);

        parentElement.addEventListener('dblclick', (event) => {
            event.preventDefault();
            event.stopPropagation();
        })

        return parentElement;
    }

    documentClickHandler(event) {
        const targetClass = event.target.className;
        if (targetClass == 'resource-input' ||
            targetClass == 'resource-input-button' ||
            targetClass == 'far fa-trash-alt')
        {
            return;
        }

        const parentElement = document.querySelector('div.resource-input-box');
        if (parentElement) {
            this.closeEditElement(CHANGES_SAVE);
        }
        document.removeEventListener('click', this.documentOnClick);
    }

    closeEditElement(changeState=CHANGES_SAVE) {
        //const valuesParent = this.taskElement.querySelector('.resource-values');
        const parentElement = document.querySelector('div.resource-input-box');

        //const index = parseInt(parentElement.dataset.index, 10)
        const startDate = new Date(parentElement.dataset.startDate);
        const resourceElement = this.taskElement.querySelector(`div.resource-values div[data-start-date="${startDate.toDateString()}"]`);
        if (resourceElement) {
            //const startDate = new Date(valuesParent.children[index].dataset.startDate);
            const endDate = new Date(resourceElement.dataset.endDate);
            const newValue = parseFloat(parentElement.querySelector('input.resource-input').value);
            const isChanged = parentElement.dataset.changed === '1';

            if (changeState === CHANGES_RESET) {
                this.sendAction(FIXED_VALUE_UNSET, { task: this.task, startDate, endDate });
            } else if (!Number.isNaN(newValue) && isChanged && changeState === CHANGES_SAVE) {
                this.sendAction(FIXED_VALUE_SET, { task: this.task, startDate, endDate, value: newValue });
                resourceElement.innerText = newValue;
            }
        }

        const input = this.taskElement.querySelector('div.resource-input-box');
        if (input) {
            this.inputElement = null;
            try { this.taskElement.removeChild(input) } catch {};
        }
    }
}