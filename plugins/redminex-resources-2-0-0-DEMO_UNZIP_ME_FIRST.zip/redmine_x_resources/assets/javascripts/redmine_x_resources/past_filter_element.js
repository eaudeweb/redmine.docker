export class PastFilterElement {
    constructor(task) {
        this.task = task;
        this.sizes = task.id ? gantt.getTaskPosition(task) : { top: 0, left: 0, width: 0, height: 0 };
    }

    update(task) {
        this.task = task;
        this.sizes = task.id ? gantt.getTaskPosition(task) : { top: 0, left: 0, width: 0, height: 0 };
    }

    createPastFilterElement() {
        const element = document.createElement('div');
        const today = new Date();

        element.className = 'resources-past-filter';
        element.style.position = 'absolute';
        element.style.left = 0;
        element.style.top = 0;

        if (RXA.common.diffDates(today, this.task.start_date) > 0) {
            element.style.width = 0;
            element.style.height = 0;
        } else if (RXA.common.diffDates(this.task.end_date, today) >= 0) {
            element.style.width = this.sizes.width + 'px';
            element.style.height = this.sizes.height + 'px';
        } else {
            const todayPosition = gantt.posFromDate(new Date((new Date()).toDateString()));
            element.style.width = todayPosition - this.sizes.left + 'px';
            element.style.height = this.sizes.height + 'px';
        }

        return element;
    }
}