export class Storage extends RXA.Storage {
    constructor(keyPrefix, local, projectId) {
        super(keyPrefix, local, projectId);

        this.verifyUsersFilter();
        if (!local) {
            this.verifyProjectsFilter();
        }
    }

    initialState() {
        const priorities = {}
        const filter_inputs = document.getElementById("filters_wrapper").getElementsByTagName("input");
        for (let i = 0; i < filter_inputs.length; i++) {
            let filter_value = filter_inputs[i].getAttribute('name');
            priorities[filter_value] = true;
        }

        return {
            timestamp: Date.now(),
            zoom: 'week',
            workdays: false,
            priorityFilter: priorities,
            milestoneFilter: 'milestones-all',
            groupUsers: true,
            warningTasks: false,
            usersFilter: [],
            projectsFilter: [],
        };
    }

    getGroupUsers() {
        return this.store.groupUsers;
    }

    setGroupUsers(value) {
        this.store.groupUsers = value;
        this.saveStateWithTimeStamp();
    }

    getWarningTasks() {
        return this.store.warningTasks;
    }

    setWarningTasks(value) {
        this.store.warningTasks = value;
        this.saveStateWithTimeStamp();
    }

    getUsersFilter() {
        return this.store.usersFilter;
    }

    setUsersFilter(unselected) {
        this.store.usersFilter = unselected;
        this.saveStateWithTimeStamp();
    }

    getProjectsFilter() {
        return this.store.projectsFilter;
    }

    setProjectsFilter(unselected) {
        this.store.projectsFilter = unselected;
        this.saveStateWithTimeStamp();
    }

    verifyUsersFilter() {
        const selectedBox = document.getElementById('users-box-right');

        for (let i = 0; i < this.store.usersFilter.length; i++) {
            const id = this.store.usersFilter[i];
            if (!this.includesOption(selectedBox.options, id)) {
                this.store.usersFilter.splice(i, 1);
            }
        }

        this.saveStateWithTimeStamp();
    }

    verifyProjectsFilter() {
        const selectedBox = document.getElementById('projects-box-right');

        for (let i = 0; i < this.store.projectsFilter.length; i++) {
            const id = this.store.projectsFilter[i];
            if (!this.includesOption(selectedBox.options, id)) {
                this.store.projectsFilter.splice(i, 1);
            }
        }

        this.saveStateWithTimeStamp();
    }

    includesOption(options, id) {
        for (let i = 0; i < options.length; i++) {
            if (options[i].value.toString() === id.toString()) {
                return true;
            }
        }
        return false;
    }

    // includesId(array, id) {
    //     for (let i = 0; i < array.length; i++) {
    //         if (array[i].id.toString() === id.toString()) {
    //             return true;
    //         }
    //     }
    //     return false;
    // }
}