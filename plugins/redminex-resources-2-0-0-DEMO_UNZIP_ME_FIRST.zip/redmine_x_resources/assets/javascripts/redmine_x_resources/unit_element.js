import { round1D } from './common.js';
export class UnitElement {
    constructor(startDate, endDate, value, isWorkTime, offset) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.value = value;
        this.isWorkTime = isWorkTime;
        this.offset = offset;
        this.element = this.createElement();
        this.elementClasses();
        if (!endDate) {
            debugger
        }
    }

    get el() {
        return this.element;
    }

    get start() {
        return this.startDate;
    }

    get end() {
        return this.endDate;
    }

    // updateValue(val) {
    //     this.value = val;
    //     this.element.innerText = Math.round(this.value.hours * 10) / 10;

    //     this.elementClasses();
    //     return this.element;
    // }

    update(startDate, endDate, value, offset, isWorkTime) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.offset = offset;
        if (!this.endDate) {
            debugger
        }
        this.value = value;
        this.isWorkTime = isWorkTime;
        this.updateElement();
    }

    createElement() {
        const left = gantt.posFromDate(this.startDate) - this.offset;
        const width = gantt.posFromDate(this.endDate) - this.offset - left;
        return this.createHtml(left, width);
    }

    createHtml(left, width) {
        const element = document.createElement('div');
        element.className = `resource-marker`;
        if (!this.isWorkTime)
        {
            element.classList.add('dayoff');
        }
        element.dataset.startDate = this.startDate.toDateString();
        element.dataset.endDate = this.endDate.toDateString();
        element.dataset.periodName = this.periodName();
        element.style.position = 'absolute';
        element.style.top = 0 + 'px';
        element.style.left = left + 'px';
        element.style.width = width + 'px';
        const value = this.elementValue();
        if (this.value) {
            element.dataset.here = this.value.planned;
            element.dataset.external = this.value.external;
        }

        element.innerHTML = `<span>${value}</span>`;
        return element;
    }

    updateElement() {
        const left = gantt.posFromDate(this.startDate) - this.offset;
        const width = gantt.posFromDate(this.endDate) - this.offset - left;
        if (this.isWorkTime) {
            this.element.classList.remove('dayoff');
        } else {
            this.element.classList.add('dayoff');
        }
        this.element.dataset.startDate = this.startDate.toDateString();
        this.element.dataset.endDate = this.endDate.toDateString();
        this.element.dataset.periodName = this.periodName();
        this.element.style.left = left + 'px';
        this.element.style.width = width + 'px';
        const value = this.elementValue();
        if (this.value) {
            this.element.dataset.here = this.value.planned;
            this.element.dataset.external = this.value.external;
        }
        this.element.innerHTML = `<span>${value}</span>`;
        this.elementClasses();
    }

    elementValue() {
        if (this.value && this.value.hours >= 0) {
            if (this.value.capacity !== undefined) {
                return `${round1D(this.value.hours)} / ${this.value.capacity}`;
            } else {
                return round1D(this.value.hours);
            }
        } else {
            return '&nbsp';
        }
    }

    elementClasses() {
        if (this.value.isOver) {
            this.element.classList.add('workday-over');
            this.element.classList.remove('workday-ok');
        } else if (this.value.isOk) {
            this.element.classList.add('workday-ok');
            this.element.classList.remove('workday-over');
        } else {
            this.element.classList.remove('workday-ok');
            this.element.classList.remove('workday-over');
        }
        if (this.value.isFixed) {
            this.element.classList.add('value-fixed');
        } else {
            this.element.classList.remove('value-fixed');
        }
    }

    periodName() {
        const level = gantt.ext.zoom.getCurrentLevel();
        const zoom = gantt.ext.zoom.getLevels()[level];

        if (zoom.name === RXA.common.ZOOM_DAY)
        {
            const day = I18n.date.day_names[this.startDate.getDay()];
            return day.charAt(0).toUpperCase() + day.slice(1) + ' ' +
                RXA.common.dateToStr(this.startDate);
        }

        const start = RXA.common.dateToStr(new Date(this.startDate));
        const end = RXA.common.dateToStr(gantt.date.add(new Date(this.endDate), -1, 'day'));

        return `${start} - ${end}`
    }
}