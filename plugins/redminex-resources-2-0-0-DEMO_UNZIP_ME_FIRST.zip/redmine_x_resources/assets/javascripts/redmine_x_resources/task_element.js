import { UnitElement } from './unit_element.js';
import { PastFilterElement } from './past_filter_element.js';
import { EditBoxElement } from './edit_box_element.js'

export class TaskElement {
    constructor(task, values) {
        this.task = task;
        this.sizes = task.id ? gantt.getTaskPosition(task) : { top: 0, left: 0, width: 0, height: 0 };
        this.valuesObject = values;
        this.subElementObjects = [];
        this.pastFilterElement = new PastFilterElement(this.task);
        this.element = this.createElement();
        this.createSubElements(this.values);
        this.taskWarnings();
        this.editBoxElement = new EditBoxElement(this.task, this.element);
    }

    get el() {
        return this.element;
    }

    updateDimensions(task) {
        if (task.$virtual && !gantt.$groupMode) return;

        this.task = task;
        this.sizes = task.id ? gantt.getTaskPosition(this.task) : { top: 0, left: 0, width: 0, height: 0 };
        this.updateElement();
        this.taskWarnings();
    }

    update(task, values) {
        if (task.$virtual && !gantt.$groupMode) return;

        this.task = task;
        this.sizes = task.id ? gantt.getTaskPosition(this.task) : { top: 0, left: 0, width: 0, height: 0 };
        if (values) {
            this.valuesObject = values;
        }
        this.updateElement();

        if (this.task.utype === RXA.common.TYPE_TASK) {
            this.pastFilterElement.update(this.task);
            this.element.removeChild(this.element.querySelector('.resources-past-filter'));
            this.element.appendChild(this.pastFilterElement.createPastFilterElement());
        }

        this.editBoxElement.update(this.task);

        this.updateSubElements();
        this.taskWarnings();
    }

    createElement() {
        const element = document.createElement('div');
        element.id = `resource-${this.task.uid}`;
        element.dataset.taskId = this.task.id;

        if (this.task.utype === RXA.common.TYPE_TASK) {
            element.style.left = this.sizes.left + 'px';
            element.style.top = this.sizes.top + 'px';
            element.style.width = this.sizes.width + 'px';
            element.style.height = this.sizes.height + 'px';
            element.style.pointerEvents = 'none';
            element.appendChild(this.pastFilterElement.createPastFilterElement());
        } else {
            const left = gantt.posFromDate(this.valuesObject.firstDayOfPeriod);
            const width = gantt.posFromDate(this.valuesObject.lastDayOfPeriod) - left;
            element.style.left = left + 'px';
            element.style.top = this.sizes.top + 'px';
            element.style.width = width + 'px';
            element.style.height = gantt.config.row_height - 2 + 'px';
        }

        const classType = this.task.type === RXA.common.TYPE_TASK ? 'resource-task' : 'resource-project'
        element.className = `resource-task-box ${classType}`;

        const valuesParent = document.createElement('div');
        valuesParent.className = 'resource-values';
        valuesParent.style.position = 'absolute';
        valuesParent.style.top = 0 + 'px';
        valuesParent.style.left = 0 + 'px';

        element.appendChild(valuesParent);

        return element;
    }

    updateElement() {
        this.element.dataset.taskId = this.task.id;
        if (this.task.utype === RXA.common.TYPE_TASK) {
            this.element.style.left = this.sizes.left + 'px';
            this.element.style.top = this.sizes.top + 'px';
            this.element.style.width = this.sizes.width + 'px';
            this.element.style.height = this.sizes.height + 'px';
        } else {
            const left = gantt.posFromDate(this.valuesObject.firstDayOfPeriod);
            const width = gantt.posFromDate(this.valuesObject.lastDayOfPeriod) - left;
            this.element.style.left = left + 'px';
            this.element.style.top = this.sizes.top + 'px';
            this.element.style.width = width + 'px';
            this.element.style.height = gantt.config.row_height - 2 + 'px';
        }
    }

    createSubElements() {
        const valuesParent = this.element.querySelector('.resource-values');

        let currentStart, currentEnd, offset;

        if (this.task.type == RXA.common.TYPE_PROJECT) {
            offset = gantt.posFromDate(this.valuesObject.firstDayOfPeriod);
        } else {
            offset = this.sizes.left;
        }

        for (let i = 0; i < this.valuesObject.values.length; i++) {
            if (i === 0 && this.task.type == RXA.common.TYPE_PROJECT) {
                currentStart = this.valuesObject.firstDayOfPeriod;
            } else {
                currentStart = this.valuesObject.values[i].start;
            }

            if (i === this.valuesObject.values.length - 1 && this.task.type == RXA.common.TYPE_PROJECT) {
                currentEnd = this.valuesObject.lastDayOfPeriod;
            } else {
                currentEnd = this.valuesObject.values[i].end;
            }
            const isWorkTime = gantt.getTaskCalendar(this.task).isWorkTime(currentStart);
            const subElement = new UnitElement(currentStart, currentEnd, this.valuesObject.values[i].val, isWorkTime, offset);
            this.subElementObjects.push(subElement);
            valuesParent.appendChild(subElement.el)
        }
    }

    updateSubElements() {
        const valuesParent = this.element.querySelector('.resource-values');
        let currentStart, currentEnd, offset, i;

        if (this.task.type == RXA.common.TYPE_PROJECT) {
            offset = gantt.posFromDate(this.valuesObject.firstDayOfPeriod);
        } else {
            offset = this.sizes.left;
        }

        for (i = 0; i < this.valuesObject.values.length; i++) {
            if (i === 0 && this.task.type == RXA.common.TYPE_PROJECT) {
                currentStart = this.valuesObject.firstDayOfPeriod;
            } else {
                currentStart = this.valuesObject.values[i].start;
            }

            if (i === this.valuesObject.values.length - 1 && this.task.type == RXA.common.TYPE_PROJECT) {
                currentEnd = this.valuesObject.lastDayOfPeriod;
            } else {
                currentEnd = this.valuesObject.values[i].end;
            }
            let value = { hours: 0, start: new Date(), end: new Date() };
            if (this.valuesObject) {
                value = this.valuesObject.values[i].val;
            }
            if (i < valuesParent.children.length) {
                this.updateSubElement(currentStart, currentEnd, value, valuesParent, offset, i);
            } else {
                const calendar = gantt.getTaskCalendar(this.task);
                const isWorkTime = calendar.calculateDuration(currentStart, currentEnd) > 0;
                const subElement = new UnitElement(currentStart, currentEnd, value, isWorkTime, offset);
                this.subElementObjects.push(subElement);
                valuesParent.appendChild(subElement.el);
            }
        }

        if (valuesParent.children.length > i) {
            const length = valuesParent.children.length - 1;
            for (let j = length; j >= i; j--) {
                valuesParent.removeChild(valuesParent.children[j]);
                this.subElementObjects.pop();
            }
        }
    }

    updateSubElement(startDate, endDate, value, valuesParent, offset, index) {
        let element;
        if (this.subElementObjects[index]) {
            element = this.subElementObjects[index];
            const calendar = gantt.getTaskCalendar(this.task);
            const isWorkTime = calendar.calculateDuration(startDate, endDate) > 0;
            element.update(startDate, endDate, value, offset, isWorkTime);
        }
    }

    taskWarnings() {
        const valuesParent = this.element.querySelector('.resource-values');
        const taskLine = document.querySelector(`div.gantt_task_line[task_id="${this.task.id}"]`);
        const warningIcon = document.getElementById(`warning-icon-${this.task.uid}`);
        if (warningIcon) {
            warningIcon.dataset.warning = '';
        }
        if (this.valuesObject.isOverflow) {
            valuesParent.classList.add('hours_overflow');
            if (taskLine) {
                taskLine.classList.add('hours_overflow');
            }
            if (warningIcon) {
                warningIcon.style.display = 'block';
                warningIcon.dataset.warning += 'hours_overflow ';
            }
        } else {
            valuesParent.classList.remove('hours_overflow');
            if (taskLine) {
                taskLine.classList.remove('hours_overflow');
            }
        }
        if (this.valuesObject.lowEstimation) {
            valuesParent.classList.add('estimation_low');
            if (taskLine) {
                taskLine.classList.add('estimation_low');
            }
            if (warningIcon) {
                warningIcon.style.display = 'block';
                warningIcon.dataset.warning += 'estimation_low ';
            }
        } else {
            valuesParent.classList.remove('estimation_low');
            if (taskLine) {
                taskLine.classList.remove('estimation_low');
            }
        }
        if (this.valuesObject.highEstimation) {
            valuesParent.classList.add('estimation_high');
            if (taskLine) {
                taskLine.classList.add('estimation_high');
            }
            if (warningIcon) {
                warningIcon.style.display = 'block';
                warningIcon.dataset.warning += 'estimation_high ';
            }
        } else {
            valuesParent.classList.remove('estimation_high');
            if (taskLine) {
                taskLine.classList.remove('estimation_high');
            }
        }

        if (!this.valuesObject.isOverflow &&
            !this.valuesObject.highEstimation &&
            !this.valuesObject.lowEstimation &&
            warningIcon)
        {
            warningIcon.style.display = 'none';
        }
    }
}