import { CREATE_OTHER, NEW_VALUES, NEW_VALUES_PARENT, DOWNLOADED_VALUES } from './resources_store.js';
import { fetchEntries, distributionType, roundDistribution } from './common.js';

export const TYPE_ENTRY = 'TYPE_ENTRY';
export const TYPE_FIXED = 'TYPE_FIXED';
export const TYPE_DISTRIBUTION = 'TYPE_DISTRIBUTION';
export const TYPE_DAYOFF = 'TYPE_DAYOFF';

export const PARENT_MODE_ADD = 'PARENT_MODE_ADD';
export const PARENT_MODE_REMOVE = 'PARENT_MODE_REMOVE';
export const PARENT_MODE_CHANGE = 'PARENT_MODE_CHANGE';

export class ResourceActions {
    constructor() {
        this.sendAction = gantt.resourcesStore.sendAction;
    }

    async fetchResourcesData() {
        const projectsAndUsers = gantt.serverList('projects_and_users');
        const users = gantt.serverList('users');
        const requestData = {
            projects_and_users: {
                projects: projectsAndUsers[0].projects,
                users: users.reduce((a, v) => ({ ...a, [v.key]: v }), {}),
                //users: projectsAndUsers[1].users,
                global: !localResources
            }
        }

        fetchEntries(`${pathsToActions.plugin}/api/v1/resources/issues_and_users.json`, requestData)
            .then(result => {
                if (Object.keys(result).length > 0) {
                    this.sendAction(DOWNLOADED_VALUES, { values: result });
                }
            });
    }

    async createTaskAction(options) {
        const { task, start, end, updateParents } = options;
        const result = this.processData(task, {});
        this.sendAction(NEW_VALUES, { task, values: result, start, end } );

        if (updateParents) {
            this.updateParentsAction2({
                task: task,
                mode: PARENT_MODE_ADD,
                newData: result,
                start: start,
                end: end,
                bubbleUp: true,
            });
        }
    }

    async updateTaskAction(options) {
        const { task, newData, oldData, start, end, updateParents, oldOwnerUid } = options;
        const data = newData ? newData.values : oldData.values;
        const result = this.processData(task, data);
        this.sendAction(NEW_VALUES, { task, values: result, start, end } );

        if (updateParents) {
            if (oldOwnerUid && !gantt.resourcesStore.store[oldOwnerUid]) {
                this.sendAction(CREATE_OTHER, { task: this.createTemporaryTask(oldOwnerUid) });
            }
            if (task.uparent && !gantt.resourcesStore.store[task.uparent]) {
                this.sendAction(CREATE_OTHER, { task: this.createTemporaryTask(task.uparent) });
            }
            const oldOwner = gantt.resourcesStore.store[oldOwnerUid];
            const newOwner = gantt.resourcesStore.store[task.uparent];
            // Change of parent user
            if (oldOwner && newOwner) {
                // New owner is a group, old owner is an user, the group is parent of the user
                if (oldOwner.task.uparent == newOwner.task.uid) {
                    this.updateParentsAction2({
                        parentTask: newOwner.task,
                        mode: PARENT_MODE_CHANGE,
                        newData: result,
                        oldData: oldData,
                        start: start,
                        end: end,
                        bubbleUp: false,
                    });
                    this.updateParentsAction2({
                        parentTask: oldOwner.task,
                        mode: PARENT_MODE_REMOVE,
                        newData: oldData,
                        //newData: result,
                        //oldData: oldData,
                        start: start,
                        end: end,
                        bubbleUp: false,
                    });
                // New owner is an user, old owner is a group, the group is parent of the user
                } else if (oldOwner.task.uid == newOwner.task.uparent) {
                    this.updateParentsAction2({
                        parentTask: newOwner.task,
                        mode: PARENT_MODE_ADD,
                        newData: result,
                        oldData: oldData,
                        start: start,
                        end: end,
                        bubbleUp: false,
                    });
                    this.updateParentsAction2({
                        parentTask: oldOwner.task,
                        mode: PARENT_MODE_CHANGE,
                        newData: result,
                        oldData: oldData,
                        start: start,
                        end: end,
                        bubbleUp: false,
                    });
                // New owner and old owner are not related
                } else {
                    this.updateParentsAction2({
                        parentTask: newOwner.task,
                        mode: PARENT_MODE_ADD,
                        newData: result,
                        //oldData: oldData,
                        start: start,
                        end: end,
                        bubbleUp: true,
                    });
                    this.updateParentsAction2({
                        parentTask: oldOwner.task,
                        mode: PARENT_MODE_REMOVE,
                        newData: oldData,
                        //newData: result,
                        //oldData: oldData,
                        start: start,
                        end: end,
                        bubbleUp: true,
                    });
                }

            // Parent user unchanged
            } else {
                this.updateParentsAction2({
                    task: task,
                    mode: PARENT_MODE_CHANGE,
                    newData: result,
                    oldData: oldData,
                    start: start,
                    end: end,
                    bubbleUp: true,
                });
            }
        }
    }

    async updateParentsAction2(options) {
        let { task, parentTask, newData, oldData, mode, start, end, bubbleUp } = options;

        const parents = [];

        if (parentTask) {
            parents.push(parentTask);
        } else {
            if ((task.utype === RXA.common.TYPE_TASK || task.utype === RXA.common.TYPE_PROJECT)
                && task.parent)
            {
                const projectId = RXA.common.getProjectId({ taskId: task.parent });
                const project = gantt.getTask(projectId);
                if (!gantt.resourcesStore.store[project.uid]) {
                    this.sendAction(CREATE_OTHER, { task: project });
                }
                parents.push(project);
            }
            
            if (task.uparent) {
                if (!gantt.resourcesStore.store[task.uparent]) {
                    this.sendAction(CREATE_OTHER, { task: this.createTemporaryTask(task.uparent) });
                }
                const user = gantt.resourcesStore.store[task.uparent].task;
                parents.push(user);
            }
        }

        if (parents.length <= 0) {
            return;
        }

        for (let parent of parents) {
            this.sendAction(NEW_VALUES_PARENT, {
                task: parent,
                mode: mode,
                newData: newData,
                oldData: oldData,
                start: start,
                end: end,
            });

            if (bubbleUp) {
                this.updateParentsAction2({ task: parent, newData, oldData, mode, start, end, bubbleUp });
            }
        }

    }

    createTemporaryTask(uid) {
        const task = {};
        task.uid = uid;
        task.start_date = gantt.config.start_date;
        task.end_date = gantt.config.end_date;

        if (uid.startsWith('i')) {
            task.type = 'task';
            task.utype = 'task';
        } else if (uid.startsWith('m')) {
            task.type = 'task';
            task.utype = 'milestone';
        } else if (uid.startsWith('u')) {
            const users = gantt.serverList('users');
            task.type = 'project';
            task.utype = 'group';
            for (let i = 0; i < users.lenght; i++) {
                if (users[i].uid == uid) {
                    task.utype = users[i].utype;
                }
            }
        } else {
            task.type = 'project';
            task.utype = 'project';
        }

        const uparentId = gantt.getDatastore('resource').getParent(RXA.common.cleanId(uid));
        task.uparent = uparentId > 0 ? `u${uparentId}` : uparentId;

        return task;
    }

    processData(task, data) {
        const calendar = gantt.getTaskCalendar(task);
        const remainingData = this.calculateRemainingHours(task, data);
        //let hoursDistributionTotal = 0;
        let result = { values: {}, hoursDistributionTotal: 0 };

        const type = distributionType(task);

        if (type === RXA.common.DISTRIBUTION_FROM_END) {
            result = this.loopDatesBackward(task, data, calendar, remainingData, result, type);
        } else {
            result = this.loopDatesForward(task, data, calendar, remainingData, result, type);
        }

        result.fixedTotal = remainingData.fixedTotal;
        //result.hoursDistributionTotal = hoursDistributionTotal;
        result.estimated = task.estimated_hours || 0.0;
        result.spentTotal = task.total_hours || 0.0;
        result.highEstimation = remainingData.highEstimation;
        result.lowEstimation = remainingData.lowEstimation;

        return result;
    }

    loopDatesForward(task, data, calendar, remainingData, result, type) {
        let currentDate = this.startDate(task);
        const endDate = this.endDate(task);

        let workDayCounter = 0;
        let remainder = 0;

        if (type === RXA.common.DISTRIBUTION_FROM_START) {
          remainder = remainingData.remainingEstimated;
        }

        do {
            const dateString = currentDate.toDateString();

            if (this.isPast(currentDate)) {
                result.values[dateString] = { hours: 0, type: TYPE_ENTRY };
            } else if (data[dateString] && data[dateString].type == TYPE_FIXED) {
                result.values[dateString] = data[dateString];
            } else if (!calendar.isWorkTime(currentDate)) {
                result.values[dateString] = { hours: 0, type: TYPE_DAYOFF };
            } else {
                let hoursValue = 0;
                if (remainingData.remainingEstimated != 0) {
                    const distributionValue = this.distributionValue(
                        currentDate, calendar, workDayCounter, remainder, remainingData, type
                    );
                    hoursValue = distributionValue.hoursValue;
                    remainder = distributionValue.remainder;
                }
                result.hoursDistributionTotal += hoursValue;
                result.values[dateString] = { hours: hoursValue, type: TYPE_DISTRIBUTION };
                workDayCounter++;
            }
            currentDate = gantt.date.add(currentDate, 1, 'day');
        } while (RXA.common.diffDates(currentDate, endDate) > 0)

        return result;
    }

    loopDatesBackward(task, data, calendar, remainingData, result, type) {
        let startDate = this.startDate(task);
        let currentDate = this.endDate(task);
        currentDate = gantt.date.add(currentDate, -1, 'day');

        let workDayCounter = 0;
        let remainder = remainingData.remainingEstimated;

        do {
            const dateString = currentDate.toDateString();

            if (this.isPast(currentDate)) {
                result.values[dateString] = { hours: 0, type: TYPE_ENTRY };
            } else if (data[dateString] && data[dateString].type == TYPE_FIXED) {
                result.values[dateString] = data[dateString];
            } else if (!calendar.isWorkTime(currentDate)) {
                result.values[dateString] = { hours: 0, type: TYPE_DAYOFF };
            } else {
                let hoursValue = 0;
                if (remainingData.remainingEstimated != 0) {
                    const distributionValue = this.distributionValue(
                        currentDate, calendar, workDayCounter, remainder, remainingData, type
                    );
                    hoursValue = distributionValue.hoursValue;
                    remainder = distributionValue.remainder;
                }
                result.hoursDistributionTotal += hoursValue;
                result.values[dateString] = { hours: hoursValue, type: TYPE_DISTRIBUTION };
                workDayCounter++;
            }
            currentDate = gantt.date.add(currentDate, -1, 'day');
        } while (RXA.common.diffDates(startDate, currentDate) >= 0)

        return result;
    }

    distributionValue(currentDate, calendar, day, remainder, remainingData, type) {
        if (type === RXA.common.DISTRIBUTION_FROM_START ||
            type === RXA.common.DISTRIBUTION_FROM_END)
        {
            return this.distributionFromStartOrEnd(currentDate, calendar, day, remainder, remainingData);
        } else {
            return this.distributionUniform(currentDate, calendar, day, remainder, remainingData, type);
        }
    }

    distributionFromStartOrEnd(currentDate, calendar, day, remainder, remainingData) {
        if (remainder <= 0) {
            return { hoursValue: 0, remainder: 0 };
        }

        const capacity = calendar.getHoursPerDay(currentDate);
        let hoursValue = (capacity > remainder ? remainder : capacity);
        remainder -= hoursValue

        if (this.lastDay(day, remainingData)) {
            hoursValue += remainder;
            remainder = 0;
        }

        return { hoursValue, remainder }
    }

    distributionUniform(currentDate, calendar, day, remainder, remainingData, type) {
        const hoursValue = calendar.getHoursPerDay(currentDate) / remainingData.workHours *
            remainingData.remainingEstimated;
        let hoursValueRounded = roundDistribution(hoursValue, type);

        if (type !== RXA.common.DISTRIBUTION_UNIFORM_DECIMAL) {
            remainder += hoursValue - hoursValueRounded;
        }

        if (this.lastDay(day, remainingData)) {
            hoursValueRounded = roundDistribution(hoursValue + remainder, type);
            remainder = 0;
        }
        return { hoursValue: hoursValueRounded, remainder }
    }

    lastDay(day, remainingData) {
        return day === remainingData.workDays - 1;
    }

    startDate(task) {
        if (task.ustart_date) {
            return new Date(task.ustart_date);
        } else {
            return task.start_date;
        }
    }

    endDate(task) {
        if (task.uend_date) {
            return new Date(task.uend_date);
        } else {
            return task.end_date;
        }
    }

    setTimeEntry(task, date, value) {
        const startDate = this.startDate(task);
        const data = {}
        const fromStart = RXA.common.diffDates(startDate, date);
        const fromToday = RXA.common.diffDates(date, new Date());
        if (fromStart >= 0 && fromToday > 0) {
            return date.toDateString();
        } else if (fromStart < 0) {
            return startDate.toDateString();
        } else {
            dayBeforeToday = gantt.date.add(new Date(), -1, 'day').toDateString();
            return dayBeforeToday;
        }
    }

    setFixedEntry(task, date, value) {
        const endDate = this.endDate(task);
        const data = {}
        const toEnd = RXA.common.diffDates(endDate, date);
        const fromToday = RXA.common.diffDates(new Date(), date);

        if (fromToday >= 0 && toEnd < 0) {
            data[date.toDateString()] = { hours: value, type: TYPE_FIXED }
        } else {
            //this.addFixedToSendingStack(date, 0, false, 'destroy');
        }
        return data;
    }

    processFixed(entriesObject, task) {
        let result = {};
        const entries = entriesObject.fixed_values;
        for (let i = 0; i < entries.length; i++) {
            const date = new Date(entries[i].date);
            result = Object.assign(result, this.setFixedEntry(task, date, entries[i].hours));
        }

        return result;
    }

    calculateRemainingHours(task, data) {
        const result = {};

        result.highEstimation = 0;
        result.lowEstimation = 0;
        result.value = 0;
        result.fixedTotal = 0;

        if (task.type !== RXA.common.TYPE_TASK) {
            return result;
        }

        // Past and Future or All Future
        const { workDays, workHours } = this.workDays(task, data);
        const sumFixed = this.sumFixedEntries(task, data);
        const hours = sumFixed + task.total_hours;
        result.remainingEstimated = task.estimated_hours - hours;

        const isPast = RXA.common.diffDates(task.end_date, new Date()) >= 0;

        if (workDays === 0 && result.remainingEstimated > 0) {
            if (!isPast) {
                result.highEstimation = 1;
            }
        } else if (result.remainingEstimated < 0) {
            result.highEstimation = 0;
            if (!isPast) {
                result.lowEstimation = 1;
            }
        }

        result.workDays = workDays;
        result.workHours = workHours;
        result.fixedTotal = sumFixed;
        return result;
    }

    workDays(task, data) {
        const endDate = this.endDate(task);
        let currentDate = new Date(new Date().toDateString());
        if (RXA.common.diffDates(currentDate, task.start_date) > 0) {
            currentDate = task.start_date;
        }

        const calendar = gantt.getTaskCalendar(task);
        let workDays = calendar.calculateDuration(currentDate, endDate);
        gantt.config.duration_unit = 'hour';
        let workHours = calendar.calculateDuration(currentDate, endDate);
        gantt.config.duration_unit = 'day';

        while(RXA.common.diffDates(endDate, currentDate) < 0) {
            if (calendar.isWorkTime(currentDate)) {
                if (data[currentDate.toDateString()] && data[currentDate.toDateString()].type === TYPE_FIXED)
                {
                    workDays--;
                    workHours -= calendar.getHoursPerDay(currentDate);
                }
            }

            currentDate = gantt.date.add(currentDate, 1, 'day');
        }
        return { workDays, workHours };
    }

    sumFixedEntries(task, data) {
        let fixedHours = 0;
        for (let date in data) {
            let currentDate = new Date(date);
            if (RXA.common.diffDates(currentDate, task.start_date) > 0 ||
                RXA.common.diffDates(task.end_date, currentDate) >= 0) 
            {
                if (data[date].type === TYPE_FIXED) {
                    this.addFixedToSendingStack(task, date, 0, true, 'destroy');
                }
                continue;
            }
            if (!this.isPast(currentDate) && data[date].type === TYPE_FIXED) {
                fixedHours += data[date].hours;
            }
        }
        return fixedHours;
    }

    /**
     * Adds one fixed value to the sending stack
     * @param {Date object} date - date of the fixed value
     * @param {Float} hours - float value of fixed hours (0..24)
     * @param {String} taskId - id of task, for which the fixed value belongs
     * @return {void}
     */
     addFixedToSendingStack(task, date, hours, count, mode) {
        const fixedValue = {
            hours,
            date: date,
            author_id: userId,
            issue_id: RXA.common.cleanId(task.id),
            count
        }

        if (mode) {
            fixedValue.mode = mode;
        }
        gantt.fixedSendingStack.push(fixedValue);
    }

    isPast(date) {
        return (RXA.common.diffDates(date, new Date()) > 0);
    }


    // async fetchEntries(url, data) {
    //     const urlWithKey = `${url}?key=${userApiToken}`;

    //     const parameters = {
    //         method: 'get',
    //         mode: 'cors',
    //         cache: 'no-cache',
    //         credentials: 'same-origin',
    //         headers: {
    //             'Content-Type': 'application/json',
    //         },
    //         redirect: 'follow',
    //         referrerPolicy: 'no-referrer',
    //     };

    //     if (data) {
    //         parameters.method = 'post';
    //         parameters.body = JSON.stringify(data);
    //     }

    //     const response = await fetch(urlWithKey, parameters);

    //     const responseText = await response.text();
    //     const result = responseText ? JSON.parse(responseText) : null;

    //     if (!response.ok) {
    //         let message;
    //         if (result && result.errors) {
    //             message = result.errors.join(', ');
    //         }
    //         throw new Error(`${response.status} ${message}`)
    //     }
    //     return result;
    // }
}