import { TaskElement }      from './task_element.js';
import { ResourceObject }   from './resource_object.js';
import { ResourceActions }  from './resource_actions.js'

export const CREATE_TASK                    = 'CREATE_TASK';
export const CREATE_OTHER                   = 'CREATE_OTHER';
export const CREATE_EXTERNAL_TASKS          = 'CREATE_EXTERNAL_TASKS';
export const UPDATE_TASK                    = 'UPDATE_TASK';
export const UPDATE_DIMENSIONS              = 'UPDATE_DIMENSIONS';
export const UPDATE_OTHER                   = 'UPDATE_OTHER';
export const UPDATE_PARENT                  = 'UPDATE_PARENT';
export const CHANGE_PARENT                  = 'CHANGE_PARENT';
export const UPDATE_USERS_CHILDREN_TASKS    = 'UPDATE_USERS_CHILDREN_TASKS'
export const NEW_VALUES                     = 'NEW_VALUES';
export const NEW_VALUES_PARENT              = 'NEW_VALUES_PARENT';
export const NEW_EXTERNAL_VALUES            = 'NEW_EXTERNAL_VALUES';
export const DOWNLOADED_VALUES              = 'DOWNLOADED_VALUES';
export const OPEN_EDIT_BOX                  = 'OPEN_EDIT_BOX';
export const FIXED_VALUE_SET                = 'FIXED_VALUE_SET';
export const FIXED_VALUE_UNSET              = 'FIXED_VALUE_UNSET';

export class ResourcesStore {
    initResourcesStore() {
        this.store = {};
        this.downloadedValues = {};
        this.actionProvider = new ResourceActions();
        this.startTime = performance.now();
        this.resourcesNotLoaded = true;

        this.loadResources();
    }

    loadResources() {
        gantt.attachEvent('onLoadEnd', () => {
            if (this.loadResources) {
                this.resourcesNotLoaded = false;
                this.actionProvider.fetchResourcesData();
            }
        });
    }

    processAction(action, data) {
        let dataObject, values;
        switch (action) {
            case CREATE_TASK:
            case CREATE_OTHER:
                return this.createTask(data);
            case UPDATE_TASK:
                return this.updateTask(data);
            case UPDATE_OTHER:
                return this.updateOther(data);
            case UPDATE_DIMENSIONS:
                return this.updateDimensions(data);

                // console.log({action, data});
                // this.end();
                // this.store[data.task.uid] = this.createNewTaskData(data.task);
                // dataObject = this.store[data.task.uid];
                // dataObject.resourceObject = new ResourceObject(data.task, {});
                // values = dataObject.resourceObject.getValuesForZoomLevel();
                // dataObject.elementObject = new TaskElement(data.task, values);
                //if (data.task.utype === 'user') {
                //this.actionProvider.createChildrenAction(data.task);
                //}
                // return dataObject.elementObject.el;
            case UPDATE_PARENT:
                this.actionProvider.updateParentsAction2({
                    task: data.task,
                    parentTask: data.parentTask,
                    mode: data.mode,
                    oldData: data.oldData,
                    start: data.start,
                    end: data.end,
                    bubbleUp: data.bubbleUp,
                });
                break;
            case CHANGE_PARENT:

            case UPDATE_USERS_CHILDREN_TASKS:
                const parentTask = data.taskParentId ? gantt.getTask(data.taskParentId) : null;
                const oldOwner = this.store[data.oldOwnerId];
                const newOwner = this.store[data.newOwnerId];

                if (oldOwner && oldOwner.task.uparent === newOwner.task.uid)
                {
                    this.actionProvider.updateParentsAction({
                        parentTask: oldOwner.task,
                        start: data.start,
                        end: data.end,
                        updateChildrenTasks: true,
                        bubbleUp: true,
                    });
                } else if (!oldOwner && parentTask) {
                    this.actionProvider.updateParentsAction({
                        parentTask,
                        start: data.start,
                        end: data.end,
                        updateChildrenTasks: true,
                        bubbleUp: true,
                    });
                } else if (!oldOwner || (oldOwner && newOwner.task.uparent === oldOwner.task.uid)) {
                    this.actionProvider.updateParentsAction({
                        parentTask: newOwner.task,
                        start: data.start,
                        end: data.end,
                        updateChildrenTasks: true,
                        bubbleUp: true,
                    });
                } else {
                    this.actionProvider.updateParentsAction({
                        parentTask: oldOwner.task,
                        start: data.start,
                        end: data.end,
                        updateChildrenTasks: true,
                        bubbleUp: true,
                    });
                    this.actionProvider.updateParentsAction({
                        parentTask: newOwner.task,
                        start: data.start,
                        end: data.end,
                        updateChildrenTasks: true,
                        bubbleUp: true,
                    });
                }
                break;
            // case CREATE_EXTERNAL_TASKS:
            //     const uids = []
            //     for (let i = 0; i < data.tasks.length; i++) {
            //         uids.push(data.tasks[i].uid);
            //         this.store[data.tasks[i].uid] = this.createNewTaskData(data.tasks[i]);
            //         dataObject = this.store[data.tasks[i].uid];
            //         dataObject.resourceObject = new ResourceObject(data.tasks[i], {});
            //     }
            //     this.actionProvider.createExternalTasksAction(uids);
            //     break;
            case NEW_VALUES:
                // console.log({action, data});
                // this.end();
                dataObject = this.store[data.task.uid];
                dataObject.resourceObject.updateTask(data.task, data.values);
                values = dataObject.resourceObject.getValuesForZoomLevel();
                dataObject.elementObject.update(data.task, values);
                break;
            case NEW_VALUES_PARENT:
                if (data.task.type === RXA.common.TYPE_MILESTONE) {
                    break;
                }
                if (!this.store[data.task.uid]) {
                    break;
                }
                dataObject = this.store[data.task.uid];
                dataObject.resourceObject.updateChildData(
                    data.mode, data.newData, data.oldData, data.start, data.end);
                values = dataObject.resourceObject.getValuesForZoomLevel();
                dataObject.elementObject.update(data.task, values);
                break;
            case DOWNLOADED_VALUES:
                this.downloadedValues = data.values;
                for (const uid in data.values) {
                    if (this.store[uid]) {
                        dataObject = this.store[uid];
                        //task = gantt.getTask(uid);
                        if (gantt.$data.tasksStore.visibleOrder.includes(dataObject.task.id)) {
                            if (uid.startsWith('i')) {
                                const newData = {
                                    task: dataObject.task,
                                    values: data.values[uid],
                                    updateParents: false
                                }
                                this.updateTask(newData);
                            } else {
                                const newData = {
                                    task: dataObject.task,
                                    values: data.values[uid],
                                }
                                this.updateOther(newData);
                            }
                        } else {
                            dataObject.resourceObject.updateTask(dataObject.task, data.values[uid]);
                        }
                    } 
                }
                break;
            // case NEW_EXTERNAL_VALUES:
            //     start = new Date(2040, 0, 1);
            //     end = new Date(2000, 0, 1);
            //     for (const uid in data.values) {
            //         dataObject = this.store[uid];
            //         task = gantt.getTask(uid);
            //         if (new Date(task.ustart_date).getTime() < start.getTime()) {
            //             start = new Date(task.ustart_date);
            //         }
            //         if (new Date(task.uend_date).getTime() > end.getTime()) {
            //             end = new Date(task.uend_date);
            //         }
            //         dataObject.resourceObject.updateTask(task, data.values[uid]);
            //     }
            //     end = gantt.date.add(end, -1, 'day');
            //     this.actionProvider.updateParentsAction({
            //         task,
            //         start,
            //         end,
            //         updateChildrenTasks: false,
            //         bubbleUp: true
            //     });
            //     break;
            case OPEN_EDIT_BOX:
                this.openEditBox(data);
                break;
            case FIXED_VALUE_SET:
                this.fixedChangeValue(data, true);
                break;
            case FIXED_VALUE_UNSET:
                this.fixedChangeValue(data, false);
                break;
        }
    }

    get sendAction() {
        return this.processAction.bind(this);
    }

    getEl(task) {
        if (this.store[task.uid] && this.isChanged(task)) {
            if (task.utype === RXA.common.TYPE_TASK) {
                console.log('UPDATE TASK', task.uid, (new Date().getTime() - gantt.mTime.getTime()) / 1000);
                return this.processAction(UPDATE_TASK, { task });
            } else {
                console.log('UPDATE OTHER', task.uid, (new Date().getTime() - gantt.mTime.getTime()) / 1000);
                return this.processAction(UPDATE_OTHER, { task });
            }
        } else if (this.store[task.uid]) {
            console.log('UPDATE DIMENSIONS', task.uid, (new Date().getTime() - gantt.mTime.getTime()) / 1000);
            return this.processAction(UPDATE_DIMENSIONS, { task });
        } else {
            if (task.utype === RXA.common.TYPE_TASK) {
                console.log('CREATE TASK', task.uid, (new Date().getTime() - gantt.mTime.getTime()) / 1000);
                return this.processAction(CREATE_TASK, { task });
            } else if (task.utype === RXA.common.TYPE_MILESTONE) {
                return;
            } else {
                console.log('CREATE OTHER', task.uid, (new Date().getTime() - gantt.mTime.getTime()) / 1000);
                return this.processAction(CREATE_OTHER, { task });
            }
        }
    }

    createNewTaskData(task) {
        const start_date = new Date(task.start_date.getTime());
        const end_date = new Date(task.end_date.getTime());
        const estimated_hours = task.estimated_hours;
        const width = task.id ? gantt.getTaskPosition(task).width : 0;
        const owner = task.owner_id;
        const distribution = task.distribution;

        const level = gantt.ext.zoom.getCurrentLevel();
        const zoom = gantt.ext.zoom.getLevels()[level].name;

        return ({
            task: task,
            type: task.utype,
            external: task.external === undefined ? false : task.external,
            firstVisible: false,
            basicData: { start_date, end_date, estimated_hours, width, currentZoom: zoom, owner, distribution },
            workdaysOnly: gantt.config.skip_off_time,
            groupCounter: gantt.$groupCounter ? gantt.$groupCounter : 1,
        });
    }

    updateTaskData(task) {
        const start_date = new Date(task.start_date.getTime());
        const end_date = new Date(task.end_date.getTime());
        let changeStart = start_date;
        let changeEnd = end_date;

        const estimated_hours = task.estimated_hours;
        const owner = task.owner_id;
        const distribution = task.distribution;

        const level = gantt.ext.zoom.getCurrentLevel();
        const zoom = gantt.ext.zoom.getLevels()[level].name;

        const dataObject = this.store[task.uid];

        if (RXA.common.diffDates(dataObject.basicData.start_date, changeStart) > 0) {
            changeStart = new Date(dataObject.basicData.start_date.getTime());
        }

        if (RXA.common.diffDates(changeEnd, dataObject.basicData.end_date) > 0) {
            changeEnd = new Date(dataObject.basicData.end_date.getTime());
        }

        dataObject.task = task;
        dataObject.type = task.utype;
        dataObject.groupCounter = gantt.$groupCounter ? gantt.$groupCounter : 1;
        dataObject.basicData = { start_date, end_date, estimated_hours, currentZoom: zoom, owner, distribution };
        return { start: changeStart, end: changeEnd };
    }

    isChanged(task) {
        const level = gantt.ext.zoom.getCurrentLevel();
        const zoom = gantt.ext.zoom.getLevels()[level].name;
        const basicData = this.store[task.uid].basicData;

        if (gantt.$groupCounter > this.store[task.uid].groupCounter &&
            task.type !== RXA.common.TYPE_TASK)
        {
            this.store[task.uid].groupCounter = gantt.$groupCounter;
            console.log(task.uid, 'changed - groupMode');
            return true;
        }

        if (gantt.config.skip_off_time !== this.store[task.uid].workdaysOnly) {
            this.store[task.uid].workdaysOnly = gantt.config.skip_off_time;
            console.log(task.uid, 'changed - workdays');
            return true;
        }

        if (task.start_date.getTime() !== basicData.start_date.getTime() ||
            task.end_date.getTime() !== basicData.end_date.getTime()) 
        {
            console.log(task.uid, 'changed - start date or end date');
            return true;
        }

        if (task.owner_id != basicData.owner) {
            console.log(task.uid, 'changed - owner changed');
            return true;
        }

        if (task.distribution !== basicData.distribution) {
            console.log(task.uid, 'changed - distribution changed');
            return true;
        }

        if (task.type === RXA.common.TYPE_TASK && task.estimated_hours !== basicData.estimated_hours) {
            console.log(task.uid, 'changed - estimated hours');
            return true;
        }

        if (zoom !== basicData.currentZoom) {
            console.log(task.uid, 'changed - current zoom');
            return true;
        }

        if (gantt.$data.tasksStore.visibleOrder.includes(task.id) && !this.store[task.uid].firstVisible) {
            this.store[task.uid].firstVisible = true;
            return true;
        }

        const elementObject = this.store[task.uid].elementObject;
        const taskSizes = gantt.getTaskPosition(task);

        if (elementObject && elementObject.sizes.width !==  taskSizes.width) {
            console.log(task.uid, `changed - width of the task - old: ${basicData.width} new:${gantt.getTaskPosition(task).width}`);
            return true;
        }

        return false;
    }

    // calculateEstimatedHours(task) {
    //     const children = gantt.getChildren(task.id);
    //     if (task.type === RXA.common.TYPE_TASK && task.estimated_hours) {
    //         return task.estimated_hours;
    //     } else if (children.length > 0) {
    //         let hours = 0;
    //         for (let i = 0; i < children.length; i++) {
    //             const childTask = gantt.getTask(children[i]);
    //             if (childTask.external) {
    //                 continue;
    //             }
    //             hours += parseInt(this.calculateEstimatedHours(childTask), 10);
    //         }
    //         return hours;
    //     } else {
    //         return 0;
    //     }
    // }

    // *************
    // ** ACTIONS **
    // *************

    /**
     * Create new task in resources store
     * @param {Object} data - data object of the action
     * @return {Object} - task resource element
     */
    createTask(data) {
        console.log('new task uid', data.task.uid);
        this.store[data.task.uid] = this.createNewTaskData(data.task);

        const  dataObject = this.store[data.task.uid];
        if (this.downloadedValues[data.task.uid]) {
            dataObject.resourceObject = new ResourceObject(data.task, this.downloadedValues[data.task.uid]);
        } else {
            dataObject.resourceObject = new ResourceObject(data.task, {});
        }

        const values = dataObject.resourceObject.getValuesForZoomLevel();
        dataObject.elementObject = new TaskElement(data.task, values);

        // task created on the resources chart
        if (typeof(data.task.uid) === 'number' && data.task.type === RXA.common.TYPE_TASK) {
            this.actionProvider.createTaskAction({
                task: data.task,
                start: data.task.start_date,
                end: gantt.date.add(data.task.end_date, -1, 'day'),
                updateParents: true,
            });
        }
        return dataObject.elementObject.el;
    }

    /**
     * Update task in resources store (recalculate values, regenerate elements)
     * @param {Object} data - data object of the action
     * @return {Object} - task resource element
     */
    updateTask(data) {
        const dataObject = this.store[data.task.uid];
        let oldOwnerUid;
        if (data.task.owner_id != dataObject.basicData.owner) {
            oldOwnerUid = `u${dataObject.basicData.owner}`;
        }

        const { start, end } = this.updateTaskData(data.task);
        const options = {
            task: data.task,
            oldData: data.values || dataObject.resourceObject.resourceData,
            start: start,
            end: gantt.date.add(end, -1, 'day'),
            updateParents: true,
            oldOwnerUid: oldOwnerUid,
        }

        this.actionProvider.updateTaskAction(options);

        return dataObject.elementObject.el;
    }

    /**
     * Create new user or project in resources store
     * @param {Object} data - data object of the action
     * @return {Object} - task resource element
     */
     createOther(data) {
        this.store[data.task.uid] = this.createNewTaskData(data.task);

        const  dataObject = this.store[data.task.uid];
        if (this.downloadedValues[data.task.uid]) {
            dataObject.resourceObject = new ResourceObject(data.task, this.downloadedValues[data.task.uid]);
        } else {
            dataObject.resourceObject = new ResourceObject(data.task, {});
        }

        const values = dataObject.resourceObject.getValuesForZoomLevel();
        dataObject.elementObject = new TaskElement(data.task, values);
     }

    /**
     * Update parent (project, user) in resources store (recalculate values, regenerate elements)
     * @param {Object} data - data object of the action
     * @return {Object} - parent resource element
     */
    updateOther(data) {
        const dataObject = this.store[data.task.uid];
        this.updateTaskData(data.task);
        dataObject.resourceObject.updateTask(data.task, data.values);
        const values = dataObject.resourceObject.getValuesForZoomLevel();
        dataObject.elementObject.update(data.task, values);
        return dataObject.elementObject.el;
    }

    /**
     * Update dimensions of the task or parent 
     * @param {Object} data - data object of the action
     * @return {Object} - task resource element
     */
    updateDimensions(data) {
        const dataObject = this.store[data.task.uid];
        dataObject.elementObject.updateDimensions(data.task);
        return dataObject.elementObject.el;
    }

    /**
     * Opens edit box to enter fixed value
     * @param {Object} data - data object of the action
     * @return {void} - nothing is returned
     */
    openEditBox(data) {
        const dataObject = this.store[data.task.uid];
        dataObject.elementObject.editBoxElement.showEditBox(data.event, data.rect, data.index);
    }

    /**
     * Sets or unsets fixed value
     * @param {Object} data - data object of the action
     * @return {void} - nothing is returned
     */
    fixedChangeValue(data, setValue) {
        const dataObject = this.store[data.task.uid];

        const oldData = RXA.common.deepCopy(dataObject.resourceObject.resourceData);

        if (setValue) {
            dataObject.resourceObject.setValue(data.startDate, data.endDate, data.value);
        } else {
            dataObject.resourceObject.unsetValue(data.startDate, data.endDate);
        }

        let start = new Date(new Date().toDateString());
        if (RXA.common.diffDates(start, data.task.start_date) > 0) {
            start = data.task.start_date;
        }

        const options = {
            task: data.task,
            newData: dataObject.resourceObject.resourceData,
            oldData: oldData,
            start: start,
            end: gantt.date.add(data.task.end_date, -1, 'day'),
            updateParents: true
        }
        this.actionProvider.updateTaskAction(options);
    }
}