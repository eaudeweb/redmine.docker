#RedmineX Resources Plugin
# Foreword
============
Thank you for purchasing the RedmineX Resources plugin. Below, you will find useful information about the plugin. 


# Contents
============
1. Installation
2. Update
    
## 1. Installation of the Resources Plugin
============

Follow the standard Redmine plugin installation procedure: <br/>
	<ol type='a'>
		<li>Unzip the archive and copy it to `redmine_root/plugins` or copy the archive in the same location and perform the unzip command in cour console.</li>
		<li>from `redmine_root ` run `bundle install`</li>
		<li>from `redmine_root ` run `bundle exec rake redmine:plugins:migrate RAILS_ENV=production ` (migration command)</li>
		<li>after migration, it is necessary to upload public holidays into the db by running `bundle exec rake redmine:redmine_x_assets:initialize_holidays RAILS_ENV=production ` from the `redmine_root `</li>
		<li>restart Redmine</li>
	</ol>

## 2. Updating The Resources Plugin
============

These are the steps needed to update the Resources plugin: <br/>
	<ol type='a'>
		<li>Go to `redmine_root/plugins ` and delete the `redmine_x_resources ` folder</li>
		<li>Go to `redmine_root/public/plugin_assets ` and delete the `redmine_x_resources ` folder</li>
		<li>Restart Redmine</li>
		<li>Copy the new Resources version into the `redmine_root/plugins ` folder</li>
		<li>from `redmine_root ` run `bundle install`</li>
		<li>from `redmine_root ` run `bundle exec rake redmine:plugins:migrate RAILS_ENV=production `</li>
		<li>Restart Redmine</li>
	</ol>

Enjoy!
RedmineX Team
<br/>
[www.redmine-x.com](https://www.redmine-x.com)