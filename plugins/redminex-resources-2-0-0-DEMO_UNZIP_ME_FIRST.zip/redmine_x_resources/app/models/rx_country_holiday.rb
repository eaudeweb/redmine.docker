class RxCountryHoliday < ActiveRecord::Base
  @@states = {}
  @@holidays = {}

  def self.countries
    rx_country_holidays = RxCountryHoliday.arel_table

    @@countries ||=
      RxCountryHoliday
      .group(:country_iso, :country)
      .pluck(:country_iso, :country, 'COUNT(state)')
      .map { |c| { key: c[0], value: c[1], states: c[2] > 0 }}
  end

  def self.states(country_iso)
    @@states[country_iso] ||=
      RxCountryHoliday
      .where(country_iso: country_iso)
      .where('state IS NOT NULL')
      .group(:state_iso, :state)
      .pluck(:state_iso, :state)
      .map { |c| { key: c[0], value: c[1] }}
  end

  def self.holidays(country_iso, state_iso=nil)
    if state_iso
      @@holidays["#{country_iso}_#{state_iso}"] ||=
        RxCountryHoliday
        .where(country_iso: country_iso)
        .where('holiday_type = "national" OR state_iso = ?', state_iso)
        .group(:date)
        .pluck(:date)
    else
      @@holidays[country_iso] ||=
        RxCountryHoliday
        .where(country_iso: country_iso, holiday_type: 'national')
        .pluck(:date)
    end
  end
end