class RxFixedValue < ActiveRecord::Base
    belongs_to :issue, class_name: 'Issue', foreign_key: 'issue_id'
    belongs_to :author, class_name: 'User', foreign_key: 'author_id'

    validates :date, uniqueness: { scope: :issue }
    validates :hours, numericality: { greater_than_or_equal_to: 0, less_than_or_equal_to: 24 }

    def self.remove_value(attrs)
        records = RxFixedValue.where(issue: attrs[:issue_id], date: attrs[:date])
        if records.count > 0 && attrs[:mode] == 'destroy'
            records[0].destroy
        end
    end

    def self.create_or_update_value(attrs)
        author = User.find(attrs[:author_id])
        issue = Issue.find(attrs[:issue_id])
        records = RxFixedValue.where(issue: issue, date: attrs[:date])

        if records.count > 0
            records[0].update(
                hours: attrs[:hours], date: attrs[:date], author: author, issue: issue
            )
        else
            RxFixedValue.create!(
                hours: attrs[:hours], date: attrs[:date], author: author, issue: issue
            )
        end
    end
end
