class RedmineXResourcesController < ApplicationController
  DATE_FORMATS_GANTT = [
    ['%b', '%M'], ['%B', '%F']
  ]

  DATE_FORMATS_JQUERY = [
    ['%d', 'dd'], ['%b', 'M'], ['%B', 'MM'], ['%Y', 'yy'], ['%m', 'mm'], ['%', '']
  ]

  menu_item :redmine_x_resources

  before_action :find_project, only: [:show]

  before_action :authorize, if: proc { @project.present? }
  before_action :authorize_global, if: proc { @project.nil? }

  include RedmineXAssets::Helpers::CalendarsHelper
  include RedmineXResources::Helpers::DataHelper
  include RedmineXResources::Helpers::DistributionsHelper
  include RedmineXAssets::Helpers::PrioritiesHelper
  include RedmineXAssets::Helpers::TranslationsHelper

  # Shows Resources with all projects (Resources activated from the top menu)
  def index
    unselected_users = Setting.plugin_redmine_x_resources[:users_unselected_on_global_resources]
    unselected_users = [-100] if unselected_users.nil? || unselected_users.empty?

    user_options = { users_excluded: unselected_users, include_closed_issues: show_closed_issues?(true) }
    users = RedmineXResources::Helpers::UsersHelper.user_items(nil, user_options)

    unselected_projects = Setting.plugin_redmine_x_resources[:projects_unselected_on_global_resources]
    unselected_projects = [-100] if unselected_projects.nil? || unselected_projects.empty?
    if Redmine::Plugin.installed?(:redmine_x_project_templates)
      projects = Project.active.visible.where('id NOT IN (?)', unselected_projects).where(rx_project_template: false)
    else
      projects = Project.active.visible.where('id NOT IN (?)', unselected_projects)
    end

    @local_resources = false;
    define_actions_commons(users)

    users.pop
    @users_select = RedmineXResources::Helpers::UsersHelper.hierarchize_items(users)
    @projects_select = RedmineXResources::Helpers::DataHelper.project_items_select(projects)

    render 'resources_view'
  end

  # Shows Resources with only one project (Resources activated from the project menu of current project)
  def show
    condition = @project.project_condition(true)
    if Redmine::Plugin.installed?(:redmine_x_project_templates)
      projects = Project.where(condition).where(rx_project_template: false).active.visible
    else
      projects = Project.where(condition).active.visible
    end

    user_options = { users_excluded: [], include_closed_issues: show_closed_issues?(false) }
    users = RedmineXResources::Helpers::UsersHelper.user_items(projects.pluck(:id), user_options)

    @local_resources = true;
    @holiday_project = holiday_project
    define_actions_commons(users)

    users.pop
    @users_select = RedmineXResources::Helpers::UsersHelper.hierarchize_items(users)

    render 'resources_view'
  end

  private

  # Defines instance variables used by views common for index and show actions
  # @param users [Array] - of hashes with users info (which will be used when resources is loaded)
  # @return [nil] - nothing is returned
  def define_actions_commons(users)
    @calendars = calendars(users).to_json.html_safe
    @current_user = User.current
    @date_format = date_format
    @datepicker_locale = datepicker_locale
    @distributions = distribution_items.to_json.html_safe
    @hours_per_day = Setting.plugin_redmine_x_resources[:hours_per_resource_per_day]
    @non_working_days = "[#{Setting.non_working_week_days.map{ |d| d == '7' ? '0' : d }.join(', ')}]"
    @parent_issue_settings = parent_issue_settings
    @paths_to_actions = paths_to_actions
    @permissions = user_permissions
    @priorities = priority_items.to_json.html_safe
    @priorities_for_filters = priorities
    @rest_api_enabled = Setting.rest_api_enabled?
    @scope = { scope: :redmine_x_resources }
    @translations = export_translations(
      [
        File.join(Rails.root, 'plugins', 'redmine_x_assets', 'config', 'locales', '*'),
        File.join(Rails.root, 'plugins', 'redmine_x_resources', 'config', 'locales', '*')
      ],
      [:redmine_x_assets, :redmine_x_resources]
    )
    @users = users.to_json.html_safe
  end

  # Returns rails path to different action in redmine, using the rails path helper
  # We do not want to use hardcoded paths in the gantt
  # @return [String] json string of paths
  def paths_to_actions
    {
      plugin: redmine_x_resources_path,
      projects: projects_path,
      issues: issues_path,
      milestones: "#{Redmine::Utils::relative_url_root}/versions",
      relations: "#{Redmine::Utils::relative_url_root}/relations",
      settings: settings_path,
      users: users_path,
      groups: groups_path
    }.to_json.html_safe
  end

  # Date format from settings in Redmine
  # @return [String] date format string in js format
  def date_format
    date_format_setting = Setting.where(name: 'date_format').first
    if date_format_setting && date_format_setting.value.length > 0
       date_format = date_format_setting.value
    else
      date_format = l(:default, { scope: [:date, :formats] })
    end

    date_format_gantt = date_format_jquery = date_format
    DATE_FORMATS_GANTT.each do |format_str|
      date_format_gantt = date_format_gantt.gsub(format_str[0], format_str[1])
    end
    DATE_FORMATS_JQUERY.each do |format_str|
      date_format_jquery = date_format_jquery.gsub(format_str[0], format_str[1])
    end

    { gantt: date_format_gantt, jQuery: date_format_jquery }.to_json.html_safe
  end

  # Returns redmine settings of parent issues (whether these are calculated independently or derived)
  # @return [String] json string of settings
  def parent_issue_settings
    {
      dates_derived: Setting['parent_issue_dates'] == 'derived',
      priority_derived: Setting['parent_issue_priority'] == 'derived',
      done_ratio_derived: Setting['parent_issue_done_ratio'] == 'derived'
    }.to_json.html_safe
  end

  # Returns priority levels defined in the settings of redmine
  # @return [Array] of priority levels
  def priorities
    Enumeration.select(:id, :name, :position_name, :is_default)
               .where(type: 'IssuePriority')
               .order(:position)
  end

  # Finds current project and set it as an instance variable
  def find_project
    @project = Project.find(params[:id])
  end

  # Collects user permissions on the project(s)
  # @return [Hash] json of user permissions
  def user_permissions
    projects = []
    if @project
      condition = @project.project_condition(true)
      projects = Project.where(condition)
    else
      condition = Project.visible_condition(User.current)
      projects = Project.where(condition)
    end
    create_permissions_hash(projects).to_json.html_safe
  end

  # Compose permissions hash
  # @param projects [Array] of ActiveRecord Project objects
  # @return [Hash] permissions
  def create_permissions_hash(projects)
    permissions = {}

    if User.current.admin
      permissions = admin_projects_permissions(projects)
    else
      permissions = user_projects_permissions(projects)
    end
    permissions.merge!(global_premissions(permissions))
    permissions.merge!(general_permissions)
  end

  # Checks if user is allowed to add something (issue or version) - because visibility of add button
  # @param permissions_hash [Hash] of all user user_projects_permissions
  # @return [Hash] add permission
  def global_premissions(permissions_hash)
    permissions_hash.each do |_key, value|
      if value[:add_issues] || value[:manage_versions]
        return { add: true }
      end
    end
    { add: false }
  end

  # Gets all user permissions for each project
  # @param projects [Array] of ActiveRecord Project objects
  # @return [Array] of Hashes or permissions
  def user_projects_permissions(projects)
    permissions = {}
    projects.each do |project|
      permissions[project.id] = collect_project_permissions(User.current, project)
    end
    permissions
  end

  # Returns permissions all set to true - used in case user is admin
  # @param projects [Array] of ActiveRecord Project objects
  # @return [Array] of Hashes or permissions
  def admin_projects_permissions(projects)
    permissions = {}
    projects.each do |project|
      permissions[project.id] = {
        add_issues: true, edit_issues: true, edit_own_issues: true, manage_issue_relations: true,
        manage_subtasks: true, delete_issues: true, manage_versions: true,
        members: project.memberships.pluck(:user_id),
        trackers: project.trackers.pluck(:id)
      }
    end
    permissions
  end

  # Gets the specific permissions for specific user and project from redmine
  # @param user [Object] ActiveRecord User object
  # @param projects [Object] ActiveRecord Project object
  # @return [Hash] of permissions
  def collect_project_permissions(user, project)
    {
      add_issues: user.allowed_to?(:add_issues, project),
      edit_issues: user.allowed_to?(:edit_issues, project),
      edit_own_issues: user.allowed_to?(:edit_own_issues, project),
      manage_issue_relations: user.allowed_to?(:manage_issue_relations, project),
      manage_subtasks: user.allowed_to?(:manage_subtasks, project),
      delete_issues: user.allowed_to?(:delete_issues, project),
      manage_versions: user.allowed_to?(:manage_versions, project),
      members: project.memberships.pluck(:user_id),
      trackers: project.trackers.pluck(:id)
    }
  end

  # Returns whether closed issues should be displayed or not
  # @param global [Boolean] - true if global resources are requested
  # @return [Boolean] - true if closed task should be displayed
  def show_closed_issues?(global)
    if global
      return true if Setting.plugin_redmine_x_resources[:closed_tasks_on_global_resources]
    else
      return true if Setting.plugin_redmine_x_resources[:closed_tasks_on_local_resources]
    end
    false
  end

  def general_permissions
    { cross_project_links: Setting.cross_project_issue_relations == "1" }
  end

  # Returns true if the project is a holiday project (project which contains holiday issues)
  # @return [Boolean] - true @project is a holiday project
  def holiday_project
    return false unless @project
    tracker = nil
    settings = Setting.plugin_redmine_x_assets
    if settings['holiday_tracker'] && settings['holiday_tracker'].to_i > 0
      tracker = settings['holiday_tracker'].to_i
    end

    return false unless tracker

    if @project.issues.where(tracker_id: tracker).count > 0
      true
    else
      false
    end
  end

  def measure_time(msg, t)
    time = Time.now - t
    Rails.logger.info("#{msg}, #{time}")
    t = Time.now
  end
end
