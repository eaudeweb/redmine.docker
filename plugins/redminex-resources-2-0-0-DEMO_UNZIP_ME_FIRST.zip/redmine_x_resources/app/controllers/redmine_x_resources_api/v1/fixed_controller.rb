class RedmineXResourcesApi::V1::FixedController < ApplicationController
  accept_api_auth :index, :create

  def index
    issue = Issue.find(index_fixed_params[:issue_id])
    date = index_fixed_params[:date]
    if date
      fixed_values = RxFixedValue.where(issue: issue, date: date)
    else
      fixed_values = RxFixedValue.where(issue: issue)
    end
    render json: { fixed_values: fixed_values }
  rescue => error
    render json: { error: error.message }
  end

  def create
    create_fixed_params[:fixed_values].each do |fixed|
      if fixed[:mode] == 'destroy'
        RxFixedValue.remove_value(fixed)
      else
        RxFixedValue.create_or_update_value(fixed)
      end
    end
  rescue => error
    render json: { error: error.message }
  end

  private

  def create_fixed_params
    params.permit(fixed_values: [:mode, :hours, :date, :author_id, :issue_id])
  end

  def index_fixed_params
    params.permit(:key, :issue_id, :date, :limit)
  end
end