class RedmineXResourcesApi::V1::DataController < ApplicationController
  accept_api_auth :index, :show, :project
  before_action :find_project, only: [:show, :project]

  include RedmineXResources::Helpers::DataHelper
  include RedmineXAssets::Helpers::PrioritiesHelper

  # Resources data global - for all projects
  def index
    holiday_projects = holiday_project_ids
    unselected_projects = Setting.plugin_redmine_x_resources[:projects_unselected_on_global_resources]
    unselected_projects = [-100] if unselected_projects.nil? || unselected_projects.empty?
    if Redmine::Plugin.installed?(:redmine_x_project_templates)
      projects = Project.active.visible.where('id NOT IN (?)', unselected_projects + holiday_projects).where(rx_project_template: false)
    else
      projects = Project.active.visible.where('id NOT IN (?)', unselected_projects + holiday_projects)
    end

    unselected_users = Setting.plugin_redmine_x_resources[:users_unselected_on_global_resources]
    unselected_users = [-100] if unselected_users.nil? || unselected_users.empty?
    user_options = { users_excluded: unselected_users, include_closed_issues: show_closed_issues?(true) }
    users = RedmineXResources::Helpers::UsersHelper.user_items(nil, user_options)
    user_list = users.map { |v| v[:id] }

    items = projects_items(projects,
                           { show_closed_issues: show_closed_issues?(true) },
                           user_list)
    items[:collections] = {
      projects: RedmineXResources::Helpers::DataHelper.project_items_select(projects),
      projects_and_users: [{ projects: projects.pluck(:id) }, { users: user_list }]
    }
    render json: items
  end

  # Resources data for one project only
  def show
    condition = @project.project_condition(true)
    if Redmine::Plugin.installed?(:redmine_x_project_templates)
      projects = Project.where(condition).where(rx_project_template: false).active.visible
    else
      projects = Project.where(condition).active.visible
    end

    user_options = { users_excluded: [], include_closed_issues: show_closed_issues?(false) }
    users = RedmineXResources::Helpers::UsersHelper.user_items(projects.pluck(:id), user_options)
    user_list = users.map { |v| v[:id] }

    items = projects_items(projects, { show_closed_issues: show_closed_issues?(false) }, user_list)
    items[:collections] = {
      projects: RedmineXResources::Helpers::DataHelper.project_items_select(projects),
      projects_and_users: [{ projects: projects.pluck(:id) }, { users: user_list }]
    }
    render json: items
  end

  def project
    if shift_project_params[:shift_project_start]
      shift_value = Date.parse(shift_project_params[:shift_project_start]) - @project.start_date
      shift_project(@project, shift_value) if shift_value != 0
    end

    if shift_project_params[:distribution]
      @project.rx_resources_distribution = shift_project_params[:distribution]
      @project.save
    end

    render json: {
      project: {
        id: @project.id,
        shift_project_value: shift_value,
        distribution: @project.rx_resources_distribution
      }
    }
  end

  private

  # Returns whether closed issues should be displayed or not
  # @param global [Boolean] - true if global resources are requested
  # @return [Boolean] - true if closed task should be displayed
  def show_closed_issues?(global)
    if global
      return true if Setting.plugin_redmine_x_resources[:closed_tasks_on_global_resources]
    else
      return true if Setting.plugin_redmine_x_resources[:closed_tasks_on_local_resources]
    end
    false
  end

  # Permitted parameters
  def shift_project_params
    params.require(:project).permit(:shift_project_start, :distribution)
  end

  # Find project from params and set it to the @project variable
  # @return [nil] - nothing is returned
  def find_project
    if params[:id]
      @project = Project.find(params[:id])
    end
  end

  # Returns ids of the projects with holiday issues
  # @return [Array] - array of project ids
  def holiday_project_ids
    holiday_projects = []
    tracker = nil
    settings = Setting.plugin_redmine_x_assets
    if settings['holiday_tracker'] && settings['holiday_tracker'].to_i > 0
      tracker = settings['holiday_tracker'].to_i
    end

    if tracker
      holiday_projects =
        Project
        .active
        .visible
        .joins('INNER JOIN issues ON projects.id = issues.project_id')
        .where('issues.tracker_id = ?', tracker)
        .distinct
        .pluck(:id)
    end

    holiday_projects
  end
end
