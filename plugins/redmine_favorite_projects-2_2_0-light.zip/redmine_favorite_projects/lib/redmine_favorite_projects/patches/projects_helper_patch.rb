module RedmineFavoriteProjects
  module Patches
    module ProjectsHelperPatch
      include ::RedmineFavoriteProjects::Helpers::FavoriteProjectsHelper
    end
  end
end

ProjectsHelper.include(RedmineFavoriteProjects::Patches::ProjectsHelperPatch)