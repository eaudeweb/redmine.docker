require_dependency 'projects_controller'

module RedmineFavoriteProjects
  module Patches
    module ProjectsControllerPatch
      def index
        if api_request?
          super
        else
          p = request.parameters
          p.except!(:controller, :action)
          redirect_to(search_favorite_projects_path(p)) and return
        end
      end
    end
  end
end

ProjectsController.prepend(RedmineFavoriteProjects::Patches::ProjectsControllerPatch)
