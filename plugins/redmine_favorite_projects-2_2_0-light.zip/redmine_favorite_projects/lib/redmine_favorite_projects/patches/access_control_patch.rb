require_dependency 'project'

module RedmineFavoriteProjects
  module Patches
    module AccessControlPatch
      def available_project_modules
        return @fp_available_project_modules if @fp_available_project_modules

        @fp_available_project_modules = super - [:favorite_projects]
      end
    end
  end
end

Redmine::AccessControl.singleton_class.prepend(RedmineFavoriteProjects::Patches::AccessControlPatch)
