IMPORTANT
=========

This zip contains two versions of Redmine plugins. 
One compatible with Redmine 3.x
Other compatible with Redmine 4.x

!Do not install this package as a whole!
Use only the plugin folder(s) within the respective archive. 