# This file is a part of Redmine Tags (redmine_tags) plugin,
# customer relationship management plugin for Redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_tags is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_tags is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_tags.  If not, see <http://www.gnu.org/licenses/>.

module RedmineupTags
  module Patches
    module AgileQueryPatch
      def self.prepended(base)
        base.class_eval do
          add_available_column QueryTagsColumn.new(:tags_relations, caption: :tags)
        end
      end

      def sql_for_issue_tags_field(_field, operator, value)
        case operator
        when '=', '!'
          issues = Issue.tagged_with(value.clone)
        when '!*'
          issues = Issue.joins(:tags).uniq
        else
          issues = Issue.tagged_with(Redmineup::Tag.all.map(&:to_s), any: true)
        end

        compare   = operator.include?('!') ? 'NOT IN' : 'IN'
        ids_list  = issues.collect(&:id).push(0).join(',')
        "( #{Issue.table_name}.id #{compare} (#{ids_list}) ) "
      end

      def available_filters
        super
        selected_tags = []
        if filters['issue_tags'].present?
          selected_tags = Issue.all_tags(project: project, open_only: RedmineupTags.settings['issues_open_only'].to_i == 1).
                          where(name: filters['issue_tags'][:values]).map { |c| [c.name, c.name] }
        end
        add_available_filter('issue_tags', type: :issue_tags, name: l(:tags), values: selected_tags)
      end
    end
  end
end

if RedmineupTags.agile_required_version?('1.4.3')
  AgileQuery.prepend(RedmineupTags::Patches::AgileQueryPatch)
end
